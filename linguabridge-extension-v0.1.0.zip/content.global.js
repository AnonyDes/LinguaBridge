"use strict";
(() => {
  // ../../packages/translation-engine/dist/index.mjs
  var APERTIUM_EWONDO_ENTRIES = [
    {
      "ewo": "a",
      "fra": "il",
      "pos": "prn",
      "par": "cl_0"
    },
    {
      "ewo": "m\xF4t",
      "fra": "personne",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "m\xF4t",
      "fra": "homme",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "m\xF3do",
      "fra": "humanit\xE9",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "minga",
      "fra": "femme",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "abui",
      "fra": "beaucoup",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "a",
      "fra": "\xE0",
      "pos": "pr",
      "par": ""
    },
    {
      "ewo": "abum",
      "fra": "ventre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ab\xF2",
      "fra": "pied",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "af\xEB",
      "fra": "autre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "afi",
      "fra": "malgr\xE9",
      "pos": "pr",
      "par": ""
    },
    {
      "ewo": "dzal",
      "fra": "village",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "byan\u0300",
      "fra": "m\xE9dicament",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nyan\u0300",
      "fra": "mer",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "an\xEB",
      "fra": "comme",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "angondo",
      "fra": "horreur",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "at\xF2m",
      "fra": "ulc\xE8re",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "avus",
      "fra": "camaraderie",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "baala",
      "fra": "garder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mba",
      "fra": "tambour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mb\xE8",
      "fra": "porte",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "di",
      "fra": "manger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bad\xEB",
      "fra": "encore",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bam",
      "fra": "gronder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "an\u0300",
      "fra": "m\xE9dicament",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "anyan\u0300",
      "fra": "son fr\xE8re",
      "pos": "n",
      "par": "n_1/1_sg/sg"
    },
    {
      "ewo": "dzas",
      "fra": "don",
      "pos": "n",
      "par": "n_5b/6_sg/pl"
    },
    {
      "ewo": "asu",
      "fra": "pour",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "bum",
      "fra": "ventre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ai",
      "fra": "avec",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "ayon\u0300",
      "fra": "chaleur",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "mbad\xEBl\xF2g",
      "fra": "malchance",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "bal",
      "fra": "sarcler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ban",
      "fra": "appuyer sur",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbanda",
      "fra": "invitation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mban\u0300",
      "fra": "noyau",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9ban\u0300",
      "fra": "caillot",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9ban\u0300",
      "fra": "fagot",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "abas",
      "fra": "nageoire caudale",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "abe",
      "fra": "mal",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bebe",
      "fra": "pr\xE8s de",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "bede",
      "fra": "soulever",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bede",
      "fra": "d\xE9poser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bende",
      "fra": "recommander",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbendan",
      "fra": "fait d'annoncer",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "b\xE8d",
      "fra": "monter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xE8",
      "fra": "d\xE9pecer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ab\xE8",
      "fra": "sein",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ab\xE8",
      "fra": "cuisse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "b\xEBb\xEB",
      "fra": "regarder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBdan",
      "fra": "supplanter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xEBdan",
      "fra": "cadet",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xEBg",
      "fra": "partitionner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEB",
      "fra": "porter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEBl\xEB",
      "fra": "cafardage",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEBl\xEB",
      "fra": "attiser le feu",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xEBg\xEB",
      "fra": "charge",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mb\xEBb\xEBla",
      "fra": "v\xE9rit\xE9",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "b\xEBlan",
      "fra": "utiliser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBl\xEB",
      "fra": "dire vrai",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBm",
      "fra": "enfoncer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xEBm",
      "fra": "cagibi",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xEBme",
      "fra": "pr\xE9venir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xEBmb\xEB",
      "fra": "convenable",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "biali",
      "fra": "na\xEEtre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abi",
      "fra": "excr\xE9ment",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mbi",
      "fra": "preneur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "bif\xEBf\xE8",
      "fra": "v\xE9g\xE9tation anarchique",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "bie",
      "fra": "donner naissance",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbie",
      "fra": "g\xE9niteur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "big",
      "fra": "d\xE9pister",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "big",
      "fra": "s'enrichir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abig",
      "fra": "urticaire",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "abiali",
      "fra": "naissance",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mbil",
      "fra": "course",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "bili",
      "fra": "\xEAtre contamin\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bili",
      "fra": "\xEAtre saoule",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bim",
      "fra": "enfler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abin",
      "fra": "p\xE9nis",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bindi",
      "fra": "d\xE9nicher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bisi",
      "fra": "photographier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bisi",
      "fra": "tenir compte de",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bit",
      "fra": "entrelacer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9bob",
      "fra": "grossier",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "abobo",
      "fra": "araign\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "boe",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bog",
      "fra": "b\xFBcher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abog",
      "fra": "f\xEAte",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bom",
      "fra": "battre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abom",
      "fra": "tumulus",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "boman",
      "fra": "entourer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mboman",
      "fra": "rhume",
      "pos": "n",
      "par": "n_3/3_sg/sg"
    },
    {
      "ewo": "mboman\xEB",
      "fra": "contour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mbonde",
      "fra": "fondateur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "bonde",
      "fra": "fonder",
      "pos": "refl",
      "par": ""
    },
    {
      "ewo": "b\xF2ban",
      "fra": "se faire",
      "pos": "refl",
      "par": ""
    },
    {
      "ewo": "b\xF2",
      "fra": "faire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xF2",
      "fra": "artisan",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "b\xF2d",
      "fra": "se mouiller",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xF2d",
      "fra": "recadrer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ab\xF2d",
      "fra": "petitesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9b\xF2d",
      "fra": "cabine d'habillage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mb\xF2d",
      "fra": "accoutrement",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "b\xF2dan",
      "fra": "p\xE9trir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xF2dan",
      "fra": "b\xE9n\xE9diction",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xF2\xF2l\xF2",
      "fra": "attester",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xF2\xF2l\xF2",
      "fra": "t\xE9moin",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "mb\xF2g",
      "fra": "un",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ab\xF2m",
      "fra": "morve",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9bonga",
      "fra": "c\xE2blage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mb\xF2n",
      "fra": "huile",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mbu",
      "fra": "ann\xE9e",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "abu",
      "fra": "touffe",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9bubua",
      "fra": "calamit\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "budi",
      "fra": "couvrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bug",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bug\xEBban",
      "fra": "prosp\xE9rer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abug\xEBban",
      "fra": "prosp\xE9rit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bugi",
      "fra": "\xEAtre cass\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bum",
      "fra": "braiser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9buma",
      "fra": "cabosse",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "bumulan",
      "fra": "se pr\xE9cipiter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwal",
      "fra": "pourrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwali",
      "fra": "faire pourrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwe",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bye",
      "fra": "enfanter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dan\u0300",
      "fra": "d\xE9passer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dan\u0300dan\u0300",
      "fra": "surtout",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "dian",
      "fra": "se manger mutuellement",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dib",
      "fra": "fermer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "diban",
      "fra": "se fermer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dibidi",
      "fra": "dissimuler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "digi",
      "fra": "calciner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "diiban",
      "fra": "se ronger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dim",
      "fra": "effacer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ndim",
      "fra": "c\xE9cit\xE9",
      "pos": "n",
      "par": "n_9/2_sg/pl"
    },
    {
      "ewo": "dimi",
      "fra": "camouffler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9dimin\u0300",
      "fra": "cachoterie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "d\xF2",
      "fra": "surtout",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "nd\xF2g",
      "fra": "voracit\xE9",
      "pos": "n",
      "par": "n_3/3_sg/sg"
    },
    {
      "ewo": "\xE9d\xF2g",
      "fra": "profondeur",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nd\xF2b\xEBd\xF2",
      "fra": "h\xF4pital",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "du",
      "fra": "tremper",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dudu",
      "fra": "attirer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dug",
      "fra": "mentir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dulu",
      "fra": "marche",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "dun\u0300",
      "fra": "d\xE9p\xE9rir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBm",
      "fra": "danser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBman",
      "fra": "manquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBm\xEBl\xEB",
      "fra": "dribbler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBn\u0300",
      "fra": "chercher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzib",
      "fra": "voler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ndzin",
      "fra": "un certain",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "dzo",
      "fra": "dire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9dzo",
      "fra": "membre du corps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "adzogodo",
      "fra": "canton",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ndzoe",
      "fra": "dirigeant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "dzu",
      "fra": "pardonner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzug",
      "fra": "se faire mal",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzugu",
      "fra": "avoir l'habitude de",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mesanga",
      "fra": "sa tante paternelle",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mesia",
      "fra": "son p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mesoa",
      "fra": "ton p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "evuezin\u0300",
      "fra": "peut-\xEAtre",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "edzidzin",
      "fra": "dignit\xE9",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ekob",
      "fra": "peau",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "y\xEBgan",
      "fra": "s'etonner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9y\xEBgan",
      "fra": "stup\xE9faction",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "yom\xEBlo",
      "fra": "examiner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fag",
      "fra": "creuser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afan",
      "fra": "for\xEAt",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mfas",
      "fra": "analyse",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "fas\xEBban",
      "fra": "se faire examiner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "f\xEB",
      "fra": "autre",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "f\xEB",
      "fra": "aussi",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "f\xEBb",
      "fra": "sonder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "af\xEBb",
      "fra": "papier",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mf\xEBb",
      "fra": "vapeur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "f\xEBg",
      "fra": "sagesse",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9f\xEBf\xE8",
      "fra": "v\xE9g\xE9tation hanarchique",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9f\xEBl",
      "fra": "cicatrice",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "f\xEBm",
      "fra": "d\xE9tester",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfia",
      "fra": "avocat",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "fib",
      "fra": "s'\xE9paissir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afib",
      "fra": "\xE9paisseur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "fid",
      "fra": "\xE9craser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fidi",
      "fra": "compter sur",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfila",
      "fra": "oreiller",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "fog",
      "fra": "\xEAtre mobile",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afola",
      "fra": "place",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mf\xF2n\u0300",
      "fra": "moelle",
      "pos": "n",
      "par": "n_9/10_sg/pl"
    },
    {
      "ewo": "f\xF2\xF2",
      "fra": "aussi",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "fub",
      "fra": "\xEAtre propre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fubu",
      "fra": "purifier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fulan",
      "fra": "ressembler \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9fulan",
      "fra": "ressemblance",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mfulu",
      "fra": "caract\xE8re",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "fwe",
      "fra": "se multiplier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfwe",
      "fra": "reproducteur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nguma",
      "fra": "entier",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nka",
      "fra": "assistant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nkada",
      "fra": "crabe",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "kad",
      "fra": "dire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kad\xEB",
      "fra": "souvent",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "kag",
      "fra": "empiler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkal",
      "fra": "plaidoyer",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kalan",
      "fra": "transmettre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkalasina",
      "fra": "p\xE9trole",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "kan",
      "fra": "odeur de roussi",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "kandi",
      "fra": "diminuer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ki",
      "fra": "s'abstenir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "aki",
      "fra": "oeuf",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9kie",
      "fra": "fer",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "akie",
      "fra": "feuille",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kig",
      "fra": "ne...pas",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "kil",
      "fra": "refuser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akil",
      "fra": "serve",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kilan",
      "fra": "tourner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kili",
      "fra": "interdire \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akim",
      "fra": "fluidit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kele",
      "fra": "suspendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kele",
      "fra": "circoncier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akele",
      "fra": "circoncision",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "k\xEBlan",
      "fra": "se rompre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kende",
      "fra": "grignotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "k\xEB",
      "fra": "partir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9k\xEBl",
      "fra": "abc\xE8s",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ak\xEBn\u0300",
      "fra": "intelligence",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ak\xEBn\u0300",
      "fra": "technique",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nkidi",
      "fra": "matin",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "koan",
      "fra": "entasser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kuan",
      "fra": "vendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9koan",
      "fra": "r\xE9union",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "akoa",
      "fra": "pierre",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nkob",
      "fra": "puce",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "\xE9kod",
      "fra": "teigne",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "kodo",
      "fra": "quitter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akog",
      "fra": "pierre",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kom",
      "fra": "fabriquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkomo",
      "fra": "fabriquant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nkon",
      "fra": "fant\xF4me",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "k\xF2b\xF2",
      "fra": "parler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "k\xF2d",
      "fra": "tourner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akol",
      "fra": "pied",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "akoli",
      "fra": "pi\xE9ger",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "koge",
      "fra": "mordre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kogo",
      "fra": "ajouter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kogolo",
      "fra": "ajouter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nk\xF2b\xF2",
      "fra": "acceptation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "k\xF2m",
      "fra": "longtemps",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "k\xF2m",
      "fra": "habitude",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "ak\xF2m",
      "fra": "lourdeur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9k\xF2n",
      "fra": "maladie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "k\xF2n",
      "fra": "\xEAtre malade",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEB",
      "fra": "tatouer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEBban",
      "fra": "se faire vacciner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEBmve",
      "fra": "cellulite",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ku",
      "fra": "tomber",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kue",
      "fra": "tousser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9kue",
      "fra": "toux",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nkugu",
      "fra": "cuisinier",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "nkukuma",
      "fra": "chef",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kulan",
      "fra": "se d\xE9tacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kuliban",
      "fra": "se faire d\xE9tacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkulu",
      "fra": "tortue",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "nkulu",
      "fra": "tornade",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "akun",
      "fra": "poubelle",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kus",
      "fra": "acheter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkus",
      "fra": "achat",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kus",
      "fra": "veuvage",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "nkus",
      "fra": "veuve",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kwe",
      "fra": "cueillir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akwe",
      "fra": "escargot",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kwi",
      "fra": "sortir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akwi",
      "fra": "sortie",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "akya",
      "fra": "type",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "l\xEBd\xEB",
      "fra": "montrer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9l\xEBmb\xEB",
      "fra": "microscope",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "l\xEBmb\xEB",
      "fra": "guetter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9labi",
      "fra": "cadeau",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "lad",
      "fra": "coudre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lada",
      "fra": "\xEAtre coll\xE9 \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lamvomba",
      "fra": "bourru",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "lan\u0300",
      "fra": "lire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "alen",
      "fra": "palmier",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "l\xE8",
      "fra": "puiser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "l\xE8d",
      "fra": "durcir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nl\xE8d",
      "fra": "duret\xE9",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "l\xE8n",
      "fra": "ruisseler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "al\xE8na",
      "fra": "infection due \xE0 une morsure d'araign\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "li",
      "fra": "d\xE9fricher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lod",
      "fra": "d\xE9passer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lob",
      "fra": "mordre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lob",
      "fra": "sene\xE7on",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "alog",
      "fra": "p\xEAche au barrage",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "log",
      "fra": "faire la p\xEAche au barrage",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "al\xF2",
      "fra": "oreille",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9l\xF2bi",
      "fra": "mar\xE9cage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9l\xF2g",
      "fra": "herbe",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "l\xF2m",
      "fra": "c\xE9l\xE9brer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nlo",
      "fra": "t\xEAte",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "lum",
      "fra": "piquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "luman",
      "fra": "injecter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lunga",
      "fra": "association",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mma",
      "fra": "mouleur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xE9mag",
      "fra": "tas",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "man\xEB",
      "fra": "terminer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mmba",
      "fra": "tambour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "meki",
      "fra": "sang",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "amos",
      "fra": "journ\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9mvum",
      "fra": "particule",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nal",
      "fra": "mensonge",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "\xE9nam",
      "fra": "membre sup\xE9rieur du corps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "namba",
      "fra": "toucher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "anda",
      "fra": "maison",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "andi",
      "fra": "espoir",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nnd\xF2n\u0300",
      "fra": "rapport",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "ndim",
      "fra": "eau",
      "pos": "n",
      "par": "n_6a/6a_pl/pl"
    },
    {
      "ewo": "\xE9ngog\xF2l",
      "fra": "piti\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "angomba",
      "fra": "ngomba",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "angon\u0300",
      "fra": "cadenas",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngan",
      "fra": "se braquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9ngan",
      "fra": "obstin\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9ngas",
      "fra": "marais",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ng\xEBng",
      "fra": "clair",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "ang\xEBng\xE8",
      "fra": "insecte",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngoge",
      "fra": "soir",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "angos",
      "fra": "tas",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngul",
      "fra": "force",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "angula",
      "fra": "cabane",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngun",
      "fra": "entasser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ngunubu",
      "fra": "accumuler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "n\xF2n\u0300",
      "fra": "prendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "anyama",
      "fra": "calamiteux",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyin\u0300",
      "fra": "vivre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9nyin\u0300",
      "fra": "vie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "anyu",
      "fra": "bouche",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyum",
      "fra": "sentir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9nyum",
      "fra": "odeur",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "dzoap",
      "fra": "nombril",
      "pos": "n",
      "par": "n_5b/6_sg/pl"
    },
    {
      "ewo": "oe",
      "fra": "rire",
      "pos": "n",
      "par": "n_5c/5c_sg/sg"
    },
    {
      "ewo": "dzooga",
      "fra": "articulation",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "m\xF2n\u0300\xF2n",
      "fra": "rejeton",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "k\xF2n",
      "fra": "maladie",
      "pos": "n",
      "par": "n_11/5_sg/pl"
    },
    {
      "ewo": "mmaw\xF2d",
      "fra": "ma\xE7on",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mm\xEBtua",
      "fra": "voiture",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mmvigi",
      "fra": "pratique m\xE9dicale",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mmvim",
      "fra": "enflure",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "mmy\xEBg\xEB",
      "fra": "digue",
      "pos": "n",
      "par": "n_9/2_sg/pl"
    },
    {
      "ewo": "nn\xEBn\u0300",
      "fra": "h\xF4te",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nnom",
      "fra": "male",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nnyala",
      "fra": "beau-fr\xE8re",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "op",
      "fra": "ciel",
      "pos": "n",
      "par": "n_5d/5d_sg/sg"
    },
    {
      "ewo": "m\xF2ng\xF2",
      "fra": "enfant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xF2ng\xF2",
      "fra": "calamit\xE9",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "\xE9salag",
      "fra": "caniveau",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "sanga",
      "fra": "tisane",
      "pos": "n",
      "par": "n_11/16_sg/pl"
    },
    {
      "ewo": "\xE9s\xEBd\xEBga",
      "fra": "\xE9chantillon",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ns\xEBn\u0300",
      "fra": "cour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ns\xEBm",
      "fra": "p\xE9ch\xE9",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nsi",
      "fra": "terre",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "asie",
      "fra": "cabinet",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nsis",
      "fra": "nerf",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nsili",
      "fra": "question",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "s\xF2",
      "fra": "\xEAtre venu",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "as\xF2",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ns\xF2b\xF2",
      "fra": "savon",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "s\xF2b\xF2",
      "fra": "se cacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "as\xF2b\xF2",
      "fra": "cache",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "as\xF2l\xF2",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "asoe",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nsoe",
      "fra": "l\xE9zard",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "asoga",
      "fra": "calao",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "s\xF2s",
      "fra": "medisance",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "susu",
      "fra": "pluie diluvienne",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9susud",
      "fra": "humidit\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nsusug",
      "fra": "pareusseux",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9tam",
      "fra": "puits",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ntada",
      "fra": "p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "ntela",
      "fra": "tailleur",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "t\xE8",
      "fra": "\xEAtre douloureux",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "at\xEBg",
      "fra": "faiblesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nti",
      "fra": "seigneur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "tin",
      "fra": "souche",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "tinte",
      "fra": "encre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "tog",
      "fra": "s'aggraver",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntog",
      "fra": "cuill\xE8re",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "atom",
      "fra": "colis",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9t\xF2",
      "fra": "place",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "at\xF2m",
      "fra": "ulc\xE8re de Buruli",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "atolog",
      "fra": "papule",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ntsan\u0300",
      "fra": "bouton",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "tug",
      "fra": "frotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntug",
      "fra": "action de frotter",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ntug",
      "fra": "d\xE9su\xE9tude",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "tugu",
      "fra": "\xEAtre en train de frotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": 'ntugu"n"/>',
      "fra": "frotteur",
      "pos": "",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "tugulu",
      "fra": "causer une l\xE9sion",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntugulu",
      "fra": "l\xE9sion",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9tun",
      "fra": "partie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "tye",
      "fra": "taquinerie",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "avis",
      "fra": "amas",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "\xE9v\xE8",
      "fra": "soif",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9v\xE8s",
      "fra": "os",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "v\xEBb\xEB",
      "fra": "respirer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mv\xEBb\xEB",
      "fra": "respiration",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xE9v\xEBga",
      "fra": "exemple",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "av\xEBn\u0300",
      "fra": "plaie",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "avol",
      "fra": "rapidit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "av\xF2n\u0300",
      "fra": "graisse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "v\xF2g",
      "fra": "autre",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "weme",
      "fra": "se muer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9wem\xEBnga",
      "fra": "n\xE9crose",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nwundi",
      "fra": "fen\xEAtre",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "g\xEBban",
      "fra": "scintiller",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "w\xF2",
      "fra": "main",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "nwulu",
      "fra": "marcheur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "ya",
      "fra": "grandir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ayab",
      "fra": "longueur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9yalga",
      "fra": "enveloppe",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ayan\u0300",
      "fra": "couleur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayan\u0300",
      "fra": "bulbe",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "aye",
      "fra": "p\xE9riode",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "ny\xEBb\xEB",
      "fra": "acceptation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ay\xEBg\xE8",
      "fra": "apprentissage",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9y\xEBm",
      "fra": "handicape",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "y\xEBm",
      "fra": "savoir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "y\xE8",
      "fra": "cro\xEEtre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ay\xE8",
      "fra": "croissance",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "y\xEBm",
      "fra": "\xEAtre coinc\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "yi",
      "fra": "vouloir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9yia",
      "fra": "ulc\xE8re phag\xE9d\xE9nique",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ayie",
      "fra": "difficult\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyoa",
      "fra": "ta m\xE8re",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "ayol",
      "fra": "amertume",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayom",
      "fra": "vieillesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayom",
      "fra": "caducit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9y\xF2n\u0300",
      "fra": "temps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "yom\xEBlo",
      "fra": "raviver",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nyon",
      "fra": "pleur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "Zamba",
      "fra": "Dieu",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "zam",
      "fra": "l\xE8pre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9zam\xEBda",
      "fra": "cafouillage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "zie",
      "fra": "faim",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "azimbi",
      "fra": "soldats",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "zin\u0300",
      "fra": "un tel",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "v\xEB",
      "fra": "donner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "veend\xEBg\xEBle",
      "fra": "d\xE9ranger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "avon\u0300",
      "fra": "chaleur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nd\xEBg\xEBl\xEB",
      "fra": "ennui",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ama",
      "fra": "mon",
      "pos": "adj",
      "par": "pos_GDND_Gender-1"
    }
  ];
  var FINANCIAL_GLOSSARY_ENTRIES = [
    {
      "ewo": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
      "fra": "Solde disponible",
      "en": "Available balance",
      "phonetic": "m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B"
    },
    {
      "ewo": "L\xF3m m\xF3ni",
      "fra": "Virement / Transfert",
      "en": "Money transfer",
      "phonetic": "l\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "N\xF2ng m\xF3ni",
      "fra": "Retrait d'argent",
      "en": "Cash withdrawal",
      "phonetic": "n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "W\xF3gl\xF4 m\xF3ni",
      "fra": "D\xE9p\xF4t d'argent",
      "en": "Deposit",
      "phonetic": "w\xF3-gl\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m",
      "fra": "Frais de transfert",
      "en": "Transfer fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-l\xF3m"
    },
    {
      "ewo": "Ny\xED a n\xF2ng m\xF3ni",
      "fra": "B\xE9n\xE9ficiaire",
      "en": "Beneficiary",
      "phonetic": "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "T\xEDb\xEDli t\xF3b\xF3",
      "fra": "Confirmer le transfert",
      "en": "Confirm transfer",
      "phonetic": "t\xED-b\xED-l\xED t\xF3-b\xF3"
    },
    {
      "ewo": "Dz\xE1gb\xE1",
      "fra": "Annuler",
      "en": "Cancel",
      "phonetic": "dz\xE1-gb\xE1"
    },
    {
      "ewo": "Abui m\xF3ni",
      "fra": "Montant du transfert",
      "en": "Transfer amount",
      "phonetic": "\xE0-b\xF9\xEC m\xF3-n\xED"
    },
    {
      "ewo": "Nlamb\xE1 telef\xF4n",
      "fra": "Num\xE9ro de t\xE9l\xE9phone",
      "en": "Phone number",
      "phonetic": "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n"
    },
    {
      "ewo": "Nd\xE1mb\xE1 ts\xEDti",
      "fra": "Code secret / PIN",
      "en": "Secret PIN",
      "phonetic": "n-d\xE1m-b\xE1 ts\xED-t\xED"
    },
    {
      "ewo": "Minl\xF3m m\xED ay\xE1a l\xF3t",
      "fra": "Historique des transactions",
      "en": "Transaction history",
      "phonetic": "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t"
    },
    {
      "ewo": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa",
      "fra": "Transfert effectu\xE9 avec succ\xE8s",
      "en": "Transfer successful",
      "phonetic": "l\xF3m m\xF3-n\xED l-\xE0-y\xE1-\xE1 d\xFA-\xE1"
    },
    {
      "ewo": "L\xF3m m\xF3ni l'ab\xEA d\xFAa",
      "fra": "\xC9chec de l'op\xE9ration",
      "en": "Operation failed",
      "phonetic": "l\xF3m m\xF3-n\xED l-\xE0-b\xE9 d\xFA-\xE1"
    },
    {
      "ewo": "M\xF3ni ts\u0254\u0301",
      "fra": "Cotisation tontine",
      "en": "Tontine contribution",
      "phonetic": "m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "\xC9k\xF3bl\xF3 m\xF3ni ya \xE9t\xE1m",
      "fra": "Compte principal",
      "en": "Main account",
      "phonetic": "\xE9-k\xF3-bl\xF3 m\xF3-n\xED y\xE0 \xE9-t\xE1m"
    },
    {
      "ewo": "Kalad\xED nl\xE1man",
      "fra": "Re\xE7u de paiement",
      "en": "Payment receipt",
      "phonetic": "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n"
    },
    {
      "ewo": "V\xE1 m\xF3ni",
      "fra": "Envoyer de l'argent",
      "en": "Send money",
      "phonetic": "v\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "N\xF2ng m\xF3ni",
      "fra": "Recevoir de l'argent",
      "en": "Receive money",
      "phonetic": "n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "\xC9m\xF2t a k\xF9s m\xF3ni",
      "fra": "Point de vente / Agent",
      "en": "Agent / Point of sale",
      "phonetic": "\xE9-m\xF2t \xE0 k\xF9s m\xF3-n\xED"
    }
  ];
  var EXTENDED_BANKING_UI_LEXICON = {
    // Navigation & Space
    "bienvenue": { ewo: "Mb\xF3lo", phonetic: "m-b\xF3-lo" },
    "bienvenue sur votre espace bancaire": { ewo: "Mb\xF3lo \xE9 mv\xF4k nda m\xF3ni w\xEAn", phonetic: "m-b\xF3-lo \xE9 m-v\xF4k n-da m\xF3-n\xED w\xEAn" },
    "bienvenue sur votre espace client": { ewo: "Mb\xF3lo \xE9 mv\xF4k \xE9m\xF2t w\xEAn", phonetic: "m-b\xF3-lo \xE9 m-v\xF4k \xE9-m\xF2t w\xEAn" },
    "bienvenue sur": { ewo: "Mb\xF3lo \xE9", phonetic: "m-b\xF3-lo \xE9" },
    "espace bancaire": { ewo: "Mv\xF4k nda m\xF3ni", phonetic: "m-v\xF4k n-da m\xF3-n\xED" },
    "espace client": { ewo: "Mv\xF4k \xE9m\xF2t", phonetic: "m-v\xF4k \xE9-m\xF2t" },
    "mon espace": { ewo: "Mv\xF4k dama", phonetic: "m-v\xF4k da-ma" },
    "votre espace": { ewo: "Mv\xF4k w\xEAn", phonetic: "m-v\xF4k w\xEAn" },
    "espace": { ewo: "Mv\xF4k", phonetic: "m-v\xF4k" },
    "accueil": { ewo: "Mv\xF4k", phonetic: "m-v\xF4k" },
    "page d accueil": { ewo: "Mv\xF4k kalad\xED", phonetic: "m-v\xF4k k\xE0-l\xE0-d\xED" },
    "page d'accueil": { ewo: "Mv\xF4k kalad\xED", phonetic: "m-v\xF4k k\xE0-l\xE0-d\xED" },
    "menu": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "param\xE8tres": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "parametres": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "profil": { ewo: "\xC9m\xF2t", phonetic: "\xE9-m\xF2t" },
    "client": { ewo: "M\xF4t", phonetic: "m\xF4t" },
    "clients": { ewo: "B\xF4t", phonetic: "b\xF4t" },
    "utilisateur": { ewo: "M\xF4t", phonetic: "m\xF4t" },
    "utilisateurs": { ewo: "B\xF4t", phonetic: "b\xF4t" },
    "tableau de bord": { ewo: "Mv\xF4k mimb\xF2n\xE1n", phonetic: "m-v\xF4k m\xECm-b\xF2-n\xE1n" },
    // Banking Institutions & Points of Service
    "banque": { ewo: "Nda m\xF3ni", phonetic: "n-da m\xF3-n\xED" },
    "banques": { ewo: "Menda m\xE9 m\xF3ni", phonetic: "men-da m\xE9 m\xF3-n\xED" },
    "agence": { ewo: "T\xF2 nda m\xF3ni", phonetic: "t\xF2 n-da m\xF3-n\xED" },
    "agences": { ewo: "M\xE8t\xF2 nda m\xF3ni", phonetic: "m\xE8-t\xF2 n-da m\xF3-n\xED" },
    "guichet": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "guichets": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "distributeur": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "distributeurs": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "distributeur automatique": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "dab": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    // Accounts
    "compte": { ewo: "\xC9k\xF3bl\xF3", phonetic: "\xE9-k\xF3-bl\xF3" },
    "comptes": { ewo: "Mak\xF3bl\xF3", phonetic: "ma-k\xF3-bl\xF3" },
    "mon compte": { ewo: "\xC9k\xF3bl\xF3 dama", phonetic: "\xE9-k\xF3-bl\xF3 da-ma" },
    "mes comptes": { ewo: "Mak\xF3bl\xF3 mama", phonetic: "ma-k\xF3-bl\xF3 ma-ma" },
    "votre compte": { ewo: "\xC9k\xF3bl\xF3 w\xEAn", phonetic: "\xE9-k\xF3-bl\xF3 w\xEAn" },
    "vos comptes": { ewo: "Mak\xF3bl\xF3 m\xEAn", phonetic: "ma-k\xF3-bl\xF3 m\xEAn" },
    "compte bancaire": { ewo: "\xC9k\xF3bl\xF3 m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 m\xF3-n\xED" },
    "compte courant": { ewo: "\xC9k\xF3bl\xF3 \xE9t\xE1m", phonetic: "\xE9-k\xF3-bl\xF3 \xE9-t\xE1m" },
    "compte epargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte \xE9pargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte d'\xE9pargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte d epargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "num\xE9ro de compte": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    "relev\xE9 de compte": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "releve de compte": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "relev\xE9": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "releve": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "rib": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    "iban": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    // Balances & Currency
    "solde": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "balance": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "solde disponible": { ewo: "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng", phonetic: "m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B" },
    "solde actuel": { ewo: "M\xF3ni m\xED ne n\xE1n\xE1", phonetic: "m\xF3-n\xED m\xED n\xE9 n\xE1-n\xE1" },
    "mon solde": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "votre solde": { ewo: "M\xF3ni m\xED ne w\xEAn", phonetic: "m\xF3-n\xED m\xED n\xE9 w\xEAn" },
    "consulter mon solde": { ewo: "Y\xEAn m\xF3ni m\xED ne", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9" },
    "consulter mon compte": { ewo: "Y\xEAn \xE9k\xF3bl\xF3 dama", phonetic: "y\xEAn \xE9-k\xF3-bl\xF3 da-ma" },
    "consulter le solde": { ewo: "Y\xEAn m\xF3ni m\xED ne", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9" },
    "consulter le solde disponible": { ewo: "Y\xEAn m\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B" },
    "consulter": { ewo: "Y\xEAn", phonetic: "y\xEAn" },
    "montant": { ewo: "Abui m\xF3ni", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED" },
    "montant du transfert": { ewo: "Abui m\xF3ni y\xE1 nl\xF3m", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED y\xE1 n-l\xF3m" },
    "montant total": { ewo: "Abui m\xF3ni m\xE9s\xEB", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-s\xEB" },
    "argent": { ewo: "M\xF3ni", phonetic: "m\xF3-n\xED" },
    "l'argent": { ewo: "M\xF3ni", phonetic: "m\xF3-n\xED" },
    "d'argent": { ewo: "m\xF3ni", phonetic: "m\xF3-n\xED" },
    "votre argent": { ewo: "M\xF3ni w\xEAn", phonetic: "m\xF3-n\xED w\xEAn" },
    "mon argent": { ewo: "M\xF3ni wama", phonetic: "m\xF3-n\xED wa-ma" },
    "votre argent est en s\xE9curit\xE9": { ewo: "M\xF3ni w\xEAn \xE9 ne mba\xE1n", phonetic: "m\xF3-n\xED w\xEAn \xE9 n\xE9 m-ba-\xE1n" },
    // Transfers & Operations
    "virement": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "virements": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "transfert": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "transferts": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "virement bancaire": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "transfert d'argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un virement": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un transfert": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un virement s\xE9curis\xE9": { ewo: "L\xF3m m\xF3ni \xE9 ne mba\xE1n", phonetic: "l\xF3m m\xF3-n\xED \xE9 n\xE9 m-ba-\xE1n" },
    "envoyer de l'argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "envoyer de l argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "envoyer": { ewo: "L\xF3m", phonetic: "l\xF3m" },
    "recevoir de l'argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "recevoir de l argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "recevoir": { ewo: "N\xF2ng", phonetic: "n\xF2\u014B" },
    "retrait": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "retraits": { ewo: "Minl\xF2ng m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF2\u014B m\xED m\xF3-n\xED" },
    "retrait d'argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "retrait au distributeur": { ewo: "N\xF2ng m\xF3ni \xE9 mas\xEDn", phonetic: "n\xF2\u014B m\xF3-n\xED \xE9 ma-s\xEDn" },
    "d\xE9p\xF4t": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "depot": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "d\xE9p\xF4ts": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "depots": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "d\xE9p\xF4t d'argent": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "payer": { ewo: "K\xF9s", phonetic: "k\xF9s" },
    "paiement": { ewo: "T\xF3b\xF3 m\xF3ni", phonetic: "t\xF3-b\xF3 m\xF3-n\xED" },
    "paiements": { ewo: "Mat\xF3b\xF3 m\xF3ni", phonetic: "ma-t\xF3-b\xF3 m\xF3-n\xED" },
    "paiement de facture": { ewo: "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED", phonetic: "t\xF3-b\xF3 m\xF3-n\xED y\xE1 k\xE0-l\xE0-d\xED" },
    "paiement s\xE9curis\xE9": { ewo: "T\xF3b\xF3 m\xF3ni \xE9 ne mba\xE1n", phonetic: "t\xF3-b\xF3 m\xF3-n\xED \xE9 n\xE9 m-ba-\xE1n" },
    "facture": { ewo: "Kalad\xED m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED m\xF3-n\xED" },
    "factures": { ewo: "Mekalad\xED m\xE9 m\xF3ni", phonetic: "me-k\xE0-l\xE0-d\xED m\xE9 m\xF3-n\xED" },
    "re\xE7u": { ewo: "Kalad\xED nl\xE1man", phonetic: "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "recu": { ewo: "Kalad\xED nl\xE1man", phonetic: "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "re\xE7us": { ewo: "Mekalad\xED nl\xE1man", phonetic: "me-k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "recus": { ewo: "Mekalad\xED nl\xE1man", phonetic: "me-k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger mon re\xE7u": { ewo: "N\xF2ng kalad\xED nl\xE1man", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger le re\xE7u": { ewo: "N\xF2ng kalad\xED nl\xE1man", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger": { ewo: "N\xF2ng kalad\xED", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED" },
    "telecharger": { ewo: "N\xF2ng kalad\xED", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED" },
    // Fees & Economics
    "frais": { ewo: "M\xF3ni m\xE9bemb\xE1", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "frais de transfert": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-l\xF3m" },
    "frais de tenue de compte": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 \xE9k\xF3bl\xF3", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 \xE9-k\xF3-bl\xF3" },
    "frais de retrait": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 nn\xF2ng", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-n\xF2\u014B" },
    "sans frais": { ewo: "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1", phonetic: "t\xE9-g\xE9 m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "gratuit": { ewo: "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1", phonetic: "t\xE9-g\xE9 m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "taux": { ewo: "Abui", phonetic: "\xE0-b\xF9\xEC" },
    "taux d'int\xE9r\xEAt": { ewo: "Abui m\xF3ni m\xE9bemb\xE1", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "taux d interet": { ewo: "Abui m\xF3ni m\xE9bemb\xE1", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "cr\xE9dit": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "credit": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "cr\xE9dits": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "credits": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pr\xEAt": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pret": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pr\xEAts": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "prets": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "\xE9pargne": { ewo: "B\xF3m m\xF3ni", phonetic: "b\xF3m m\xF3-n\xED" },
    "epargne": { ewo: "B\xF3m m\xF3ni", phonetic: "b\xF3m m\xF3-n\xED" },
    "tontine": { ewo: "M\xF3ni ts\u0254\u0301", phonetic: "m\xF3-n\xED ts\u0254\u0301" },
    "cotisation": { ewo: "M\xF3ni ts\u0254\u0301", phonetic: "m\xF3-n\xED ts\u0254\u0301" },
    // Parties & Roles
    "b\xE9n\xE9ficiaire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "beneficiaire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "b\xE9n\xE9ficiaires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "beneficiaires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "destinataire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "destinataires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "exp\xE9diteur": { ewo: "Ny\xED a l\xF3m m\xF3ni", phonetic: "ny\xED \xE0 l\xF3m m\xF3-n\xED" },
    "expediteur": { ewo: "Ny\xED a l\xF3m m\xF3ni", phonetic: "ny\xED \xE0 l\xF3m m\xF3-n\xED" },
    // History & Transactions
    "historique des transactions": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "historique des op\xE9rations": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "historique": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "transactions r\xE9centes": { ewo: "Minl\xF3m m\xED m\xF3ni m\xEDmpepe", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED m\xEDm-p\xE8-p\xE8" },
    "transactions": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "transaction": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    "op\xE9rations": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "operations": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "op\xE9ration": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    "operation": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    // Security & Authentication
    "s\xE9curit\xE9": { ewo: "Mba\xE1n", phonetic: "m-ba-\xE1n" },
    "securite": { ewo: "Mba\xE1n", phonetic: "m-ba-\xE1n" },
    "s\xE9curis\xE9": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "securise": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "en s\xE9curit\xE9": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "authentification": { ewo: "Y\xEAm \xE9m\xF2t", phonetic: "y\xEAm \xE9-m\xF2t" },
    "connexion": { ewo: "Nyin", phonetic: "nyin" },
    "se connecter": { ewo: "Nyin", phonetic: "nyin" },
    "connectez-vous": { ewo: "Nyin", phonetic: "nyin" },
    "connectez-vous \xE0 votre compte": { ewo: "Nyin \xE9k\xF3bl\xF3 w\xEAn", phonetic: "nyin \xE9-k\xF3-bl\xF3 w\xEAn" },
    "connect\xE9": { ewo: "\xC1 nyin", phonetic: "\xE1 nyin" },
    "connectee": { ewo: "\xC1 nyin", phonetic: "\xE1 nyin" },
    "d\xE9connexion": { ewo: "Kwi", phonetic: "kwi" },
    "se d\xE9connecter": { ewo: "Kwi", phonetic: "kwi" },
    "d\xE9connectez-vous": { ewo: "Kwi", phonetic: "kwi" },
    "carte": { ewo: "Kalad\xED m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED m\xF3-n\xED" },
    "cartes": { ewo: "Mekalad\xED m\xE9 m\xF3ni", phonetic: "me-k\xE0-l\xE0-d\xED m\xE9 m\xF3-n\xED" },
    "carte bancaire": { ewo: "Kalad\xED nda m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED n-da m\xF3-n\xED" },
    "carte de cr\xE9dit": { ewo: "Kalad\xED k\xE1l\xE1 m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED k\xE1-l\xE1 m\xF3-n\xED" },
    "code": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "code secret": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "mot de passe": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "pin": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "entrez votre code secret": { ewo: "Tsil\xED nd\xE1mb\xE1 ts\xEDti w\xEAn", phonetic: "ts\xEC-l\xED n-d\xE1m-b\xE1 ts\xED-t\xED w\xEAn" },
    // Buttons & Interactions
    "confirmer le transfert": { ewo: "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3 n-l\xF3m" },
    "confirmer": { ewo: "T\xEDb\xEDli t\xF3b\xF3", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3" },
    "valider": { ewo: "T\xEDb\xEDli t\xF3b\xF3", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3" },
    "annuler": { ewo: "Dz\xE1gb\xE1", phonetic: "dz\xE1-gb\xE1" },
    "partager": { ewo: "K\xE1b\xE1n", phonetic: "k\xE1-b\xE1n" },
    "voir": { ewo: "Y\xEAn", phonetic: "y\xEAn" },
    "continuer": { ewo: "K\xEB \xF4su", phonetic: "k\xEB \xF4-su" },
    "suivant": { ewo: "Ny\xED a y\xE1a zu", phonetic: "ny\xED \xE0 y\xE1-\xE1 zu" },
    "pr\xE9c\xE9dent": { ewo: "Ny\xED a l\xF3t", phonetic: "ny\xED \xE0 l\xF3t" },
    "precedent": { ewo: "Ny\xED a l\xF3t", phonetic: "ny\xED \xE0 l\xF3t" },
    "fermer": { ewo: "Dib", phonetic: "dib" },
    "ouvrir": { ewo: "Yob", phonetic: "yob" },
    "supprimer": { ewo: "Dim", phonetic: "dim" },
    "modifier": { ewo: "Tsindin", phonetic: "tsin-din" },
    "enregistrer": { ewo: "B\xF3m", phonetic: "b\xF3m" },
    "recherche": { ewo: "Dz\xEBn", phonetic: "dz\xE8\u014B" },
    "rechercher": { ewo: "Dz\xEBn", phonetic: "dz\xE8\u014B" },
    // Communication, Support & Details
    "aide et support": { ewo: "Nv\xF4l ai nkob\xF3", phonetic: "n-v\xF4l a-\xED n-ko-b\xF3" },
    "aide": { ewo: "Nv\xF4l", phonetic: "n-v\xF4l" },
    "support client": { ewo: "Nv\xF4l \xE9m\xF2t", phonetic: "n-v\xF4l \xE9-m\xF2t" },
    "contactez-nous": { ewo: "K\xF2b\xF2 ai b\xEDa", phonetic: "k\xF2-b\xF2 a-\xED b\xED-a" },
    "contact": { ewo: "K\xF2b\xF2 ai b\xEDa", phonetic: "k\xF2-b\xF2 a-\xED b\xED-a" },
    "t\xE9l\xE9phone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "telephone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "numero de telephone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "num\xE9ro de t\xE9l\xE9phone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "date": { ewo: "Mos", phonetic: "mos" },
    "heure": { ewo: "Nge\u014B", phonetic: "\u014Be\u014B" },
    "\xE9ch\xE9ance": { ewo: "Mos y\xE1 man\xEB", phonetic: "mos y\xE1 ma-n\xEB" },
    "echeance": { ewo: "Mos y\xE1 man\xEB", phonetic: "mos y\xE1 ma-n\xEB" },
    "statut": { ewo: "Ne d\xE9", phonetic: "ne d\xE9" },
    "r\xE9ussi": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "succ\xE8s": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "succes": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "effectu\xE9": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "effectue": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "\xE9chec": { ewo: "L ab\xEA d\xFAa", phonetic: "l \xE0-b\xE9 d\xFA-\xE1" },
    "echec": { ewo: "L ab\xEA d\xFAa", phonetic: "l \xE0-b\xE9 d\xFA-\xE1" },
    "en cours": { ewo: "\xC9 ng\xE1 b\u0254ban", phonetic: "\xE9 \u014B\xE1 b\xF2-ban" },
    "en attente": { ewo: "\xC9 ng\xE1 yange", phonetic: "\xE9 \u014B\xE1 ya\u014B-ge" },
    "service": { ewo: "\xC9s\xEB", phonetic: "\xE9-s\xEB" },
    "services": { ewo: "M\xE9s\xEB", phonetic: "m\xE9-s\xEB" },
    "nos services": { ewo: "M\xE9s\xEB mama", phonetic: "m\xE9-s\xEB ma-ma" },
    "services bancaires": { ewo: "M\xE9s\xEB m\xE9 nda m\xF3ni", phonetic: "m\xE9-s\xEB m\xE9 n-da m\xF3-n\xED" },
    "notification": { ewo: "Nkat", phonetic: "n-kat" },
    "notifications": { ewo: "Minkat", phonetic: "m\xECn-kat" },
    "message": { ewo: "Nkat", phonetic: "n-kat" },
    "messages": { ewo: "Minkat", phonetic: "m\xECn-kat" },
    "bonjour": { ewo: "Mb\xF3lo", phonetic: "m-b\xF3-lo" },
    "bonsoir": { ewo: "Mb\xF3lo ngoge", phonetic: "m-b\xF3-lo \u014Bo-ge" },
    "merci": { ewo: "Ak\xEDba", phonetic: "a-k\xED-ba" },
    "merci de votre confiance": { ewo: "Ak\xEDba", phonetic: "a-k\xED-ba" },
    "oui": { ewo: "\xC9y\xE9", phonetic: "\xE9-y\xE9" },
    "non": { ewo: "T\xE9g\xE9", phonetic: "t\xE9-g\xE9" },
    "attention": { ewo: "T\xE1b\xE9 a\xED mes\xF3", phonetic: "t\xE1-b\xE9 a-\xED me-s\xF3" },
    // Prepositions, Pronouns & Everyday Connectives
    "sur": { ewo: "\xE1", phonetic: "\xE1" },
    "dans": { ewo: "\xE9t\xE9", phonetic: "\xE9-t\xE9" },
    "en": { ewo: "\xE9", phonetic: "\xE9" },
    "pour": { ewo: "as\xFA", phonetic: "a-s\xFA" },
    "avec": { ewo: "a\xED", phonetic: "a-\xED" },
    "sans": { ewo: "t\xE9g\xE9", phonetic: "t\xE9-g\xE9" },
    "vers": { ewo: "\xE9 be", phonetic: "\xE9 be" },
    "de": { ewo: "y\xE1", phonetic: "y\xE1" },
    "du": { ewo: "y\xE1", phonetic: "y\xE1" },
    "des": { ewo: "m\xE9", phonetic: "m\xE9" },
    "et": { ewo: "a\xED", phonetic: "a-\xED" },
    "ou": { ewo: "ng\xE9", phonetic: "ng\xE9" },
    "est": { ewo: "ne", phonetic: "ne" },
    "sont": { ewo: "b\xE9 ne", phonetic: "b\xE9 ne" },
    "votre": { ewo: "w\xEAn", phonetic: "w\xEAn" },
    "vos": { ewo: "m\xEAn", phonetic: "m\xEAn" },
    "notre": { ewo: "w\xEDs", phonetic: "w\xEDs" },
    "nos": { ewo: "m\xEDs", phonetic: "m\xEDs" },
    "mon": { ewo: "wama", phonetic: "wa-ma" },
    "ma": { ewo: "wama", phonetic: "wa-ma" },
    "mes": { ewo: "mama", phonetic: "ma-ma" },
    "tout": { ewo: "m\xEBs\xEB", phonetic: "m\xEB-s\xEB" },
    "tous": { ewo: "b\xEBs\xEB", phonetic: "b\xEB-s\xEB" },
    "toute": { ewo: "\xE9s\xEB", phonetic: "\xE9-s\xEB" },
    "homme": { ewo: "m\xF4t", phonetic: "m\xF4t" },
    "femme": { ewo: "minga", phonetic: "min-ga" },
    "personne": { ewo: "m\xF4t", phonetic: "m\xF4t" },
    "gens": { ewo: "b\xF4t", phonetic: "b\xF4t" },
    "village": { ewo: "dzal", phonetic: "dzal" },
    "porte": { ewo: "mb\xE8", phonetic: "m-b\xE8" },
    "annee": { ewo: "mbu", phonetic: "m-bu" },
    "ann\xE9e": { ewo: "mbu", phonetic: "m-bu" },
    "jour": { ewo: "mos", phonetic: "mos" },
    "mois": { ewo: "ngon", phonetic: "ngon" }
  };
  var frToEwoMap = /* @__PURE__ */ new Map();
  var enToEwoMap = /* @__PURE__ */ new Map();
  var ewoPhoneticMap = /* @__PURE__ */ new Map();
  for (const entry of APERTIUM_EWONDO_ENTRIES) {
    const normFra = entry.fra.toLowerCase().trim();
    if (normFra && entry.ewo) {
      if (!frToEwoMap.has(normFra)) {
        frToEwoMap.set(normFra, entry.ewo);
      }
    }
  }
  for (const term of FINANCIAL_GLOSSARY_ENTRIES) {
    const normFra = term.fra.toLowerCase().trim();
    frToEwoMap.set(normFra, term.ewo);
    if (term.en) {
      enToEwoMap.set(term.en.toLowerCase().trim(), term.ewo);
    }
    if (term.phonetic) {
      ewoPhoneticMap.set(term.ewo.toLowerCase().trim(), term.phonetic);
    }
  }
  for (const [key, val] of Object.entries(EXTENDED_BANKING_UI_LEXICON)) {
    const norm = key.toLowerCase().trim();
    frToEwoMap.set(norm, val.ewo);
    if (val.phonetic) {
      ewoPhoneticMap.set(val.ewo.toLowerCase().trim(), val.phonetic);
    }
  }
  function lookupEwondoWord(frenchWord) {
    const norm = frenchWord.toLowerCase().trim();
    return frToEwoMap.get(norm) || null;
  }
  function lookupEwondoFromEnglish(englishWord) {
    const norm = englishWord.toLowerCase().trim();
    return enToEwoMap.get(norm) || null;
  }
  function getEwondoPhonetic(ewondoText) {
    const norm = ewondoText.toLowerCase().trim();
    if (ewoPhoneticMap.has(norm)) {
      return ewoPhoneticMap.get(norm);
    }
    return ewondoText.replace(/ɔ́/g, "\xF3").replace(/ɔ̀/g, "\xF2").replace(/ɔ/g, "o").replace(/ɛ́/g, "\xE9").replace(/ɛ̀/g, "\xE8").replace(/ɛ/g, "e").replace(/ə́/g, "\xE9").replace(/ə̀/g, "\xE8").replace(/ə/g, "e").replace(/ë/g, "e").replace(/ŋ/g, "ng").replace(/kp/g, "kp").replace(/gb/g, "gb").replace(/[\u0300-\u036f]/g, "");
  }
  function translateSentenceToEwondo(text) {
    const trimmed = text.trim();
    if (!trimmed) return text;
    const exact = lookupEwondoWord(trimmed) || lookupEwondoFromEnglish(trimmed);
    if (exact) {
      if (trimmed === trimmed.toUpperCase() && trimmed.length > 1) {
        return exact.toUpperCase();
      }
      if (trimmed[0] === trimmed[0].toUpperCase()) {
        return exact.charAt(0).toUpperCase() + exact.slice(1);
      }
      return exact;
    }
    const transferMatch = trimmed.match(
      /(?:transfert|virement|paiement|envoi)\s+(?:de\s+)?(\d[\d\s,.\u00a0]*\s*(?:FCFA|XAF|CFA)?)\s+(?:vers|à|au)\s+([^\-]+)(?:\s*-\s*(.*))?/i
    );
    if (transferMatch) {
      const amount = transferMatch[1].trim();
      const recipient = transferMatch[2].trim();
      const reason = transferMatch[3] ? ` - ${transferMatch[3].trim()}` : "";
      return `L\xF3m m\xF3ni m\xE9 ${amount} \xE9 be ${recipient}${reason}`;
    }
    const balanceMatch = trimmed.match(/(?:solde|balance)\s+(?:est\s+de\s+|de\s+|disponible\s*:?\s*)?(\d[\d\s,.\u00a0]*\s*(?:FCFA|XAF|CFA)?)/i);
    if (balanceMatch && balanceMatch[1]) {
      return `M\xF3ni m\xED ne: ${balanceMatch[1].trim()}`;
    }
    let workingText = trimmed;
    const multiWordKeys = Array.from(frToEwoMap.keys()).filter((k) => k.includes(" ") || k.includes("'")).sort((a, b) => b.length - a.length);
    for (const phrase of multiWordKeys) {
      const escaped = escapeRegExp(phrase);
      const regex = new RegExp(`(?:^|([^\\p{L}\\p{N}]))${escaped}(?=[^\\p{L}\\p{N}]|$)`, "giu");
      if (regex.test(workingText)) {
        const repl = frToEwoMap.get(phrase);
        workingText = workingText.replace(regex, (_m, p1 = "") => {
          return p1 + repl;
        });
      }
    }
    const words = workingText.split(/(\s+|[,;:.!?()\/\-]|(?<=[ldcsqnjm]['’])(?=[\p{L}]))/u);
    const translatedTokens = [];
    for (let i = 0; i < words.length; i++) {
      const token = words[i];
      if (!token) continue;
      if (/^(\s+|[,;:.!?()\/\-])$/.test(token)) {
        translatedTokens.push(token);
        continue;
      }
      if (/^[\d\s.,\u00a0]+$/.test(token) || /^(FCFA|XAF|CFA|EUR|USD|XOF)$/i.test(token)) {
        translatedTokens.push(token);
        continue;
      }
      if (/^[ldcsqnjm]['’]$/i.test(token)) {
        let nextWordIdx = i + 1;
        while (nextWordIdx < words.length && !words[nextWordIdx]) nextWordIdx++;
        if (nextWordIdx < words.length) {
          const nextWord = words[nextWordIdx];
          const matchNext = lookupEwondoWord(nextWord);
          if (matchNext) {
            let result = matchNext;
            if (nextWord === nextWord.toUpperCase() && nextWord.length > 1) {
              result = matchNext.toUpperCase();
            } else if (token[0] === token[0].toUpperCase()) {
              result = matchNext.charAt(0).toUpperCase() + matchNext.slice(1);
            }
            translatedTokens.push(result);
            i = nextWordIdx;
            continue;
          }
        }
        translatedTokens.push(token);
        continue;
      }
      const match = lookupEwondoWord(token) || lookupEwondoFromEnglish(token);
      if (match) {
        let result = match;
        if (token === token.toUpperCase() && token.length > 1) {
          result = match.toUpperCase();
        } else if (token[0] === token[0].toUpperCase()) {
          result = match.charAt(0).toUpperCase() + match.slice(1);
        }
        translatedTokens.push(result);
        continue;
      }
      translatedTokens.push(token);
    }
    return translatedTokens.join("");
  }
  function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  var FIXTURES = {
    // FR -> EN
    "fr:en:Bonjour": "Hello",
    "fr:en:Solde": "Balance",
    "fr:en:Solde disponible": "Available balance",
    "fr:en:Solde disponible (compte principal)": "Available balance (main account)",
    "fr:en:Virement": "Transfer",
    "fr:en:Transfert": "Transfer",
    "fr:en:Effectuer un transfert": "Make a transfer",
    "fr:en:Effectuer un transfert d'argent": "Make a money transfer",
    "fr:en:Confirmer": "Confirm",
    "fr:en:Confirmer le transfert": "Confirm transfer",
    "fr:en:Annuler": "Cancel",
    "fr:en:Frais": "Fees",
    "fr:en:Frais de transfert": "Transfer fees",
    "fr:en:Retrait": "Withdrawal",
    "fr:en:D\xE9p\xF4t": "Deposit",
    "fr:en:B\xE9n\xE9ficiaire": "Beneficiary",
    "fr:en:Transaction": "Transaction",
    "fr:en:Historique des transactions": "Transaction history",
    "fr:en:Num\xE9ro de t\xE9l\xE9phone": "Phone number",
    "fr:en:Num\xE9ro du destinataire": "Recipient mobile number",
    "fr:en:Num\xE9ro du destinataire (Orange / MTN)": "Recipient mobile number (Orange / MTN)",
    "fr:en:Montant": "Amount",
    "fr:en:Montant du transfert": "Transfer amount",
    "fr:en:Montant du transfert (FCFA)": "Transfer amount (FCFA)",
    "fr:en:Motif du paiement": "Payment reason",
    "fr:en:Motif du paiement / r\xE9f\xE9rence": "Payment reason / reference",
    "fr:en:Paiement tontine mensuelle": "Monthly tontine contribution",
    "fr:en:Frais de scolarit\xE9 trimestre 1": "Term 1 tuition fees",
    "fr:en:Facture \xE9lectricit\xE9 #48291": "Electricity bill #48291",
    "fr:en:Achats provisions": "Grocery shopping",
    "fr:en:Frais estim\xE9s: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie": "Estimated fees: 150 FCFA | Zero financial drift guaranteed",
    "fr:en:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Transfer completed successfully! Digital receipt generated.",
    // EN -> FR
    "en:fr:Hello": "Bonjour",
    "en:fr:Balance": "Solde",
    "en:fr:Available balance": "Solde disponible",
    "en:fr:Transfer": "Virement",
    "en:fr:Confirm": "Confirmer",
    "en:fr:Cancel": "Annuler",
    "en:fr:Fees": "Frais",
    "en:fr:Withdrawal": "Retrait",
    "en:fr:Deposit": "D\xE9p\xF4t",
    "en:fr:Beneficiary": "B\xE9n\xE9ficiaire",
    // FR -> EWONDO (ewo-CM / ewo) — Certified NACALCO / Yaoundé I terms
    "fr:ewo-CM:Solde": "M\xF3ni m\xED ne",
    "fr:ewo-CM:Solde disponible": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
    "fr:ewo-CM:Solde disponible (compte principal)": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng (\xE9k\xF3bl\xF3 \xE9t\xE1m)",
    "fr:ewo-CM:Virement": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Transfert": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Effectuer un transfert": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Effectuer un transfert d'argent": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Confirmer": "T\xEDb\xEDli t\xF3b\xF3",
    "fr:ewo-CM:Confirmer le transfert": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
    "fr:ewo-CM:Annuler": "Dz\xE1gb\xE1",
    "fr:ewo-CM:Frais": "M\xF3ni m\xE9bemb\xE1",
    "fr:ewo-CM:Frais de transfert": "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m",
    "fr:ewo-CM:Retrait": "N\xF2ng m\xF3ni",
    "fr:ewo-CM:D\xE9p\xF4t": "W\xF3gl\xF4 m\xF3ni",
    "fr:ewo-CM:B\xE9n\xE9ficiaire": "Ny\xED a n\xF2ng m\xF3ni",
    "fr:ewo-CM:Transaction": "Nl\xF3m m\xF3ni",
    "fr:ewo-CM:Historique des transactions": "Minl\xF3m m\xED ay\xE1a l\xF3t",
    "fr:ewo-CM:Num\xE9ro de t\xE9l\xE9phone": "Nlamb\xE1 telef\xF4n",
    "fr:ewo-CM:Num\xE9ro du destinataire": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni",
    "fr:ewo-CM:Num\xE9ro du destinataire (Orange / MTN)": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni (Orange / MTN)",
    "fr:ewo-CM:Montant": "Abui m\xF3ni",
    "fr:ewo-CM:Montant du transfert": "Abui m\xF3ni y\xE1 nl\xF3m",
    "fr:ewo-CM:Montant du transfert (FCFA)": "Abui m\xF3ni (FCFA)",
    "fr:ewo-CM:Motif du paiement": "Asu dz\xE9",
    "fr:ewo-CM:Motif du paiement / r\xE9f\xE9rence": "Asu dz\xE9 / nkat",
    "fr:ewo-CM:Paiement tontine mensuelle": "M\xF3ni ts\u0254\u0301 ng\u0254\u0301n",
    "fr:ewo-CM:Frais de scolarit\xE9 trimestre 1": "M\xF3ni suk\xFA ng\u0254\u0301n 1",
    "fr:ewo-CM:Facture \xE9lectricit\xE9 #48291": "Kalad\xED \xE9lekts\xEDki #48291",
    "fr:ewo-CM:Achats provisions": "K\xF9s bid\xED",
    "fr:ewo-CM:Frais estim\xE9s: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie": "M\xF3ni m\xE9bemb\xE1: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie",
    "fr:ewo-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa ! Kalad\xED nl\xE1man ay\xE1a f\xF3b\xE1n.",
    // EN -> EWONDO
    "en:ewo-CM:Balance": "M\xF3ni m\xED ne",
    "en:ewo-CM:Available balance": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
    "en:ewo-CM:Transfer": "L\xF3m m\xF3ni",
    "en:ewo-CM:Confirm": "T\xEDb\xEDli t\xF3b\xF3",
    "en:ewo-CM:Cancel": "Dz\xE1gb\xE1",
    "en:ewo-CM:Fees": "M\xF3ni m\xE9bemb\xE1",
    "en:ewo-CM:Beneficiary": "Ny\xED a n\xF2ng m\xF3ni"
  };
  for (const [key, val] of Object.entries(FIXTURES)) {
    if (key.includes("ewo-CM")) {
      FIXTURES[key.replace("ewo-CM", "ewo")] = val;
    }
  }

  // src/content.ts
  var EwondoSpeechPlayer = class {
    isPlaying = false;
    audioCtx = null;
    onEndCallback = null;
    speak(text, phonetic, onEnd) {
      if (typeof window === "undefined") return;
      this.stop();
      this.onEndCallback = onEnd || null;
      const spokenText = phonetic || getEwondoPhonetic(text) || text;
      if ("speechSynthesis" in window) {
        const utterance = new SpeechSynthesisUtterance(spokenText);
        utterance.rate = 0.88;
        utterance.pitch = 1;
        const voices = window.speechSynthesis.getVoices();
        const voice = voices.find((v) => v.lang.startsWith("fr")) || voices[0];
        if (voice) {
          utterance.voice = voice;
        }
        utterance.onstart = () => {
          this.isPlaying = true;
        };
        utterance.onend = () => {
          this.isPlaying = false;
          if (this.onEndCallback) {
            this.onEndCallback();
            this.onEndCallback = null;
          }
        };
        utterance.onerror = () => {
          this.isPlaying = false;
          if (this.onEndCallback) {
            this.onEndCallback();
            this.onEndCallback = null;
          }
        };
        window.speechSynthesis.speak(utterance);
      } else {
        this.playAcousticChime();
        if (this.onEndCallback) {
          setTimeout(() => {
            if (this.onEndCallback) this.onEndCallback();
          }, 400);
        }
      }
    }
    pause() {
      if (typeof window !== "undefined" && "speechSynthesis" in window && window.speechSynthesis.speaking) {
        window.speechSynthesis.pause();
      }
    }
    resume() {
      if (typeof window !== "undefined" && "speechSynthesis" in window && window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
    stop() {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      this.isPlaying = false;
      if (this.onEndCallback) {
        this.onEndCallback();
        this.onEndCallback = null;
      }
    }
    playAcousticChime() {
      try {
        const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtxClass) return;
        if (!this.audioCtx) this.audioCtx = new AudioCtxClass();
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.frequency.setValueAtTime(440, this.audioCtx.currentTime);
        gain.gain.setValueAtTime(0.15, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(1e-3, this.audioCtx.currentTime + 0.35);
        osc.start();
        osc.stop(this.audioCtx.currentTime + 0.35);
      } catch {
      }
    }
  };
  var ExtensionAssistant = class {
    container = null;
    shadow = null;
    originalTextMap = /* @__PURE__ */ new Map();
    isPageTranslated = false;
    currentTargetLang = "ewo-CM";
    currentSourceLang = "fr";
    isOpen = false;
    isTouchSpeakEnabled = false;
    speechPlayer = new EwondoSpeechPlayer();
    onMouseUpHandler = null;
    onRuntimeMessageHandler = null;
    onMouseOverHandler = null;
    onMouseOutHandler = null;
    onClickElementHandler = null;
    onTouchEndHandler = null;
    currentHoveredEl = null;
    currentSpokenEl = null;
    constructor() {
      this.init();
    }
    init() {
      if (document.getElementById("linguabridge-extension-root")) return;
      this.container = document.createElement("div");
      this.container.id = "linguabridge-extension-root";
      this.container.style.all = "initial";
      this.container.style.position = "fixed";
      this.container.style.bottom = "24px";
      this.container.style.right = "24px";
      this.container.style.zIndex = "2147483646";
      this.shadow = this.container.attachShadow({ mode: "open" });
      this.render();
      document.body.appendChild(this.container);
      this.setupListeners();
    }
    setupListeners() {
      this.onMouseUpHandler = () => {
        const selection = window.getSelection();
        const text = selection?.toString().trim();
        if (!text || text.length < 2) return;
        this.translateSelectedText(text);
      };
      document.addEventListener("mouseup", this.onMouseUpHandler);
      if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
        this.onRuntimeMessageHandler = (msg) => {
          if (msg.type === "CONTEXT_MENU_TRANSLATE" && msg.text) {
            this.isOpen = true;
            this.render();
            this.translateSelectedText(msg.text);
          } else if (msg.type === "POPUP_TRANSLATE_PAGE") {
            if (msg.targetLang) this.currentTargetLang = msg.targetLang;
            this.translateFullPage();
          } else if (msg.type === "POPUP_TOGGLE_TOUCH_SPEAK") {
            this.toggleTouchSpeakMode();
          }
        };
        chrome.runtime.onMessage.addListener(this.onRuntimeMessageHandler);
      }
      this.onMouseOverHandler = (e) => {
        if (!this.isTouchSpeakEnabled) return;
        const target = e.target;
        if (!target || target.closest("#linguabridge-extension-root")) return;
        if (["script", "style", "code", "pre", "noscript"].includes(target.tagName.toLowerCase())) return;
        if (this.currentHoveredEl && this.currentHoveredEl !== target && this.currentHoveredEl !== this.currentSpokenEl) {
          this.currentHoveredEl.style.outline = "";
        }
        this.currentHoveredEl = target;
        target.style.outline = "2px solid #16a34a";
        target.style.outlineOffset = "2px";
        target.style.cursor = "pointer";
      };
      this.onMouseOutHandler = (e) => {
        if (!this.isTouchSpeakEnabled) return;
        const target = e.target;
        if (target && target === this.currentHoveredEl && target !== this.currentSpokenEl) {
          target.style.outline = "";
          target.style.cursor = "";
          this.currentHoveredEl = null;
        }
      };
      this.onClickElementHandler = (e) => {
        if (!this.isTouchSpeakEnabled) return;
        const target = e.target;
        if (!target || target.closest("#linguabridge-extension-root")) return;
        const text = target.innerText?.trim() || target.textContent?.trim();
        if (!text) return;
        e.preventDefault();
        e.stopPropagation();
        this.speakTextSection(text, target);
      };
      this.onTouchEndHandler = (e) => {
        if (!this.isTouchSpeakEnabled) return;
        const touch = e.changedTouches[0];
        if (!touch) return;
        const target = document.elementFromPoint(touch.clientX, touch.clientY);
        if (!target || target.closest("#linguabridge-extension-root")) return;
        const text = target.innerText?.trim() || target.textContent?.trim();
        if (!text) return;
        e.preventDefault();
        this.speakTextSection(text, target);
      };
      document.addEventListener("mouseover", this.onMouseOverHandler, true);
      document.addEventListener("mouseout", this.onMouseOutHandler, true);
      document.addEventListener("click", this.onClickElementHandler, true);
      document.addEventListener("touchend", this.onTouchEndHandler, { capture: true, passive: false });
    }
    toggleTouchSpeakMode() {
      this.isTouchSpeakEnabled = !this.isTouchSpeakEnabled;
      if (!this.isTouchSpeakEnabled) {
        if (this.currentHoveredEl) {
          this.currentHoveredEl.style.outline = "";
          this.currentHoveredEl.style.cursor = "";
          this.currentHoveredEl = null;
        }
        if (this.currentSpokenEl) {
          this.currentSpokenEl.style.outline = "";
          this.currentSpokenEl = null;
        }
        this.speechPlayer.stop();
        const bar = this.shadow?.getElementById("audio-bar");
        if (bar) bar.style.display = "none";
      }
      this.render();
    }
    speakTextSection(rawText, targetEl) {
      let ewondoText = rawText;
      if (this.currentTargetLang.includes("ewo")) {
        ewondoText = translateSentenceToEwondo(rawText);
      }
      const phonetic = getEwondoPhonetic(ewondoText);
      if (this.currentSpokenEl && this.currentSpokenEl !== targetEl) {
        this.currentSpokenEl.style.outline = "";
      }
      if (targetEl) {
        this.currentSpokenEl = targetEl;
        targetEl.style.outline = "2px solid #16a34a";
        targetEl.style.outlineOffset = "2px";
      }
      this.speechPlayer.speak(ewondoText, phonetic, () => {
        if (this.currentSpokenEl) {
          this.currentSpokenEl.style.outline = "";
          this.currentSpokenEl = null;
        }
      });
      this.showAudioFloatingBar(ewondoText, phonetic);
    }
    showAudioFloatingBar(text, phonetic) {
      const bar = this.shadow?.getElementById("audio-bar");
      if (!bar) return;
      bar.style.display = "flex";
      const textEl = this.shadow?.getElementById("audio-spoken-text");
      const phonEl = this.shadow?.getElementById("audio-phonetic");
      if (textEl) textEl.textContent = text;
      if (phonEl) phonEl.textContent = phonetic ? `[${phonetic}]` : "";
    }
    async translateSelectedText(text) {
      const box = this.shadow?.getElementById("selection-preview");
      if (!box) return;
      box.style.display = "block";
      box.innerHTML = `<div style="color: #4b5563; font-size: 11px;">Traduction en cours...</div>`;
      const handleSuccess = (res) => {
        const phonetic = res.phonetic || getEwondoPhonetic(res.translatedText);
        box.innerHTML = `
        <div style="font-weight: 600; margin-bottom: 2px; color: #111827;">S\xE9lectionn\xE9 : "${text}"</div>
        <div style="color: #15803d; font-weight: 700; font-size: 14px;">"${res.translatedText}"</div>
        ${phonetic ? `<div style="color: #4b5563; font-size: 11px; margin-top: 2px; font-style: italic;">Prononciation : [${phonetic}]</div>` : ""}
        <div style="margin-top: 6px; display: flex; gap: 8px;">
          <button id="btn-speak-selection" style="background: #16a34a; color: #ffffff; border: 1px solid #15803d; padding: 6px 12px; border-radius: 4px; font-size: 12px; font-weight: 600; cursor: pointer;">
            \u{1F50A} \xC9couter en langue maternelle
          </button>
        </div>
        ${res.warnings.length > 0 ? `<div style="margin-top: 6px; padding: 6px 8px; background: #f9fafb; border: 1px solid #d1d5db; border-radius: 4px; color: #111827; font-size: 11px;">
                \u{1F6E1}\uFE0F <strong>Garde financi\xE8re :</strong> ${res.warnings.join(", ")}
              </div>` : ""}
      `;
        this.shadow?.getElementById("btn-speak-selection")?.addEventListener("click", () => {
          this.speechPlayer.speak(res.translatedText, phonetic);
        });
      };
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage(
          {
            type: "TRANSLATE_TEXT",
            text,
            sourceLang: this.currentSourceLang,
            targetLang: this.currentTargetLang,
            domain: "financial"
          },
          (response) => {
            if (response?.success && response.result) {
              handleSuccess(response.result);
            } else {
              const localTrans = translateSentenceToEwondo(text);
              handleSuccess({
                id: "local-selection",
                originalText: text,
                translatedText: localTrans,
                sourceLang: this.currentSourceLang,
                targetLang: this.currentTargetLang,
                provider: "apertium-national-lexicon",
                status: "success",
                cacheStatus: "miss",
                warnings: [],
                latencyMs: 1,
                speechAvailable: true,
                phonetic: getEwondoPhonetic(localTrans)
              });
            }
          }
        );
      } else {
        const localTrans = translateSentenceToEwondo(text);
        handleSuccess({
          id: "local-test",
          originalText: text,
          translatedText: localTrans,
          sourceLang: this.currentSourceLang,
          targetLang: this.currentTargetLang,
          provider: "apertium-national-lexicon",
          status: "success",
          cacheStatus: "miss",
          warnings: [],
          latencyMs: 1,
          speechAvailable: true,
          phonetic: getEwondoPhonetic(localTrans)
        });
      }
    }
    translateFullPage() {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          if (!node.textContent || !node.textContent.trim()) return NodeFilter.FILTER_REJECT;
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName.toLowerCase();
          if (["script", "style", "code", "pre", "noscript"].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.closest("#linguabridge-extension-root")) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      const textNodes = [];
      let curr = walker.nextNode();
      while (curr) {
        if (!this.originalTextMap.has(curr)) {
          this.originalTextMap.set(curr, curr.textContent || "");
        }
        const sourceText = this.originalTextMap.get(curr) || curr.textContent || "";
        const trimmed = sourceText.trim();
        if (trimmed) {
          const match = sourceText.match(/^(\s*)([\s\S]*?)(\s*)$/);
          const leading = match ? match[1] : "";
          const trailing = match ? match[3] : "";
          textNodes.push({ node: curr, text: trimmed, leading, trailing });
        }
        curr = walker.nextNode();
      }
      if (textNodes.length === 0) return;
      const applyTranslations = (results) => {
        results.forEach((r, idx) => {
          const item = textNodes[idx];
          if (item && r.translatedText) {
            item.node.textContent = item.leading + r.translatedText + item.trailing;
          }
        });
        this.isPageTranslated = true;
        this.render();
      };
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        const items = textNodes.map((item) => ({
          text: item.text,
          sourceLang: this.currentSourceLang,
          targetLang: this.currentTargetLang,
          domain: "financial"
        }));
        chrome.runtime.sendMessage({ type: "TRANSLATE_BATCH", items }, (res) => {
          if (res?.success && res.results) {
            applyTranslations(res.results);
          } else {
            const results = items.map((i, idx) => ({
              id: `local-batch-${idx}`,
              originalText: i.text,
              translatedText: translateSentenceToEwondo(i.text),
              sourceLang: i.sourceLang,
              targetLang: i.targetLang,
              provider: "apertium-national-lexicon",
              status: "success",
              cacheStatus: "miss",
              warnings: [],
              latencyMs: 1,
              speechAvailable: true
            }));
            applyTranslations(results);
          }
        });
      } else {
        const results = textNodes.map((i, idx) => ({
          id: `local-test-${idx}`,
          originalText: i.text,
          translatedText: translateSentenceToEwondo(i.text),
          sourceLang: this.currentSourceLang,
          targetLang: this.currentTargetLang,
          provider: "apertium-national-lexicon",
          status: "success",
          cacheStatus: "miss",
          warnings: [],
          latencyMs: 1,
          speechAvailable: true
        }));
        applyTranslations(results);
      }
    }
    restorePage() {
      for (const [node, original] of this.originalTextMap.entries()) {
        node.textContent = original;
      }
      this.isPageTranslated = false;
      this.render();
    }
    render() {
      if (!this.shadow) return;
      this.shadow.innerHTML = `
      <style>
        .assistant-btn {
          width: 52px;
          height: 52px;
          border-radius: 26px;
          background: #16a34a;
          color: #ffffff;
          border: 1px solid #15803d;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
          transition: background 0.15s ease, transform 0.15s ease;
        }
        .assistant-btn:hover {
          transform: scale(1.04);
          background: #15803d;
        }
        .assistant-btn.active-speak {
          background: #15803d;
          border: 2px solid #ffffff;
          box-shadow: 0 4px 14px rgba(0, 0, 0, 0.25);
        }
        .card {
          display: ${this.isOpen ? "block" : "none"};
          position: absolute;
          bottom: 64px;
          right: 0;
          width: 320px;
          background: #ffffff;
          border-radius: 8px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
          border: 1px solid #e5e7eb;
          padding: 16px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          font-size: 13px;
          color: #111827;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-weight: 700;
          font-size: 14px;
          border-bottom: 1px solid #f3f4f6;
          padding-bottom: 8px;
          margin-bottom: 10px;
        }
        .badge-nat {
          font-size: 11px;
          font-weight: 600;
          background: #f0fdf4;
          color: #15803d;
          border: 1px solid #bbf7d0;
          padding: 2px 6px;
          border-radius: 4px;
        }
        .btn-action {
          width: 100%;
          padding: 9px 12px;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          border: 1px solid #d1d5db;
          background: #ffffff;
          color: #111827;
          margin-top: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          box-sizing: border-box;
          transition: background 0.15s ease;
        }
        .btn-action:hover {
          background: #f9fafb;
        }
        .btn-action.primary {
          background: #16a34a;
          color: #ffffff;
          border-color: #16a34a;
        }
        .btn-action.primary:hover {
          background: #15803d;
        }
        .btn-action.speak-toggle {
          background: ${this.isTouchSpeakEnabled ? "#15803d" : "#f9fafb"};
          color: ${this.isTouchSpeakEnabled ? "#ffffff" : "#111827"};
          border-color: ${this.isTouchSpeakEnabled ? "#15803d" : "#d1d5db"};
        }
        .speak-hint {
          display: ${this.isTouchSpeakEnabled ? "block" : "none"};
          margin-top: 8px;
          padding: 8px;
          background: #f0fdf4;
          border: 1px solid #bbf7d0;
          border-radius: 6px;
          color: #15803d;
          font-size: 11px;
          line-height: 1.4;
        }
        .preview-box {
          display: none;
          margin-top: 10px;
          padding: 10px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          border-radius: 6px;
          font-size: 12px;
        }
        /* Floating Audio Player Subtitle Bar */
        .audio-bar {
          display: none;
          position: fixed;
          bottom: 24px;
          left: 50%;
          transform: translateX(-50%);
          background: #111827;
          color: #ffffff;
          border-radius: 8px;
          padding: 10px 16px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.25);
          align-items: center;
          gap: 12px;
          z-index: 2147483647;
          max-width: 90vw;
          border: 1px solid #374151;
        }
        .audio-btn {
          background: #16a34a;
          color: #ffffff;
          border: none;
          padding: 5px 10px;
          border-radius: 4px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
        }
        .audio-btn:hover {
          background: #15803d;
        }
        .audio-btn.stop-btn {
          background: #374151;
          color: #ffffff;
        }
        .audio-btn.stop-btn:hover {
          background: #4b5563;
        }
      </style>

      <div class="card">
        <div class="header">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span>LinguaBridge</span>
            <span class="badge-nat">\u{1F1E8}\u{1F1F2} K\xF3b\u0254\u0301 Ewondo</span>
          </div>
          <button id="close-card" style="background:none;border:none;cursor:pointer;color:#6b7280;font-size:16px;">\u2715</button>
        </div>

        <div style="margin-bottom: 8px;">
          <label style="font-weight: 600; font-size: 12px; color: #4b5563;">Langue cible :</label>
          <select id="target-lang" style="width: 100%; padding: 7px; border-radius: 6px; border: 1px solid #d1d5db; margin-top: 4px; font-size: 13px; font-weight: 600; background: #ffffff;">
            <option value="ewo-CM" ${this.currentTargetLang === "ewo-CM" ? "selected" : ""}>\u{1F1E8}\u{1F1F2} K\xF3b\u0254\u0301 Ewondo (Langue Maternelle)</option>
            <option value="fr" ${this.currentTargetLang === "fr" ? "selected" : ""}>\u{1F1EB}\u{1F1F7} Fran\xE7ais</option>
            <option value="en" ${this.currentTargetLang === "en" ? "selected" : ""}>\u{1F1EC}\u{1F1E7} English</option>
          </select>
        </div>

        <div style="margin-top: 10px;">
          ${this.isPageTranslated ? `<button class="btn-action" id="btn-restore"><span>\u21A9\uFE0F</span><span>Restaurer le texte d'origine</span></button>` : `<button class="btn-action primary" id="btn-translate-page"><span>\u{1F310}</span><span>Traduire toute la page</span></button>`}
        </div>

        <button class="btn-action speak-toggle" id="btn-toggle-speak">
          <span>\u{1F50A}</span>
          <span>${this.isTouchSpeakEnabled ? "D\xE9sactiver la lecture au toucher" : "Activer la lecture au toucher"}</span>
        </button>

        <div class="speak-hint">
          \u{1F449} <strong>Mode vocal actif :</strong> Touchez ou cliquez sur n'importe quel \xE9l\xE9ment pour l'\xE9couter en langue maternelle.
        </div>

        <div id="selection-preview" class="preview-box"></div>
      </div>

      <button class="assistant-btn ${this.isTouchSpeakEnabled ? "active-speak" : ""}" id="btn-toggle" title="LinguaBridge - Accessibilit\xE9 en Langue Maternelle">
        ${this.isTouchSpeakEnabled ? "\u{1F50A}" : "\u{1F310}"}
      </button>

      <!-- Bottom floating speech indicator bar -->
      <div id="audio-bar" class="audio-bar">
        <span style="font-size: 16px;">\u{1F50A}</span>
        <div style="max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
          <div id="audio-spoken-text" style="font-weight: 700; font-size: 13px; color: #ffffff;"></div>
          <div id="audio-phonetic" style="font-size: 11px; color: #86efac; font-style: italic;"></div>
        </div>
        <button class="audio-btn" id="audio-replay">Rejouer</button>
        <button class="audio-btn stop-btn" id="audio-stop">Arr\xEAter</button>
        <button id="audio-close" style="background:none;border:none;color:#9ca3af;cursor:pointer;font-size:14px;padding:2px 6px;">\u2715</button>
      </div>
    `;
      this.shadow.getElementById("btn-toggle")?.addEventListener("click", () => {
        this.isOpen = !this.isOpen;
        this.render();
      });
      this.shadow.getElementById("close-card")?.addEventListener("click", () => {
        this.isOpen = false;
        this.render();
      });
      this.shadow.getElementById("btn-translate-page")?.addEventListener("click", () => {
        this.translateFullPage();
      });
      this.shadow.getElementById("btn-restore")?.addEventListener("click", () => {
        this.restorePage();
      });
      this.shadow.getElementById("btn-toggle-speak")?.addEventListener("click", () => {
        this.toggleTouchSpeakMode();
      });
      this.shadow.getElementById("target-lang")?.addEventListener("change", (e) => {
        this.currentTargetLang = e.target.value;
        if (this.isPageTranslated) {
          this.translateFullPage();
        }
      });
      this.shadow.getElementById("audio-replay")?.addEventListener("click", () => {
        const text = this.shadow?.getElementById("audio-spoken-text")?.textContent || "";
        const phonetic = this.shadow?.getElementById("audio-phonetic")?.textContent?.replace(/[\[\]]/g, "") || "";
        this.speechPlayer.speak(text, phonetic);
      });
      this.shadow.getElementById("audio-stop")?.addEventListener("click", () => {
        this.speechPlayer.stop();
      });
      this.shadow.getElementById("audio-close")?.addEventListener("click", () => {
        this.speechPlayer.stop();
        const bar = this.shadow?.getElementById("audio-bar");
        if (bar) bar.style.display = "none";
      });
    }
    destroy() {
      this.speechPlayer.stop();
      if (this.isPageTranslated) {
        this.restorePage();
      }
      if (this.currentHoveredEl) {
        this.currentHoveredEl.style.outline = "";
        this.currentHoveredEl.style.cursor = "";
        this.currentHoveredEl = null;
      }
      if (this.currentSpokenEl) {
        this.currentSpokenEl.style.outline = "";
        this.currentSpokenEl = null;
      }
      if (this.container && this.container.parentNode) {
        this.container.parentNode.removeChild(this.container);
        this.container = null;
        this.shadow = null;
      }
      if (this.onMouseUpHandler) {
        document.removeEventListener("mouseup", this.onMouseUpHandler);
        this.onMouseUpHandler = null;
      }
      if (this.onRuntimeMessageHandler && typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
        chrome.runtime.onMessage.removeListener(this.onRuntimeMessageHandler);
        this.onRuntimeMessageHandler = null;
      }
      if (this.onMouseOverHandler) {
        document.removeEventListener("mouseover", this.onMouseOverHandler, true);
        this.onMouseOverHandler = null;
      }
      if (this.onMouseOutHandler) {
        document.removeEventListener("mouseout", this.onMouseOutHandler, true);
        this.onMouseOutHandler = null;
      }
      if (this.onClickElementHandler) {
        document.removeEventListener("click", this.onClickElementHandler, true);
        this.onClickElementHandler = null;
      }
      if (this.onTouchEndHandler) {
        document.removeEventListener("touchend", this.onTouchEndHandler, true);
        this.onTouchEndHandler = null;
      }
    }
  };
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    new ExtensionAssistant();
  }
})();
