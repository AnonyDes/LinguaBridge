"use strict";
(() => {
  // ../../packages/widget/src/banking-engine.ts
  function extractFinancialEntities(text) {
    const entities = [];
    const seen = /* @__PURE__ */ new Set();
    const amountRegex = /\b(\d[\d\s,\.]*(?:\s*\d{3})*|\d+)\s*(FCFA|XAF|CFA|F|EUR|USD)\b/gi;
    let match;
    while ((match = amountRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "amount",
          raw,
          normalized: raw.replace(/\s+/g, " ").toUpperCase()
        });
      }
    }
    const phoneRegex = /(?:\+?237\s*)?[6-9]\d{2}[\s.-]?\d{3}[\s.-]?\d{3}\b/g;
    while ((match = phoneRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "phone",
          raw,
          normalized: raw.replace(/[\s.-]/g, "")
        });
      }
    }
    const refRegex = /\b(?:TXN|REF|ID|ACC)-[A-Z0-9]{4,16}\b/gi;
    while ((match = refRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "reference",
          raw,
          normalized: raw.toUpperCase()
        });
      }
    }
    return entities;
  }
  function detectBankingIntent(query) {
    const lower = query.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (lower.includes("secur") || lower.includes("pin") || lower.includes("otp") || lower.includes("code") || lower.includes("perdu") || lower.includes("vol") || lower.includes("arnaque") || lower.includes("fraude") || lower.includes("bloqu")) {
      return "security";
    }
    if (lower.includes("envoy") || lower.includes("transfer") || lower.includes("virement") || lower.includes("send") || lower.includes("payer") || lower.includes("loma") || lower.includes("neldu") || lower.includes("tura") || lower.includes("s\u0259nd")) {
      return "transfer";
    }
    if (lower.includes("frais") || lower.includes("retrait") || lower.includes("distributeur") || lower.includes("gab") || lower.includes("atm") || lower.includes("cout") || lower.includes("tarif") || lower.includes("fee") || lower.includes("charge") || lower.includes("hakke")) {
      return "fees";
    }
    if (lower.includes("solde") || lower.includes("balance") || lower.includes("compte") || lower.includes("reste") || lower.includes("combien") || lower.includes("kudi") || lower.includes("ceede") || lower.includes("moni")) {
      return "balance";
    }
    return "general";
  }
  function generateBankingResponse(query, targetLang = "ewo-CM") {
    const intent = detectBankingIntent(query);
    const entities = extractFinancialEntities(query);
    let text = "";
    let phonetic = "";
    const langCode = targetLang.toLowerCase();
    if (langCode.startsWith("ewo")) {
      switch (intent) {
        case "transfer":
          text = "Asu ya nloman m\xF3ni, kele va 'Virement', nyi\xF1i nomb\xE1 ya nlemba ai abim m\xF3ni, tsin\xED k\xF3d PIN wo\xE9. M\xF3ni mak\xE9 nlem-nlem a nda m\xF4t nu.";
          phonetic = "Asou ya nloman moni, kele va Virement, nyini nomba ya nlemba ai abim moni, tsini kod PIN woe. Moni make nlem-nlem.";
          break;
        case "balance":
          text = "M\xF3ni m\xED ne wo a k\xF4mba: F\xE1an etere o ne abim m\xF3ni ya nlemba. K\xF3d PIN wu\xE9 \xE9 ne mb\xF3l asu ya ngeng \xF3se.";
          phonetic = "Moni mi ne wo a komba: Faan etere o ne abim moni ya nlemba. Kod PIN wue e ne mbol asu ya ngeng ose.";
          break;
        case "fees":
          text = "Frais ya nk\xF3b\xF3l m\xF3ni a GAB / Agence: 1% ya abim m\xF3ni, ke ve 500 FCFA a nsisin. Nk\xF3b\xF3l m\xF3ni \xE9 ne 0 FCFA a Guichet nlemba.";
          phonetic = "Frais ya nkobol moni a GAB / Agence: un pour cent ya abim moni, ke ve 500 FCFA a nsisin. Nkobol moni e ne zero FCFA a Guichet nlemba.";
          break;
        case "security":
          text = "Mfi ya k\xF4mba: Te va k\xF3d PIN wu\xE9 ke nomb\xE1 OTP ai m\xF4t teke teke. Banque \xE9 se laa yi wo k\xF3d wu\xE9 a t\xE9lefon!";
          phonetic = "Mfi ya komba: Te va kod PIN wue ke nomba OTP ai mot teke teke. Banque e se laa yi wo kod wue a telefon!";
          break;
        default:
          text = "Mb\xF3lani! Me ne assistant bancaire LinguaBridge. Me ne wo vol\xF3 asu ya nloman m\xF3ni, solde, nk\xF3b\xF3l m\xF3ni ai mbamba k\xF4mba.";
          phonetic = "Mbolani! Me ne assistant bancaire LinguaBridge. Me ne wo volo asu ya nloman moni, solde, nkobol moni ai mbamba komba.";
          break;
      }
    } else if (langCode.startsWith("fuv")) {
      switch (intent) {
        case "transfer":
          text = "Ngam neldugo ceede, jahda to 'Neldugo', mbinnda lamba ja\u0253oowo e limoore ceede, katin ndokka PIN maada. Ceede \u0257en nylan jonta.";
          phonetic = "Ngam neldugo tcheede, jahda to Neldugo, mbinnda lamba jaboowo e limoore tcheede, katin ndokka PIN maada. Tcheede den nylan jonta.";
          break;
        case "balance":
          text = "Ceede maada heddii\u0257e: A\u0257a jogii limoore ceede maada haa ashirgol maada. Koodi maada deenaama jam.";
          phonetic = "Tcheede maada heddiide: Ada jogii limoore tcheede maada haa ashirgol maada. Koodi maada deenaama jam.";
          break;
        case "fees":
          text = "Hakke ittego ceede haa GAB: 1% e dow limoore itteteende, ko fam\u0257i fuu 500 FCFA. Ittego haa suudu banki walaa hakke (0 FCFA).";
          phonetic = "Hakke ittego tcheede haa GAB: go'o pour cent e dow limoore itteteende, ko famdi fuu 500 FCFA. Ittego haa suudu banki walaa hakke zero FCFA.";
          break;
        case "security":
          text = "Deenal ashirgol maada: Taa hokku koodi maada sirri ko lamba OTP to hay gooto. Banki \u0257on \u01B4amataa sirri maada sam!";
          phonetic = "Deenal ashirgol maada: Taa hokku koodi maada sirri ko lamba OTP to hay gooto. Banki don yamataa sirri maada sam!";
          break;
        default:
          text = "Jam waali! Mi\u0257o wallu ma e golle banki: neldugo ceede, limol ceede, hakke ittego e deenal kisndam.";
          phonetic = "Jam waali! Mido wallu ma e golle banki: neldugo tcheede, limol tcheede, hakke ittego e deenal kisndam.";
          break;
      }
    } else if (langCode.startsWith("hau")) {
      switch (intent) {
        case "transfer":
          text = "Don tura kudi, je shafin 'Aika Kudi', sa lambar asusun mai karba da adadin kudi, sannan ka tabbatar da lambar PIN. Kudin zasu isa nan take.";
          phonetic = "Don toura koudi, je shafin Aika Kudi, sa lambar asusun mai karba da adadin kudi, sannan ka tabbatar da lambar PIN. Kudin zasu isa nan take.";
          break;
        case "balance":
          text = "Sauran kudin ka a asusu: Zaka iya duba adadin kudin ka a kowane lokaci. Lambar sirrinka tana nan a kiyaye.";
          phonetic = "Saouran koudin ka a asousou: Zaka iya douba adadin kudin ka a kowane lokatsi. Lambar sirrinka tana nan a kiyaye.";
          break;
        case "fees":
          text = "Kudin cire kudi a ATM: Kashi 1% na adadin kudi, ko a kalla 500 FCFA. Cire kudi a ofishin banki kyauta ne (0 FCFA).";
          phonetic = "Kudin tsire kudi a ATM: Kashi 1% na adadin kudi, ko a kalla 500 FCFA. Tsire kudi a ofishin banki kyauta ne.";
          break;
        case "security":
          text = "Kariyar asusunka: Kada ka taba bayyana lambar PIN ko lambar sirri ta OTP ga kowa. Banki ba zai taba tambayar lambar sirrinka ta waya ba!";
          phonetic = "Kariyar asusunka: Kada ka taba bayyana lambar PIN ko lambar sirri ta OTP ga kowa. Banki ba zai taba tambayar lambar sirrinka ta waya ba!";
          break;
        default:
          text = "Sannu! Ni ne mataimakin banki na LinguaBridge. Zan taimake ka da aika kudi, duba asusu, da kiyaye kudadenka.";
          phonetic = "Sannu! Ni ne mataimakin banki na LinguaBridge. Zan taimake ka da aika kudi, duba asusu, da kiyaye kudadenka.";
          break;
      }
    } else if (langCode.startsWith("knc")) {
      switch (intent) {
        case "transfer":
          text = "K\u0259la k\u0259la ci kudi s\u0259ndoye: Fuwuro 'Cidiya Kudi' ro lewone, lamba k\u0259la maiye kuru lamba kudiye ruwone, kuru lambaro PIN-nam cukkuro. Kudiye cidiya karrin fannoto.";
          phonetic = "Kala kala tsi koudi sandoye: Fouworro Tsidiya Kudi ro lewone, lamba kala maiye kuru lamba kudiye, kuru lambaro PIN-nam tsoukkouro. Kudiye tsidiya karrin fannoto.";
          break;
        case "balance":
          text = "Kudi asusun\u0259mye b\u0259lindi: Adadu kudiye nam kuru asusun\u0259mye k\u0259l\u0259wanz\u0259 kalkallo shidoni. Lambaro sirriye garuwanz\u0259 t\u0259rnoma.";
          phonetic = "Koudi asousounamye balindi: Adadou kudiye nam kuru asousounamye kalawanza kalkallo shidoni. Lambaro sirriye garuwanza tarnoma.";
          break;
        case "fees":
          text = "Kudi k\u0259la ATM-ro s\u0259ndoye: 1% k\u0259la adadu kudiye, ko 500 FCFA ganawo. Bankinro kudi fidoye kudi bawo (0 FCFA).";
          phonetic = "Koudi kala ATM-ro sandoye: fal pour cent kala adadou kudiye, ko 500 FCFA ganawo. Bankinro kudi fidoye kudi bawo zero FCFA.";
          break;
        case "security":
          text = "Lafiya asusun\u0259mye: Lambaro PIN-nam kuru OTP-nam nduro yaye k\u0259mbuwone. Bankiye lambaro sirrin\u0259m k\u0259la wayabe kura wande!";
          phonetic = "Lafiya asousounamye: Lambaro PIN-nam kuru OTP-nam ndouro yaye kambuwone. Bankiye lambaro sirrinam kala wayabe kura wande!";
          break;
        default:
          text = "Wushe wushe! N\u0259m zaye assistant bankiye LinguaBridge. Kudi s\u0259ndoye, adadu asusuye, kuru k\u0259la lafiya asusuyero kpanza k\u0259ljin.";
          phonetic = "Wushe wushe! Nam zaye assistant bankiye LinguaBridge. Kudi sandoye, adadu asusuye, kuru kala lafiya asusuyero kpanza kaljin.";
          break;
      }
    } else if (langCode.startsWith("pcm")) {
      switch (intent) {
        case "transfer":
          text = "To send money, go to 'Transfer', put the person account number and amount, then enter your secret PIN. The money go enter one time without wahala.";
          phonetic = "To send moni, go to Transfer, put di pesin akownt nomba and amownt, den enta ya secret PIN. Di moni go enta wan taym witawt wahala.";
          break;
        case "balance":
          text = "Your account balance: You fit check your money anytime inside the app. Your secret PIN code dey protected strong strong.";
          phonetic = "Ya akownt balans: Yu fit chek ya moni enitaym insayd di app. Ya sikret PIN kod dey prot\xE8kted stron stron.";
          break;
        case "fees":
          text = "Withdrawal charges for ATM: 1% of the money, minimum 500 FCFA. To withdraw inside bank branch na completely free (0 FCFA).";
          phonetic = "Widrowal chajiz fo ATM: wan pesent of di moni, minimom 500 FCFA. To widrow insayd bank branch na komplitli fri zero FCFA.";
          break;
        case "security":
          text = "Security for your account: Make you never give your secret PIN or OTP code to any person for this world. Bank go never ask you your PIN for phone!";
          phonetic = "Sekyuriti fo ya akownt: Mek yu neva giv ya sikret PIN o OTP kod to eni pesin fo dis wol. Bank go neva ask yu ya PIN fo fon!";
          break;
        default:
          text = "How far! Na me be your LinguaBridge Bank Assistant. I fit help you send money, check balance, check charges, and secure your account.";
          phonetic = "Haw fa! Na mi bi ya LingwaBrij Bank Asistant. Ay fit help yu send moni, chek balans, chek chajiz, and sekyur ya akownt.";
          break;
      }
    } else {
      switch (intent) {
        case "transfer":
          text = "Pour envoyer de l'argent, acc\xE9dez \xE0 l'onglet 'Virement', saisissez le num\xE9ro de compte ou t\xE9l\xE9phone du destinataire ainsi que le montant, puis validez avec votre code PIN confidentiel.";
          phonetic = text;
          break;
        case "balance":
          text = "Pour consulter votre solde, acc\xE9dez \xE0 'Mon Espace' ou saisissez votre code PIN. Votre solde disponible est synchronis\xE9 en temps r\xE9el.";
          phonetic = text;
          break;
        case "fees":
          text = "Les frais de retrait au distributeur (GAB) sont de 1% du montant retir\xE9 (minimum 500 FCFA). Les retraits au guichet de votre banque sont gratuits (0 FCFA).";
          phonetic = text;
          break;
        case "security":
          text = "S\xE9curit\xE9 de votre compte : Ne communiquez jamais votre code secret PIN ni votre code OTP par SMS. Votre banque ne vous contactera jamais pour vous demander vos identifiants confidentiels.";
          phonetic = text;
          break;
        default:
          text = "Bonjour ! Je suis l'assistant bancaire IA LinguaBridge. Je peux vous renseigner sur vos virements, solde, frais de retrait et s\xE9curit\xE9 bancaire.";
          phonetic = text;
          break;
      }
    }
    if (entities.length > 0) {
      const entityStrings = entities.map((e) => e.raw).join(", ");
      const entityNotice = ` [\u{1F6E1}\uFE0F AST Guard: ${entityStrings}]`;
      text += entityNotice;
      phonetic += ` [${entityStrings}]`;
    }
    return {
      intent,
      text,
      phonetic,
      lang: targetLang,
      entities,
      zeroDriftVerified: true
    };
  }

  // ../../packages/translation-engine/dist/index.mjs
  var APERTIUM_EWONDO_ENTRIES = [
    {
      "ewo": "a",
      "fra": "il",
      "pos": "prn",
      "par": "cl_0"
    },
    {
      "ewo": "m\xF4t",
      "fra": "personne",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "m\xF4t",
      "fra": "homme",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "m\xF3do",
      "fra": "humanit\xE9",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "minga",
      "fra": "femme",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "abui",
      "fra": "beaucoup",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "a",
      "fra": "\xE0",
      "pos": "pr",
      "par": ""
    },
    {
      "ewo": "abum",
      "fra": "ventre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ab\xF2",
      "fra": "pied",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "af\xEB",
      "fra": "autre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "afi",
      "fra": "malgr\xE9",
      "pos": "pr",
      "par": ""
    },
    {
      "ewo": "dzal",
      "fra": "village",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "byan\u0300",
      "fra": "m\xE9dicament",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nyan\u0300",
      "fra": "mer",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "an\xEB",
      "fra": "comme",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "angondo",
      "fra": "horreur",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "at\xF2m",
      "fra": "ulc\xE8re",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "avus",
      "fra": "camaraderie",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "baala",
      "fra": "garder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mba",
      "fra": "tambour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mb\xE8",
      "fra": "porte",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "di",
      "fra": "manger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bad\xEB",
      "fra": "encore",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bam",
      "fra": "gronder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "an\u0300",
      "fra": "m\xE9dicament",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "anyan\u0300",
      "fra": "son fr\xE8re",
      "pos": "n",
      "par": "n_1/1_sg/sg"
    },
    {
      "ewo": "dzas",
      "fra": "don",
      "pos": "n",
      "par": "n_5b/6_sg/pl"
    },
    {
      "ewo": "asu",
      "fra": "pour",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "bum",
      "fra": "ventre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ai",
      "fra": "avec",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "ayon\u0300",
      "fra": "chaleur",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "mbad\xEBl\xF2g",
      "fra": "malchance",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "bal",
      "fra": "sarcler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ban",
      "fra": "appuyer sur",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbanda",
      "fra": "invitation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mban\u0300",
      "fra": "noyau",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9ban\u0300",
      "fra": "caillot",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9ban\u0300",
      "fra": "fagot",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "abas",
      "fra": "nageoire caudale",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "abe",
      "fra": "mal",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bebe",
      "fra": "pr\xE8s de",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "bede",
      "fra": "soulever",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bede",
      "fra": "d\xE9poser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bende",
      "fra": "recommander",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbendan",
      "fra": "fait d'annoncer",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "b\xE8d",
      "fra": "monter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xE8",
      "fra": "d\xE9pecer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ab\xE8",
      "fra": "sein",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ab\xE8",
      "fra": "cuisse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "b\xEBb\xEB",
      "fra": "regarder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBdan",
      "fra": "supplanter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xEBdan",
      "fra": "cadet",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xEBg",
      "fra": "partitionner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEB",
      "fra": "porter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEBl\xEB",
      "fra": "cafardage",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBg\xEBl\xEB",
      "fra": "attiser le feu",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xEBg\xEB",
      "fra": "charge",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mb\xEBb\xEBla",
      "fra": "v\xE9rit\xE9",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "b\xEBlan",
      "fra": "utiliser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBl\xEB",
      "fra": "dire vrai",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xEBm",
      "fra": "enfoncer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xEBm",
      "fra": "cagibi",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xEBme",
      "fra": "pr\xE9venir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xEBmb\xEB",
      "fra": "convenable",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "biali",
      "fra": "na\xEEtre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abi",
      "fra": "excr\xE9ment",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mbi",
      "fra": "preneur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "bif\xEBf\xE8",
      "fra": "v\xE9g\xE9tation anarchique",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "bie",
      "fra": "donner naissance",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mbie",
      "fra": "g\xE9niteur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "big",
      "fra": "d\xE9pister",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "big",
      "fra": "s'enrichir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abig",
      "fra": "urticaire",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "abiali",
      "fra": "naissance",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mbil",
      "fra": "course",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "bili",
      "fra": "\xEAtre contamin\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bili",
      "fra": "\xEAtre saoule",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bim",
      "fra": "enfler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abin",
      "fra": "p\xE9nis",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bindi",
      "fra": "d\xE9nicher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bisi",
      "fra": "photographier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bisi",
      "fra": "tenir compte de",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bit",
      "fra": "entrelacer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9bob",
      "fra": "grossier",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "abobo",
      "fra": "araign\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "boe",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bog",
      "fra": "b\xFBcher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abog",
      "fra": "f\xEAte",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bom",
      "fra": "battre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abom",
      "fra": "tumulus",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "boman",
      "fra": "entourer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mboman",
      "fra": "rhume",
      "pos": "n",
      "par": "n_3/3_sg/sg"
    },
    {
      "ewo": "mboman\xEB",
      "fra": "contour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mbonde",
      "fra": "fondateur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "bonde",
      "fra": "fonder",
      "pos": "refl",
      "par": ""
    },
    {
      "ewo": "b\xF2ban",
      "fra": "se faire",
      "pos": "refl",
      "par": ""
    },
    {
      "ewo": "b\xF2",
      "fra": "faire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xF2",
      "fra": "artisan",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "b\xF2d",
      "fra": "se mouiller",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "b\xF2d",
      "fra": "recadrer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ab\xF2d",
      "fra": "petitesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9b\xF2d",
      "fra": "cabine d'habillage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mb\xF2d",
      "fra": "accoutrement",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "b\xF2dan",
      "fra": "p\xE9trir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9b\xF2dan",
      "fra": "b\xE9n\xE9diction",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "b\xF2\xF2l\xF2",
      "fra": "attester",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mb\xF2\xF2l\xF2",
      "fra": "t\xE9moin",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "mb\xF2g",
      "fra": "un",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ab\xF2m",
      "fra": "morve",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9bonga",
      "fra": "c\xE2blage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mb\xF2n",
      "fra": "huile",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "mbu",
      "fra": "ann\xE9e",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "abu",
      "fra": "touffe",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9bubua",
      "fra": "calamit\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "budi",
      "fra": "couvrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bug",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bug\xEBban",
      "fra": "prosp\xE9rer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "abug\xEBban",
      "fra": "prosp\xE9rit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "bugi",
      "fra": "\xEAtre cass\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bum",
      "fra": "braiser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9buma",
      "fra": "cabosse",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "bumulan",
      "fra": "se pr\xE9cipiter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwal",
      "fra": "pourrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwali",
      "fra": "faire pourrir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bwe",
      "fra": "casser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "bye",
      "fra": "enfanter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dan\u0300",
      "fra": "d\xE9passer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dan\u0300dan\u0300",
      "fra": "surtout",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "dian",
      "fra": "se manger mutuellement",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dib",
      "fra": "fermer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "diban",
      "fra": "se fermer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dibidi",
      "fra": "dissimuler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "digi",
      "fra": "calciner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "diiban",
      "fra": "se ronger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dim",
      "fra": "effacer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ndim",
      "fra": "c\xE9cit\xE9",
      "pos": "n",
      "par": "n_9/2_sg/pl"
    },
    {
      "ewo": "dimi",
      "fra": "camouffler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9dimin\u0300",
      "fra": "cachoterie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "d\xF2",
      "fra": "surtout",
      "pos": "cnjcoo",
      "par": ""
    },
    {
      "ewo": "nd\xF2g",
      "fra": "voracit\xE9",
      "pos": "n",
      "par": "n_3/3_sg/sg"
    },
    {
      "ewo": "\xE9d\xF2g",
      "fra": "profondeur",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nd\xF2b\xEBd\xF2",
      "fra": "h\xF4pital",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "du",
      "fra": "tremper",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dudu",
      "fra": "attirer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dug",
      "fra": "mentir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dulu",
      "fra": "marche",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "dun\u0300",
      "fra": "d\xE9p\xE9rir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBm",
      "fra": "danser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBman",
      "fra": "manquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBm\xEBl\xEB",
      "fra": "dribbler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dz\xEBn\u0300",
      "fra": "chercher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzib",
      "fra": "voler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ndzin",
      "fra": "un certain",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "dzo",
      "fra": "dire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9dzo",
      "fra": "membre du corps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "adzogodo",
      "fra": "canton",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ndzoe",
      "fra": "dirigeant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "dzu",
      "fra": "pardonner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzug",
      "fra": "se faire mal",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "dzugu",
      "fra": "avoir l'habitude de",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mesanga",
      "fra": "sa tante paternelle",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mesia",
      "fra": "son p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mesoa",
      "fra": "ton p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "evuezin\u0300",
      "fra": "peut-\xEAtre",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "edzidzin",
      "fra": "dignit\xE9",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ekob",
      "fra": "peau",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "y\xEBgan",
      "fra": "s'etonner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9y\xEBgan",
      "fra": "stup\xE9faction",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "yom\xEBlo",
      "fra": "examiner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fag",
      "fra": "creuser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afan",
      "fra": "for\xEAt",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mfas",
      "fra": "analyse",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "fas\xEBban",
      "fra": "se faire examiner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "f\xEB",
      "fra": "autre",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "f\xEB",
      "fra": "aussi",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "f\xEBb",
      "fra": "sonder",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "af\xEBb",
      "fra": "papier",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mf\xEBb",
      "fra": "vapeur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "f\xEBg",
      "fra": "sagesse",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9f\xEBf\xE8",
      "fra": "v\xE9g\xE9tation hanarchique",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9f\xEBl",
      "fra": "cicatrice",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "f\xEBm",
      "fra": "d\xE9tester",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfia",
      "fra": "avocat",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "fib",
      "fra": "s'\xE9paissir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afib",
      "fra": "\xE9paisseur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "fid",
      "fra": "\xE9craser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fidi",
      "fra": "compter sur",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfila",
      "fra": "oreiller",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "fog",
      "fra": "\xEAtre mobile",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "afola",
      "fra": "place",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "mf\xF2n\u0300",
      "fra": "moelle",
      "pos": "n",
      "par": "n_9/10_sg/pl"
    },
    {
      "ewo": "f\xF2\xF2",
      "fra": "aussi",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "fub",
      "fra": "\xEAtre propre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fubu",
      "fra": "purifier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "fulan",
      "fra": "ressembler \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9fulan",
      "fra": "ressemblance",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mfulu",
      "fra": "caract\xE8re",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "fwe",
      "fra": "se multiplier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mfwe",
      "fra": "reproducteur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nguma",
      "fra": "entier",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nka",
      "fra": "assistant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nkada",
      "fra": "crabe",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "kad",
      "fra": "dire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kad\xEB",
      "fra": "souvent",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "kag",
      "fra": "empiler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkal",
      "fra": "plaidoyer",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kalan",
      "fra": "transmettre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkalasina",
      "fra": "p\xE9trole",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "kan",
      "fra": "odeur de roussi",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "kandi",
      "fra": "diminuer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ki",
      "fra": "s'abstenir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "aki",
      "fra": "oeuf",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9kie",
      "fra": "fer",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "akie",
      "fra": "feuille",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kig",
      "fra": "ne...pas",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "kil",
      "fra": "refuser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akil",
      "fra": "serve",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kilan",
      "fra": "tourner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kili",
      "fra": "interdire \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akim",
      "fra": "fluidit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kele",
      "fra": "suspendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kele",
      "fra": "circoncier",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akele",
      "fra": "circoncision",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "k\xEBlan",
      "fra": "se rompre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kende",
      "fra": "grignotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "k\xEB",
      "fra": "partir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9k\xEBl",
      "fra": "abc\xE8s",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ak\xEBn\u0300",
      "fra": "intelligence",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ak\xEBn\u0300",
      "fra": "technique",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nkidi",
      "fra": "matin",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "koan",
      "fra": "entasser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kuan",
      "fra": "vendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9koan",
      "fra": "r\xE9union",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "akoa",
      "fra": "pierre",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nkob",
      "fra": "puce",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "\xE9kod",
      "fra": "teigne",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "kodo",
      "fra": "quitter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akog",
      "fra": "pierre",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kom",
      "fra": "fabriquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkomo",
      "fra": "fabriquant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nkon",
      "fra": "fant\xF4me",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "k\xF2b\xF2",
      "fra": "parler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "k\xF2d",
      "fra": "tourner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akol",
      "fra": "pied",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "akoli",
      "fra": "pi\xE9ger",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "koge",
      "fra": "mordre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kogo",
      "fra": "ajouter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kogolo",
      "fra": "ajouter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nk\xF2b\xF2",
      "fra": "acceptation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "k\xF2m",
      "fra": "longtemps",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "k\xF2m",
      "fra": "habitude",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "ak\xF2m",
      "fra": "lourdeur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9k\xF2n",
      "fra": "maladie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "k\xF2n",
      "fra": "\xEAtre malade",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEB",
      "fra": "tatouer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEBban",
      "fra": "se faire vacciner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kp\xEBl\xEBmve",
      "fra": "cellulite",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ku",
      "fra": "tomber",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kue",
      "fra": "tousser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9kue",
      "fra": "toux",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nkugu",
      "fra": "cuisinier",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "nkukuma",
      "fra": "chef",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kulan",
      "fra": "se d\xE9tacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "kuliban",
      "fra": "se faire d\xE9tacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkulu",
      "fra": "tortue",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "nkulu",
      "fra": "tornade",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "akun",
      "fra": "poubelle",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kus",
      "fra": "acheter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nkus",
      "fra": "achat",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kus",
      "fra": "veuvage",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "nkus",
      "fra": "veuve",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "kwe",
      "fra": "cueillir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akwe",
      "fra": "escargot",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "kwi",
      "fra": "sortir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "akwi",
      "fra": "sortie",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "akya",
      "fra": "type",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "l\xEBd\xEB",
      "fra": "montrer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9l\xEBmb\xEB",
      "fra": "microscope",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "l\xEBmb\xEB",
      "fra": "guetter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9labi",
      "fra": "cadeau",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "lad",
      "fra": "coudre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lada",
      "fra": "\xEAtre coll\xE9 \xE0",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lamvomba",
      "fra": "bourru",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "lan\u0300",
      "fra": "lire",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "alen",
      "fra": "palmier",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "l\xE8",
      "fra": "puiser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "l\xE8d",
      "fra": "durcir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nl\xE8d",
      "fra": "duret\xE9",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "l\xE8n",
      "fra": "ruisseler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "al\xE8na",
      "fra": "infection due \xE0 une morsure d'araign\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "li",
      "fra": "d\xE9fricher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lod",
      "fra": "d\xE9passer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "lob",
      "fra": "mordre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lob",
      "fra": "sene\xE7on",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "alog",
      "fra": "p\xEAche au barrage",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "log",
      "fra": "faire la p\xEAche au barrage",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "al\xF2",
      "fra": "oreille",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9l\xF2bi",
      "fra": "mar\xE9cage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9l\xF2g",
      "fra": "herbe",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "l\xF2m",
      "fra": "c\xE9l\xE9brer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nlo",
      "fra": "t\xEAte",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "lum",
      "fra": "piquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "luman",
      "fra": "injecter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9lunga",
      "fra": "association",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "mma",
      "fra": "mouleur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xE9mag",
      "fra": "tas",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "man\xEB",
      "fra": "terminer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mmba",
      "fra": "tambour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "meki",
      "fra": "sang",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "amos",
      "fra": "journ\xE9e",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9mvum",
      "fra": "particule",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nal",
      "fra": "mensonge",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "\xE9nam",
      "fra": "membre sup\xE9rieur du corps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "namba",
      "fra": "toucher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "anda",
      "fra": "maison",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "andi",
      "fra": "espoir",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nnd\xF2n\u0300",
      "fra": "rapport",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "ndim",
      "fra": "eau",
      "pos": "n",
      "par": "n_6a/6a_pl/pl"
    },
    {
      "ewo": "\xE9ngog\xF2l",
      "fra": "piti\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "angomba",
      "fra": "ngomba",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "angon\u0300",
      "fra": "cadenas",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngan",
      "fra": "se braquer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9ngan",
      "fra": "obstin\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9ngas",
      "fra": "marais",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ng\xEBng",
      "fra": "clair",
      "pos": "adv",
      "par": ""
    },
    {
      "ewo": "ang\xEBng\xE8",
      "fra": "insecte",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngoge",
      "fra": "soir",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "angos",
      "fra": "tas",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngul",
      "fra": "force",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "angula",
      "fra": "cabane",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ngun",
      "fra": "entasser",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ngunubu",
      "fra": "accumuler",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "n\xF2n\u0300",
      "fra": "prendre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "anyama",
      "fra": "calamiteux",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyin\u0300",
      "fra": "vivre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9nyin\u0300",
      "fra": "vie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "anyu",
      "fra": "bouche",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyum",
      "fra": "sentir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9nyum",
      "fra": "odeur",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "dzoap",
      "fra": "nombril",
      "pos": "n",
      "par": "n_5b/6_sg/pl"
    },
    {
      "ewo": "oe",
      "fra": "rire",
      "pos": "n",
      "par": "n_5c/5c_sg/sg"
    },
    {
      "ewo": "dzooga",
      "fra": "articulation",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "m\xF2n\u0300\xF2n",
      "fra": "rejeton",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "k\xF2n",
      "fra": "maladie",
      "pos": "n",
      "par": "n_11/5_sg/pl"
    },
    {
      "ewo": "mmaw\xF2d",
      "fra": "ma\xE7on",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mm\xEBtua",
      "fra": "voiture",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mmvigi",
      "fra": "pratique m\xE9dicale",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "mmvim",
      "fra": "enflure",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "mmy\xEBg\xEB",
      "fra": "digue",
      "pos": "n",
      "par": "n_9/2_sg/pl"
    },
    {
      "ewo": "nn\xEBn\u0300",
      "fra": "h\xF4te",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nnom",
      "fra": "male",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "nnyala",
      "fra": "beau-fr\xE8re",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "op",
      "fra": "ciel",
      "pos": "n",
      "par": "n_5d/5d_sg/sg"
    },
    {
      "ewo": "m\xF2ng\xF2",
      "fra": "enfant",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xF2ng\xF2",
      "fra": "calamit\xE9",
      "pos": "n",
      "par": "n_5/5_sg/sg"
    },
    {
      "ewo": "\xE9salag",
      "fra": "caniveau",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "sanga",
      "fra": "tisane",
      "pos": "n",
      "par": "n_11/16_sg/pl"
    },
    {
      "ewo": "\xE9s\xEBd\xEBga",
      "fra": "\xE9chantillon",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ns\xEBn\u0300",
      "fra": "cour",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ns\xEBm",
      "fra": "p\xE9ch\xE9",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nsi",
      "fra": "terre",
      "pos": "n",
      "par": "n_9/6_sg/pl"
    },
    {
      "ewo": "asie",
      "fra": "cabinet",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nsis",
      "fra": "nerf",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "nsili",
      "fra": "question",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "s\xF2",
      "fra": "\xEAtre venu",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "as\xF2",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ns\xF2b\xF2",
      "fra": "savon",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "s\xF2b\xF2",
      "fra": "se cacher",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "as\xF2b\xF2",
      "fra": "cache",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "as\xF2l\xF2",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "asoe",
      "fra": "cachette",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nsoe",
      "fra": "l\xE9zard",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "asoga",
      "fra": "calao",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "s\xF2s",
      "fra": "medisance",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "susu",
      "fra": "pluie diluvienne",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9susud",
      "fra": "humidit\xE9",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nsusug",
      "fra": "pareusseux",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9tam",
      "fra": "puits",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ntada",
      "fra": "p\xE8re",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "ntela",
      "fra": "tailleur",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "t\xE8",
      "fra": "\xEAtre douloureux",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "at\xEBg",
      "fra": "faiblesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nti",
      "fra": "seigneur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "tin",
      "fra": "souche",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "tinte",
      "fra": "encre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "tog",
      "fra": "s'aggraver",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntog",
      "fra": "cuill\xE8re",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "atom",
      "fra": "colis",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9t\xF2",
      "fra": "place",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "at\xF2m",
      "fra": "ulc\xE8re de Buruli",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "atolog",
      "fra": "papule",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ntsan\u0300",
      "fra": "bouton",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "tug",
      "fra": "frotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntug",
      "fra": "action de frotter",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ntug",
      "fra": "d\xE9su\xE9tude",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "tugu",
      "fra": "\xEAtre en train de frotter",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": 'ntugu"n"/>',
      "fra": "frotteur",
      "pos": "",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "tugulu",
      "fra": "causer une l\xE9sion",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ntugulu",
      "fra": "l\xE9sion",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "\xE9tun",
      "fra": "partie",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "tye",
      "fra": "taquinerie",
      "pos": "n",
      "par": "n_4/4_pl/pl"
    },
    {
      "ewo": "avis",
      "fra": "amas",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "\xE9v\xE8",
      "fra": "soif",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "\xE9v\xE8s",
      "fra": "os",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "v\xEBb\xEB",
      "fra": "respirer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "mv\xEBb\xEB",
      "fra": "respiration",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "\xE9v\xEBga",
      "fra": "exemple",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "av\xEBn\u0300",
      "fra": "plaie",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "avol",
      "fra": "rapidit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "av\xF2n\u0300",
      "fra": "graisse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "v\xF2g",
      "fra": "autre",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "weme",
      "fra": "se muer",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9wem\xEBnga",
      "fra": "n\xE9crose",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "nwundi",
      "fra": "fen\xEAtre",
      "pos": "n",
      "par": "n_1a/2_sg/pl"
    },
    {
      "ewo": "g\xEBban",
      "fra": "scintiller",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "w\xF2",
      "fra": "main",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "nwulu",
      "fra": "marcheur",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "ya",
      "fra": "grandir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ayab",
      "fra": "longueur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9yalga",
      "fra": "enveloppe",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ayan\u0300",
      "fra": "couleur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayan\u0300",
      "fra": "bulbe",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "aye",
      "fra": "p\xE9riode",
      "pos": "n",
      "par": "n_5a/6_sg/pl"
    },
    {
      "ewo": "ny\xEBb\xEB",
      "fra": "acceptation",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "ay\xEBg\xE8",
      "fra": "apprentissage",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9y\xEBm",
      "fra": "handicape",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "y\xEBm",
      "fra": "savoir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "y\xE8",
      "fra": "cro\xEEtre",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "ay\xE8",
      "fra": "croissance",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "y\xEBm",
      "fra": "\xEAtre coinc\xE9",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "yi",
      "fra": "vouloir",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "\xE9yia",
      "fra": "ulc\xE8re phag\xE9d\xE9nique",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "ayie",
      "fra": "difficult\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nyoa",
      "fra": "ta m\xE8re",
      "pos": "n",
      "par": "n_1/2_sg/pl"
    },
    {
      "ewo": "ayol",
      "fra": "amertume",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayom",
      "fra": "vieillesse",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "ayom",
      "fra": "caducit\xE9",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "\xE9y\xF2n\u0300",
      "fra": "temps",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "yom\xEBlo",
      "fra": "raviver",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "nyon",
      "fra": "pleur",
      "pos": "n",
      "par": "n_3/4_sg/pl"
    },
    {
      "ewo": "Zamba",
      "fra": "Dieu",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "zam",
      "fra": "l\xE8pre",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "\xE9zam\xEBda",
      "fra": "cafouillage",
      "pos": "n",
      "par": "n_7/8_sg/pl"
    },
    {
      "ewo": "zie",
      "fra": "faim",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "azimbi",
      "fra": "soldats",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "zin\u0300",
      "fra": "un tel",
      "pos": "adjind",
      "par": ""
    },
    {
      "ewo": "v\xEB",
      "fra": "donner",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "veend\xEBg\xEBle",
      "fra": "d\xE9ranger",
      "pos": "vblex",
      "par": ""
    },
    {
      "ewo": "avon\u0300",
      "fra": "chaleur",
      "pos": "n",
      "par": "n_5/6_sg/pl"
    },
    {
      "ewo": "nd\xEBg\xEBl\xEB",
      "fra": "ennui",
      "pos": "n",
      "par": ""
    },
    {
      "ewo": "ama",
      "fra": "mon",
      "pos": "adj",
      "par": "pos_GDND_Gender-1"
    }
  ];
  var FINANCIAL_GLOSSARY_ENTRIES = [
    {
      "ewo": "M\xF3ni m\xED ne",
      "fra": "Solde",
      "en": "Balance",
      "phonetic": "m\xF3-n\xED m\xED n\xE9"
    },
    {
      "ewo": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
      "fra": "Solde disponible",
      "en": "Available balance",
      "phonetic": "m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B"
    },
    {
      "ewo": "M\xF3ni m\xED ne n\xE1n\xE1",
      "fra": "Solde actuel",
      "en": "Current balance",
      "phonetic": "m\xF3-n\xED m\xED n\xE9 n\xE1-n\xE1"
    },
    {
      "ewo": "M\xF3ni m\xED ne t\xE9gu\xE9 abui",
      "fra": "Solde insuffisant",
      "en": "Insufficient funds",
      "phonetic": "m\xF3-n\xED m\xED n\xE9 t\xE9-g\xE9 \xE0-b\xF9\xEC"
    },
    {
      "ewo": "L\xF3m m\xF3ni",
      "fra": "Virement / Transfert",
      "en": "Money transfer",
      "phonetic": "l\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "Minl\xF3m m\xED m\xF3ni",
      "fra": "Virements / Transferts",
      "en": "Transfers",
      "phonetic": "m\xEC-n-l\xF3m m\xED m\xF3-n\xED"
    },
    {
      "ewo": "V\xE1 m\xF3ni",
      "fra": "Envoyer de l'argent",
      "en": "Send money",
      "phonetic": "v\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "N\xF2ng m\xF3ni",
      "fra": "Recevoir de l'argent",
      "en": "Receive money",
      "phonetic": "n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "N\xF2ng m\xF3ni",
      "fra": "Retrait d'argent",
      "en": "Cash withdrawal",
      "phonetic": "n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "Minl\xF2ng m\xED m\xF3ni",
      "fra": "Retraits",
      "en": "Withdrawals",
      "phonetic": "m\xEC-n-l\xF2\u014B m\xED m\xF3-n\xED"
    },
    {
      "ewo": "W\xF3gl\xF4 m\xF3ni",
      "fra": "D\xE9p\xF4t d'argent",
      "en": "Deposit",
      "phonetic": "w\xF3-gl\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "Mew\xF3gl\xF4 m\xF3ni",
      "fra": "D\xE9p\xF4ts",
      "en": "Deposits",
      "phonetic": "me-w\xF3-gl\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1",
      "fra": "Frais",
      "en": "Fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m",
      "fra": "Frais de transfert",
      "en": "Transfer fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-l\xF3m"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1 m\xE9 nn\xF2ng",
      "fra": "Frais de retrait",
      "en": "Cash out fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-n\xF2\u014B"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1 m\xE9 \xE9k\xF3bl\xF3",
      "fra": "Frais de tenue de compte",
      "en": "Account maintenance fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 \xE9-k\xF3-bl\xF3"
    },
    {
      "ewo": "M\xF3ni m\xE9bemb\xE1 y\xE1 fakat t\xE1l",
      "fra": "Frais de timbre fiscal",
      "en": "Fiscal stamp fees",
      "phonetic": "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 y\xE1 fa-kat t\xE1l"
    },
    {
      "ewo": "Fakat t\xE1l",
      "fra": "Timbre fiscal",
      "en": "Fiscal stamp",
      "phonetic": "fa-kat t\xE1l"
    },
    {
      "ewo": "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1",
      "fra": "Sans frais",
      "en": "Free of charge",
      "phonetic": "t\xE9-g\xE9 m\xF3-n\xED m\xE9-b\xE8m-b\xE1"
    },
    {
      "ewo": "Ny\xED a n\xF2ng m\xF3ni",
      "fra": "B\xE9n\xE9ficiaire",
      "en": "Beneficiary",
      "phonetic": "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "Ny\xED a l\xF3m m\xF3ni",
      "fra": "Exp\xE9diteur",
      "en": "Sender",
      "phonetic": "ny\xED \xE0 l\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "T\xEDb\xEDli t\xF3b\xF3",
      "fra": "Confirmer",
      "en": "Confirm",
      "phonetic": "t\xED-b\xED-l\xED t\xF3-b\xF3"
    },
    {
      "ewo": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
      "fra": "Confirmer le transfert",
      "en": "Confirm transfer",
      "phonetic": "t\xED-b\xED-l\xED t\xF3-b\xF3 n-l\xF3m"
    },
    {
      "ewo": "Dz\xE1gb\xE1",
      "fra": "Annuler",
      "en": "Cancel",
      "phonetic": "dz\xE1-gb\xE1"
    },
    {
      "ewo": "Dz\xE1gb\xE1 nl\xF3m",
      "fra": "Annuler la transaction",
      "en": "Cancel transaction",
      "phonetic": "dz\xE1-gb\xE1 n-l\xF3m"
    },
    {
      "ewo": "Abui m\xF3ni",
      "fra": "Montant",
      "en": "Amount",
      "phonetic": "\xE0-b\xF9\xEC m\xF3-n\xED"
    },
    {
      "ewo": "Abui m\xF3ni y\xE1 nl\xF3m",
      "fra": "Montant du transfert",
      "en": "Transfer amount",
      "phonetic": "\xE0-b\xF9\xEC m\xF3-n\xED y\xE1 n-l\xF3m"
    },
    {
      "ewo": "Abui m\xF3ni m\xE9s\xEB",
      "fra": "Montant total",
      "en": "Total amount",
      "phonetic": "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-s\xEB"
    },
    {
      "ewo": "Nlamb\xE1 telef\xF4n",
      "fra": "Num\xE9ro de t\xE9l\xE9phone",
      "en": "Phone number",
      "phonetic": "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n"
    },
    {
      "ewo": "Nd\xE1mb\xE1 ts\xEDti",
      "fra": "Code secret / PIN",
      "en": "Secret PIN",
      "phonetic": "n-d\xE1m-b\xE1 ts\xED-t\xED"
    },
    {
      "ewo": "Nd\xE1mb\xE1 ts\xEDti \xE9y\u0254\u014B zia",
      "fra": "Mot de passe temporaire / OTP",
      "en": "One-time password",
      "phonetic": "n-d\xE1m-b\xE1 ts\xED-t\xED \xE9-y\u0254\u0300\u014B z\xEC-\xE0"
    },
    {
      "ewo": "Minl\xF3m m\xED ay\xE1a l\xF3t",
      "fra": "Historique des transactions",
      "en": "Transaction history",
      "phonetic": "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t"
    },
    {
      "ewo": "Nl\xF3m m\xF3ni",
      "fra": "Transaction",
      "en": "Transaction",
      "phonetic": "n-l\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa",
      "fra": "Transfert effectu\xE9 avec succ\xE8s",
      "en": "Transfer successful",
      "phonetic": "l\xF3m m\xF3-n\xED l-\xE0-y\xE1-\xE1 d\xFA-\xE1"
    },
    {
      "ewo": "L\xF3m m\xF3ni l'ab\xEA d\xFAa",
      "fra": "\xC9chec de l'op\xE9ration",
      "en": "Operation failed",
      "phonetic": "l\xF3m m\xF3-n\xED l-\xE0-b\xE9 d\xFA-\xE1"
    },
    {
      "ewo": "\xC9 ng\xE1 yange",
      "fra": "En attente",
      "en": "Pending",
      "phonetic": "\xE9 \u014B\xE1 ya\u014B-ge"
    },
    {
      "ewo": "\xC9 ng\xE1 b\u0254ban",
      "fra": "En cours",
      "en": "In progress",
      "phonetic": "\xE9 \u014B\xE1 b\xF2-ban"
    },
    {
      "ewo": "M\xF3ni ts\u0254\u0301",
      "fra": "Cotisation tontine",
      "en": "Tontine contribution",
      "phonetic": "m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "\xC9y\u0254\u014B ts\u0254\u0301",
      "fra": "Tour de tontine",
      "en": "Tontine turn",
      "phonetic": "\xE9-y\u0254\u0300\u014B ts\u0254\u0301"
    },
    {
      "ewo": "Esul\xE1n ts\u0254\u0301",
      "fra": "R\xE9union de tontine",
      "en": "Tontine meeting",
      "phonetic": "\xE9-s\xF9-l\xE1n ts\u0254\u0301"
    },
    {
      "ewo": "N\xF2ng m\xF3ni ts\u0254\u0301",
      "fra": "Ramassage tontine",
      "en": "Tontine payout",
      "phonetic": "n\xF2\u014B m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "\xC9k\xF3bl\xF3",
      "fra": "Compte",
      "en": "Account",
      "phonetic": "\xE9-k\xF3-bl\xF3"
    },
    {
      "ewo": "Mak\xF3bl\xF3",
      "fra": "Comptes",
      "en": "Accounts",
      "phonetic": "ma-k\xF3-bl\xF3"
    },
    {
      "ewo": "\xC9k\xF3bl\xF3 m\xF3ni ya \xE9t\xE1m",
      "fra": "Compte principal",
      "en": "Main account",
      "phonetic": "\xE9-k\xF3-bl\xF3 m\xF3-n\xED y\xE0 \xE9-t\xE1m"
    },
    {
      "ewo": "\xC9k\xF3bl\xF3 \xE9t\xE1m",
      "fra": "Compte courant",
      "en": "Current account",
      "phonetic": "\xE9-k\xF3-bl\xF3 \xE9-t\xE1m"
    },
    {
      "ewo": "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni",
      "fra": "Compte d'\xE9pargne",
      "en": "Savings account",
      "phonetic": "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "B\xF3m m\xF3ni",
      "fra": "\xC9pargne",
      "en": "Savings",
      "phonetic": "b\xF3m m\xF3-n\xED"
    },
    {
      "ewo": "Nlamb\xE1 \xE9k\xF3bl\xF3",
      "fra": "Num\xE9ro de compte",
      "en": "Account number",
      "phonetic": "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3"
    },
    {
      "ewo": "Kalad\xED \xE9k\xF3bl\xF3",
      "fra": "Relev\xE9 de compte",
      "en": "Bank statement",
      "phonetic": "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3"
    },
    {
      "ewo": "Kalad\xED nl\xE1man",
      "fra": "Re\xE7u de paiement",
      "en": "Payment receipt",
      "phonetic": "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n"
    },
    {
      "ewo": "T\xF3b\xF3 m\xF3ni",
      "fra": "Paiement",
      "en": "Payment",
      "phonetic": "t\xF3-b\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED",
      "fra": "Paiement de facture",
      "en": "Bill payment",
      "phonetic": "t\xF3-b\xF3 m\xF3-n\xED y\xE1 k\xE0-l\xE0-d\xED"
    },
    {
      "ewo": "T\xF3b\xF3 m\xF3ni nk\xFAs",
      "fra": "Paiement marchand",
      "en": "Merchant payment",
      "phonetic": "t\xF3-b\xF3 m\xF3-n\xED n-k\xFAs"
    },
    {
      "ewo": "Nd\xE1mb\xE1 nk\xFAs",
      "fra": "Code marchand",
      "en": "Merchant code",
      "phonetic": "n-d\xE1m-b\xE1 n-k\xFAs"
    },
    {
      "ewo": "Nd\xE1mb\xE1 scan",
      "fra": "Scanner pour payer",
      "en": "Scan to pay",
      "phonetic": "n-d\xE1m-b\xE1 skan"
    },
    {
      "ewo": "K\xF9s f\xF3n",
      "fra": "Recharge t\xE9l\xE9phonique",
      "en": "Airtime recharge",
      "phonetic": "k\xF9s f\xF3n"
    },
    {
      "ewo": "Nda m\xF3ni",
      "fra": "Banque",
      "en": "Bank",
      "phonetic": "n-da m\xF3-n\xED"
    },
    {
      "ewo": "Menda m\xE9 m\xF3ni",
      "fra": "Banques",
      "en": "Banks",
      "phonetic": "men-da m\xE9 m\xF3-n\xED"
    },
    {
      "ewo": "Nda m\xF3ni ts\u0254\u0301",
      "fra": "Microfinance",
      "en": "Microfinance",
      "phonetic": "n-da m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "K\xE1l\xE1 m\xF3ni",
      "fra": "Pr\xEAt / Cr\xE9dit",
      "en": "Loan",
      "phonetic": "k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "K\xF9s k\xE1l\xE1 m\xF3ni",
      "fra": "Remboursement de pr\xEAt",
      "en": "Loan repayment",
      "phonetic": "k\xF9s k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "Abui m\xF3ni m\xE9bemb\xE1",
      "fra": "Taux d'int\xE9r\xEAt",
      "en": "Interest rate",
      "phonetic": "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-b\xE8m-b\xE1"
    },
    {
      "ewo": "Mos y\xE1 man\xEB",
      "fra": "Date d'\xE9ch\xE9ance",
      "en": "Due date",
      "phonetic": "mos y\xE1 ma-n\xEB"
    },
    {
      "ewo": "Mba\xE1n k\xE1l\xE1 m\xF3ni",
      "fra": "Caution / Garantie",
      "en": "Collateral",
      "phonetic": "m-ba-\xE1n k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "Kalad\xED nda m\xF3ni",
      "fra": "Carte bancaire",
      "en": "Bank card",
      "phonetic": "k\xE0-l\xE0-d\xED n-da m\xF3-n\xED"
    },
    {
      "ewo": "Kalad\xED k\xE1l\xE1 m\xF3ni",
      "fra": "Carte de cr\xE9dit",
      "en": "Credit card",
      "phonetic": "k\xE0-l\xE0-d\xED k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "Kalad\xED m\xF3ni",
      "fra": "Carte de d\xE9bit",
      "en": "Debit card",
      "phonetic": "k\xE0-l\xE0-d\xED m\xF3-n\xED"
    },
    {
      "ewo": "Dib kalad\xED m\xF3ni",
      "fra": "Bloquer la carte",
      "en": "Block card",
      "phonetic": "dib k\xE0-l\xE0-d\xED m\xF3-n\xED"
    },
    {
      "ewo": "Yob kalad\xED m\xF3ni",
      "fra": "D\xE9bloquer la carte",
      "en": "Unblock card",
      "phonetic": "yob k\xE0-l\xE0-d\xED m\xF3-n\xED"
    },
    {
      "ewo": "Mas\xEDn m\xF3ni",
      "fra": "Distributeur automatique / GAB",
      "en": "ATM",
      "phonetic": "ma-s\xEDn m\xF3-n\xED"
    },
    {
      "ewo": "\xC9m\xF2t a k\xF9s m\xF3ni",
      "fra": "Point de vente / Agent",
      "en": "Agent / Point of sale",
      "phonetic": "\xE9-m\xF2t \xE0 k\xF9s m\xF3-n\xED"
    },
    {
      "ewo": "Mba\xE1n",
      "fra": "S\xE9curit\xE9",
      "en": "Security",
      "phonetic": "m-ba-\xE1n"
    },
    {
      "ewo": "\xC9 ne mba\xE1n",
      "fra": "S\xE9curis\xE9",
      "en": "Secured",
      "phonetic": "\xE9 n\xE9 m-ba-\xE1n"
    },
    {
      "ewo": "L\xF3m m\xF3ni \xE9 ne mba\xE1n",
      "fra": "Transfert s\xE9curis\xE9",
      "en": "Secured transfer",
      "phonetic": "l\xF3m m\xF3-n\xED \xE9 n\xE9 m-ba-\xE1n"
    },
    {
      "ewo": "Asu dz\xE9 / nkat",
      "fra": "Motif du paiement / R\xE9f\xE9rence",
      "en": "Payment reason / reference",
      "phonetic": "a-s\xFA dz\xE9 / n-kat"
    },
    {
      "ewo": "Orange Money",
      "fra": "Orange Money",
      "en": "Orange Money",
      "phonetic": "o-ranj mo-n\xED"
    },
    {
      "ewo": "MTN MoMo",
      "fra": "MTN MoMo",
      "en": "MTN MoMo",
      "phonetic": "em-ti-en mo-mo"
    },
    {
      "ewo": "W\xF3gl\xF4 m\xF3ni",
      "fra": "Cash-in / D\xE9p\xF4t esp\xE8ces",
      "en": "Cash in",
      "phonetic": "w\xF3-gl\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "N\xF2ng m\xF3ni",
      "fra": "Cash-out / Retrait esp\xE8ces",
      "en": "Cash out",
      "phonetic": "n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "K\xF9s f\xF3n",
      "fra": "Achat de cr\xE9dit / Airtime",
      "en": "Airtime",
      "phonetic": "k\xF9s f\xF3n"
    },
    {
      "ewo": "K\xF9s f\xF3n internet",
      "fra": "Forfait internet",
      "en": "Data bundle",
      "phonetic": "k\xF9s f\xF3n in-ter-net"
    },
    {
      "ewo": "Nd\xE1mb\xE1 mba\xE1n kalad\xED",
      "fra": "Code CVV / Code de s\xE9curit\xE9",
      "en": "CVV / Security code",
      "phonetic": "n-d\xE1m-b\xE1 m-ba-\xE1n k\xE0-l\xE0-d\xED"
    },
    {
      "ewo": "Mos y\xE1 man\xEB kalad\xED",
      "fra": "Date d'expiration",
      "en": "Expiry date",
      "phonetic": "mos y\xE1 ma-n\xEB k\xE0-l\xE0-d\xED"
    },
    {
      "ewo": "T\xF2 nda m\xF3ni",
      "fra": "Kiosque / Point de service",
      "en": "Kiosk / Service point",
      "phonetic": "t\xF2 n-da m\xF3-n\xED"
    },
    {
      "ewo": "\xC9m\xF2t a k\xF9s m\xF3ni",
      "fra": "Agent agr\xE9\xE9",
      "en": "Authorized agent",
      "phonetic": "\xE9-m\xF2t \xE0 k\xF9s m\xF3-n\xED"
    },
    {
      "ewo": "Nda m\xF3ni ts\u0254\u0301",
      "fra": "\xC9tablissement de microfinance / EMF",
      "en": "Microfinance institution / MFI",
      "phonetic": "n-da m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "M\xF3ni ts\u0254\u0301",
      "fra": "\xC9pargne rotative",
      "en": "Rotating savings",
      "phonetic": "m\xF3-n\xED ts\u0254\u0301"
    },
    {
      "ewo": "Nda ngul ay\u0254\u014B",
      "fra": "Caisse de solidarit\xE9",
      "en": "Solidarity fund",
      "phonetic": "n-da ngul \xE0-y\u0254\u014B"
    },
    {
      "ewo": "Kalad\xED nl\xE1man",
      "fra": "Preuve de paiement",
      "en": "Proof of payment",
      "phonetic": "k\xE0-l\xE0-d\xED n-l\xE1-man"
    },
    {
      "ewo": "Nkat",
      "fra": "R\xE9f\xE9rence",
      "en": "Reference",
      "phonetic": "n-kat"
    },
    {
      "ewo": "K\xE1l\xE1 m\xF3ni",
      "fra": "Emprunt",
      "en": "Borrowing",
      "phonetic": "k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "Mba\xE1n k\xE1l\xE1 m\xF3ni",
      "fra": "Garantie / Caution",
      "en": "Guarantee / Collateral",
      "phonetic": "m-ba-\xE1n k\xE1-l\xE1 m\xF3-n\xED"
    },
    {
      "ewo": "Ny\xED a n\xF2ng m\xF3ni",
      "fra": "Destinataire",
      "en": "Recipient",
      "phonetic": "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED"
    },
    {
      "ewo": "Mat\xF3b\xF3 m\xF3ni",
      "fra": "Paiements",
      "en": "Payments",
      "phonetic": "ma-t\xF3-b\xF3 m\xF3-n\xED"
    },
    {
      "ewo": "Mak\xE1l\xE1 m\xE9 m\xF3ni",
      "fra": "Pr\xEAts / Cr\xE9dits",
      "en": "Loans",
      "phonetic": "ma-k\xE1-l\xE1 m\xE9 m\xF3-n\xED"
    }
  ];
  var EXTENDED_BANKING_UI_LEXICON = {
    // Navigation & Space
    "bienvenue": { ewo: "Mb\xF3lo", phonetic: "m-b\xF3-lo" },
    "bienvenue sur votre espace bancaire": { ewo: "Mb\xF3lo \xE9 mv\xF4k nda m\xF3ni w\xEAn", phonetic: "m-b\xF3-lo \xE9 m-v\xF4k n-da m\xF3-n\xED w\xEAn" },
    "bienvenue sur votre espace client": { ewo: "Mb\xF3lo \xE9 mv\xF4k \xE9m\xF2t w\xEAn", phonetic: "m-b\xF3-lo \xE9 m-v\xF4k \xE9-m\xF2t w\xEAn" },
    "bienvenue sur": { ewo: "Mb\xF3lo \xE9", phonetic: "m-b\xF3-lo \xE9" },
    "espace bancaire": { ewo: "Mv\xF4k nda m\xF3ni", phonetic: "m-v\xF4k n-da m\xF3-n\xED" },
    "espace client": { ewo: "Mv\xF4k \xE9m\xF2t", phonetic: "m-v\xF4k \xE9-m\xF2t" },
    "mon espace": { ewo: "Mv\xF4k dama", phonetic: "m-v\xF4k da-ma" },
    "votre espace": { ewo: "Mv\xF4k w\xEAn", phonetic: "m-v\xF4k w\xEAn" },
    "espace": { ewo: "Mv\xF4k", phonetic: "m-v\xF4k" },
    "accueil": { ewo: "Mv\xF4k", phonetic: "m-v\xF4k" },
    "page d accueil": { ewo: "Mv\xF4k kalad\xED", phonetic: "m-v\xF4k k\xE0-l\xE0-d\xED" },
    "page d'accueil": { ewo: "Mv\xF4k kalad\xED", phonetic: "m-v\xF4k k\xE0-l\xE0-d\xED" },
    "menu": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "param\xE8tres": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "parametres": { ewo: "Mimb\xF2n\xE1n", phonetic: "m\xECm-b\xF2-n\xE1n" },
    "profil": { ewo: "\xC9m\xF2t", phonetic: "\xE9-m\xF2t" },
    "client": { ewo: "M\xF4t", phonetic: "m\xF4t" },
    "clients": { ewo: "B\xF4t", phonetic: "b\xF4t" },
    "utilisateur": { ewo: "M\xF4t", phonetic: "m\xF4t" },
    "utilisateurs": { ewo: "B\xF4t", phonetic: "b\xF4t" },
    "tableau de bord": { ewo: "Mv\xF4k mimb\xF2n\xE1n", phonetic: "m-v\xF4k m\xECm-b\xF2-n\xE1n" },
    // Banking Institutions & Points of Service
    "banque": { ewo: "Nda m\xF3ni", phonetic: "n-da m\xF3-n\xED" },
    "banques": { ewo: "Menda m\xE9 m\xF3ni", phonetic: "men-da m\xE9 m\xF3-n\xED" },
    "agence": { ewo: "T\xF2 nda m\xF3ni", phonetic: "t\xF2 n-da m\xF3-n\xED" },
    "agences": { ewo: "M\xE8t\xF2 nda m\xF3ni", phonetic: "m\xE8-t\xF2 n-da m\xF3-n\xED" },
    "guichet": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "guichets": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "distributeur": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "distributeurs": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "distributeur automatique": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    "dab": { ewo: "Mas\xEDn m\xF3ni", phonetic: "ma-s\xEDn m\xF3-n\xED" },
    // Accounts
    "compte": { ewo: "\xC9k\xF3bl\xF3", phonetic: "\xE9-k\xF3-bl\xF3" },
    "comptes": { ewo: "Mak\xF3bl\xF3", phonetic: "ma-k\xF3-bl\xF3" },
    "mon compte": { ewo: "\xC9k\xF3bl\xF3 dama", phonetic: "\xE9-k\xF3-bl\xF3 da-ma" },
    "mes comptes": { ewo: "Mak\xF3bl\xF3 mama", phonetic: "ma-k\xF3-bl\xF3 ma-ma" },
    "votre compte": { ewo: "\xC9k\xF3bl\xF3 w\xEAn", phonetic: "\xE9-k\xF3-bl\xF3 w\xEAn" },
    "vos comptes": { ewo: "Mak\xF3bl\xF3 m\xEAn", phonetic: "ma-k\xF3-bl\xF3 m\xEAn" },
    "compte bancaire": { ewo: "\xC9k\xF3bl\xF3 m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 m\xF3-n\xED" },
    "compte courant": { ewo: "\xC9k\xF3bl\xF3 \xE9t\xE1m", phonetic: "\xE9-k\xF3-bl\xF3 \xE9-t\xE1m" },
    "compte epargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte \xE9pargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte d'\xE9pargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "compte d epargne": { ewo: "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni", phonetic: "\xE9-k\xF3-bl\xF3 b\xF3m m\xF3-n\xED" },
    "num\xE9ro de compte": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    "relev\xE9 de compte": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "releve de compte": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "relev\xE9": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "releve": { ewo: "Kalad\xED \xE9k\xF3bl\xF3", phonetic: "k\xE0-l\xE0-d\xED \xE9-k\xF3-bl\xF3" },
    "rib": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    "iban": { ewo: "Nlamb\xE1 \xE9k\xF3bl\xF3", phonetic: "n-l\xE0m-b\xE1 \xE9-k\xF3-bl\xF3" },
    // Balances & Currency
    "solde": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "balance": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "solde disponible": { ewo: "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng", phonetic: "m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B" },
    "solde actuel": { ewo: "M\xF3ni m\xED ne n\xE1n\xE1", phonetic: "m\xF3-n\xED m\xED n\xE9 n\xE1-n\xE1" },
    "mon solde": { ewo: "M\xF3ni m\xED ne", phonetic: "m\xF3-n\xED m\xED n\xE9" },
    "votre solde": { ewo: "M\xF3ni m\xED ne w\xEAn", phonetic: "m\xF3-n\xED m\xED n\xE9 w\xEAn" },
    "votre solde est insuffisant": { ewo: "M\xF3ni m\xED ne w\xEAn \xE9 ne t\xE9gu\xE9 abui", phonetic: "m\xF3-n\xED m\xED n\xE9 w\xEAn \xE9 n\xE9 t\xE9-g\xE9 \xE0-b\xF9\xEC" },
    "solde est insuffisant": { ewo: "M\xF3ni m\xED ne t\xE9gu\xE9 abui", phonetic: "m\xF3-n\xED m\xED n\xE9 t\xE9-g\xE9 \xE0-b\xF9\xEC" },
    "solde insuffisant": { ewo: "M\xF3ni m\xED ne t\xE9gu\xE9 abui", phonetic: "m\xF3-n\xED m\xED n\xE9 t\xE9-g\xE9 \xE0-b\xF9\xEC" },
    "est insuffisant": { ewo: "\xE9 ne t\xE9gu\xE9 abui", phonetic: "\xE9 n\xE9 t\xE9-g\xE9 \xE0-b\xF9\xEC" },
    "insuffisant": { ewo: "t\xE9gu\xE9 abui", phonetic: "t\xE9-g\xE9 \xE0-b\xF9\xEC" },
    "pour couvrir": { ewo: "as\xFA budi", phonetic: "a-s\xFA bu-di" },
    "couvrir": { ewo: "budi", phonetic: "bu-di" },
    "consulter mon solde": { ewo: "Y\xEAn m\xF3ni m\xED ne", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9" },
    "consulter mon compte": { ewo: "Y\xEAn \xE9k\xF3bl\xF3 dama", phonetic: "y\xEAn \xE9-k\xF3-bl\xF3 da-ma" },
    "consulter le solde": { ewo: "Y\xEAn m\xF3ni m\xED ne", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9" },
    "consulter le solde disponible": { ewo: "Y\xEAn m\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng", phonetic: "y\xEAn m\xF3-n\xED m\xED n\xE9 w\xE1 \xE9 b\xE8\u014B" },
    "consulter": { ewo: "Y\xEAn", phonetic: "y\xEAn" },
    "montant": { ewo: "Abui m\xF3ni", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED" },
    "montant du transfert": { ewo: "Abui m\xF3ni y\xE1 nl\xF3m", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED y\xE1 n-l\xF3m" },
    "montant total": { ewo: "Abui m\xF3ni m\xE9s\xEB", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-s\xEB" },
    "argent": { ewo: "M\xF3ni", phonetic: "m\xF3-n\xED" },
    "l'argent": { ewo: "M\xF3ni", phonetic: "m\xF3-n\xED" },
    "d'argent": { ewo: "m\xF3ni", phonetic: "m\xF3-n\xED" },
    "votre argent": { ewo: "M\xF3ni w\xEAn", phonetic: "m\xF3-n\xED w\xEAn" },
    "mon argent": { ewo: "M\xF3ni wama", phonetic: "m\xF3-n\xED wa-ma" },
    "votre argent est en s\xE9curit\xE9": { ewo: "M\xF3ni w\xEAn \xE9 ne mba\xE1n", phonetic: "m\xF3-n\xED w\xEAn \xE9 n\xE9 m-ba-\xE1n" },
    // Transfers & Operations
    "virement": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "virements": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "transfert": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "transferts": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "virement bancaire": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "transfert d'argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un virement": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un transfert": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "effectuer un virement s\xE9curis\xE9": { ewo: "L\xF3m m\xF3ni \xE9 ne mba\xE1n", phonetic: "l\xF3m m\xF3-n\xED \xE9 n\xE9 m-ba-\xE1n" },
    "envoyer de l'argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "envoyer de l argent": { ewo: "L\xF3m m\xF3ni", phonetic: "l\xF3m m\xF3-n\xED" },
    "envoyer": { ewo: "L\xF3m", phonetic: "l\xF3m" },
    "recevoir de l'argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "recevoir de l argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "recevoir": { ewo: "N\xF2ng", phonetic: "n\xF2\u014B" },
    "retrait": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "retraits": { ewo: "Minl\xF2ng m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF2\u014B m\xED m\xF3-n\xED" },
    "retrait d'argent": { ewo: "N\xF2ng m\xF3ni", phonetic: "n\xF2\u014B m\xF3-n\xED" },
    "retrait au distributeur": { ewo: "N\xF2ng m\xF3ni \xE9 mas\xEDn", phonetic: "n\xF2\u014B m\xF3-n\xED \xE9 ma-s\xEDn" },
    "d\xE9p\xF4t": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "depot": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "d\xE9p\xF4ts": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "depots": { ewo: "Mew\xF3gl\xF4 m\xF3ni", phonetic: "me-w\xF3-gl\xF3 m\xF3-n\xED" },
    "d\xE9p\xF4t d'argent": { ewo: "W\xF3gl\xF4 m\xF3ni", phonetic: "w\xF3-gl\xF3 m\xF3-n\xED" },
    "payer": { ewo: "K\xF9s", phonetic: "k\xF9s" },
    "paiement": { ewo: "T\xF3b\xF3 m\xF3ni", phonetic: "t\xF3-b\xF3 m\xF3-n\xED" },
    "paiements": { ewo: "Mat\xF3b\xF3 m\xF3ni", phonetic: "ma-t\xF3-b\xF3 m\xF3-n\xED" },
    "paiement de facture": { ewo: "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED", phonetic: "t\xF3-b\xF3 m\xF3-n\xED y\xE1 k\xE0-l\xE0-d\xED" },
    "paiement s\xE9curis\xE9": { ewo: "T\xF3b\xF3 m\xF3ni \xE9 ne mba\xE1n", phonetic: "t\xF3-b\xF3 m\xF3-n\xED \xE9 n\xE9 m-ba-\xE1n" },
    "facture": { ewo: "Kalad\xED m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED m\xF3-n\xED" },
    "factures": { ewo: "Mekalad\xED m\xE9 m\xF3ni", phonetic: "me-k\xE0-l\xE0-d\xED m\xE9 m\xF3-n\xED" },
    "re\xE7u": { ewo: "Kalad\xED nl\xE1man", phonetic: "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "recu": { ewo: "Kalad\xED nl\xE1man", phonetic: "k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "re\xE7us": { ewo: "Mekalad\xED nl\xE1man", phonetic: "me-k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "recus": { ewo: "Mekalad\xED nl\xE1man", phonetic: "me-k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger mon re\xE7u": { ewo: "N\xF2ng kalad\xED nl\xE1man", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger le re\xE7u": { ewo: "N\xF2ng kalad\xED nl\xE1man", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED n-l\xE1-m\xE0n" },
    "t\xE9l\xE9charger": { ewo: "N\xF2ng kalad\xED", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED" },
    "telecharger": { ewo: "N\xF2ng kalad\xED", phonetic: "n\xF2\u014B k\xE0-l\xE0-d\xED" },
    // Fees & Economics
    "frais": { ewo: "M\xF3ni m\xE9bemb\xE1", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "frais de transfert": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-l\xF3m" },
    "frais de tenue de compte": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 \xE9k\xF3bl\xF3", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 \xE9-k\xF3-bl\xF3" },
    "frais de retrait": { ewo: "M\xF3ni m\xE9bemb\xE1 m\xE9 nn\xF2ng", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 m\xE9 n-n\xF2\u014B" },
    "frais de timbre fiscal": { ewo: "M\xF3ni m\xE9bemb\xE1 y\xE1 fakat t\xE1l", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 y\xE1 fa-kat t\xE1l" },
    "les frais de timbre fiscal": { ewo: "M\xF3ni m\xE9bemb\xE1 y\xE1 fakat t\xE1l", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 y\xE1 fa-kat t\xE1l" },
    "frais de timbre": { ewo: "M\xF3ni m\xE9bemb\xE1 y\xE1 fakat t\xE1l", phonetic: "m\xF3-n\xED m\xE9-b\xE8m-b\xE1 y\xE1 fa-kat t\xE1l" },
    "timbre fiscal": { ewo: "Fakat t\xE1l", phonetic: "fa-kat t\xE1l" },
    "timbre": { ewo: "Fakat t\xE1l", phonetic: "fa-kat t\xE1l" },
    "sans frais": { ewo: "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1", phonetic: "t\xE9-g\xE9 m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "gratuit": { ewo: "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1", phonetic: "t\xE9-g\xE9 m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "taux": { ewo: "Abui", phonetic: "\xE0-b\xF9\xEC" },
    "taux d'int\xE9r\xEAt": { ewo: "Abui m\xF3ni m\xE9bemb\xE1", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "taux d interet": { ewo: "Abui m\xF3ni m\xE9bemb\xE1", phonetic: "\xE0-b\xF9\xEC m\xF3-n\xED m\xE9-b\xE8m-b\xE1" },
    "cr\xE9dit": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "credit": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "cr\xE9dits": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "credits": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pr\xEAt": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pret": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "pr\xEAts": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "prets": { ewo: "K\xE1l\xE1 m\xF3ni", phonetic: "k\xE1-l\xE1 m\xF3-n\xED" },
    "\xE9pargne": { ewo: "B\xF3m m\xF3ni", phonetic: "b\xF3m m\xF3-n\xED" },
    "epargne": { ewo: "B\xF3m m\xF3ni", phonetic: "b\xF3m m\xF3-n\xED" },
    "tontine": { ewo: "M\xF3ni ts\u0254\u0301", phonetic: "m\xF3-n\xED ts\u0254\u0301" },
    "cotisation": { ewo: "M\xF3ni ts\u0254\u0301", phonetic: "m\xF3-n\xED ts\u0254\u0301" },
    // Parties & Roles
    "b\xE9n\xE9ficiaire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "beneficiaire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "b\xE9n\xE9ficiaires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "beneficiaires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "destinataire": { ewo: "Ny\xED a n\xF2ng m\xF3ni", phonetic: "ny\xED \xE0 n\xF2\u014B m\xF3-n\xED" },
    "destinataires": { ewo: "B\xE1 ba n\xF2ng m\xF3ni", phonetic: "b\xE1 b\xE0 n\xF2\u014B m\xF3-n\xED" },
    "exp\xE9diteur": { ewo: "Ny\xED a l\xF3m m\xF3ni", phonetic: "ny\xED \xE0 l\xF3m m\xF3-n\xED" },
    "expediteur": { ewo: "Ny\xED a l\xF3m m\xF3ni", phonetic: "ny\xED \xE0 l\xF3m m\xF3-n\xED" },
    // History & Transactions
    "historique des transactions": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "historique des op\xE9rations": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "historique": { ewo: "Minl\xF3m m\xED ay\xE1a l\xF3t", phonetic: "m\xEC-n-l\xF3m m\xED \xE0-y\xE1-\xE1 l\xF3t" },
    "transactions r\xE9centes": { ewo: "Minl\xF3m m\xED m\xF3ni m\xEDmpepe", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED m\xEDm-p\xE8-p\xE8" },
    "transactions": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "transaction": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    "op\xE9rations": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "operations": { ewo: "Minl\xF3m m\xED m\xF3ni", phonetic: "m\xEC-n-l\xF3m m\xED m\xF3-n\xED" },
    "op\xE9ration": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    "operation": { ewo: "Nl\xF3m m\xF3ni", phonetic: "n-l\xF3m m\xF3-n\xED" },
    // Security & Authentication
    "s\xE9curit\xE9": { ewo: "Mba\xE1n", phonetic: "m-ba-\xE1n" },
    "securite": { ewo: "Mba\xE1n", phonetic: "m-ba-\xE1n" },
    "s\xE9curis\xE9": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "securise": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "en s\xE9curit\xE9": { ewo: "\xC9 ne mba\xE1n", phonetic: "\xE9 n\xE9 m-ba-\xE1n" },
    "authentification": { ewo: "Y\xEAm \xE9m\xF2t", phonetic: "y\xEAm \xE9-m\xF2t" },
    "connexion": { ewo: "Nyin", phonetic: "nyin" },
    "se connecter": { ewo: "Nyin", phonetic: "nyin" },
    "connectez-vous": { ewo: "Nyin", phonetic: "nyin" },
    "connectez-vous \xE0 votre compte": { ewo: "Nyin \xE9k\xF3bl\xF3 w\xEAn", phonetic: "nyin \xE9-k\xF3-bl\xF3 w\xEAn" },
    "connect\xE9": { ewo: "\xC1 nyin", phonetic: "\xE1 nyin" },
    "connectee": { ewo: "\xC1 nyin", phonetic: "\xE1 nyin" },
    "d\xE9connexion": { ewo: "Kwi", phonetic: "kwi" },
    "se d\xE9connecter": { ewo: "Kwi", phonetic: "kwi" },
    "d\xE9connectez-vous": { ewo: "Kwi", phonetic: "kwi" },
    "carte": { ewo: "Kalad\xED m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED m\xF3-n\xED" },
    "cartes": { ewo: "Mekalad\xED m\xE9 m\xF3ni", phonetic: "me-k\xE0-l\xE0-d\xED m\xE9 m\xF3-n\xED" },
    "carte bancaire": { ewo: "Kalad\xED nda m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED n-da m\xF3-n\xED" },
    "carte de cr\xE9dit": { ewo: "Kalad\xED k\xE1l\xE1 m\xF3ni", phonetic: "k\xE0-l\xE0-d\xED k\xE1-l\xE1 m\xF3-n\xED" },
    "code": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "code secret": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "mot de passe": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "pin": { ewo: "Nd\xE1mb\xE1 ts\xEDti", phonetic: "n-d\xE1m-b\xE1 ts\xED-t\xED" },
    "entrez votre code secret": { ewo: "Tsil\xED nd\xE1mb\xE1 ts\xEDti w\xEAn", phonetic: "ts\xEC-l\xED n-d\xE1m-b\xE1 ts\xED-t\xED w\xEAn" },
    // Buttons & Interactions
    "confirmer le transfert": { ewo: "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3 n-l\xF3m" },
    "confirmer": { ewo: "T\xEDb\xEDli t\xF3b\xF3", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3" },
    "valider": { ewo: "T\xEDb\xEDli t\xF3b\xF3", phonetic: "t\xED-b\xED-l\xED t\xF3-b\xF3" },
    "annuler": { ewo: "Dz\xE1gb\xE1", phonetic: "dz\xE1-gb\xE1" },
    "partager": { ewo: "K\xE1b\xE1n", phonetic: "k\xE1-b\xE1n" },
    "voir": { ewo: "Y\xEAn", phonetic: "y\xEAn" },
    "continuer": { ewo: "K\xEB \xF4su", phonetic: "k\xEB \xF4-su" },
    "suivant": { ewo: "Ny\xED a y\xE1a zu", phonetic: "ny\xED \xE0 y\xE1-\xE1 zu" },
    "pr\xE9c\xE9dent": { ewo: "Ny\xED a l\xF3t", phonetic: "ny\xED \xE0 l\xF3t" },
    "precedent": { ewo: "Ny\xED a l\xF3t", phonetic: "ny\xED \xE0 l\xF3t" },
    "fermer": { ewo: "Dib", phonetic: "dib" },
    "ouvrir": { ewo: "Yob", phonetic: "yob" },
    "supprimer": { ewo: "Dim", phonetic: "dim" },
    "modifier": { ewo: "Tsindin", phonetic: "tsin-din" },
    "enregistrer": { ewo: "B\xF3m", phonetic: "b\xF3m" },
    "recherche": { ewo: "Dz\xEBn", phonetic: "dz\xE8\u014B" },
    "rechercher": { ewo: "Dz\xEBn", phonetic: "dz\xE8\u014B" },
    // Communication, Support & Details
    "aide et support": { ewo: "Nv\xF4l ai nkob\xF3", phonetic: "n-v\xF4l a-\xED n-ko-b\xF3" },
    "aide": { ewo: "Nv\xF4l", phonetic: "n-v\xF4l" },
    "support client": { ewo: "Nv\xF4l \xE9m\xF2t", phonetic: "n-v\xF4l \xE9-m\xF2t" },
    "contactez-nous": { ewo: "K\xF2b\xF2 ai b\xEDa", phonetic: "k\xF2-b\xF2 a-\xED b\xED-a" },
    "contact": { ewo: "K\xF2b\xF2 ai b\xEDa", phonetic: "k\xF2-b\xF2 a-\xED b\xED-a" },
    "t\xE9l\xE9phone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "telephone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "numero de telephone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "num\xE9ro de t\xE9l\xE9phone": { ewo: "Nlamb\xE1 telef\xF4n", phonetic: "n-l\xE0m-b\xE1 t\xE9-l\xE9-f\xF4n" },
    "date": { ewo: "Mos", phonetic: "mos" },
    "heure": { ewo: "Nge\u014B", phonetic: "\u014Be\u014B" },
    "\xE9ch\xE9ance": { ewo: "Mos y\xE1 man\xEB", phonetic: "mos y\xE1 ma-n\xEB" },
    "echeance": { ewo: "Mos y\xE1 man\xEB", phonetic: "mos y\xE1 ma-n\xEB" },
    "statut": { ewo: "Ne d\xE9", phonetic: "ne d\xE9" },
    "r\xE9ussi": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "succ\xE8s": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "succes": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "effectu\xE9": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "effectue": { ewo: "L ay\xE1a d\xFAa", phonetic: "l \xE0-y\xE1-\xE1 d\xFA-\xE1" },
    "\xE9chec": { ewo: "L ab\xEA d\xFAa", phonetic: "l \xE0-b\xE9 d\xFA-\xE1" },
    "echec": { ewo: "L ab\xEA d\xFAa", phonetic: "l \xE0-b\xE9 d\xFA-\xE1" },
    "en cours": { ewo: "\xC9 ng\xE1 b\u0254ban", phonetic: "\xE9 \u014B\xE1 b\xF2-ban" },
    "en attente": { ewo: "\xC9 ng\xE1 yange", phonetic: "\xE9 \u014B\xE1 ya\u014B-ge" },
    "service": { ewo: "\xC9s\xEB", phonetic: "\xE9-s\xEB" },
    "services": { ewo: "M\xE9s\xEB", phonetic: "m\xE9-s\xEB" },
    "nos services": { ewo: "M\xE9s\xEB mama", phonetic: "m\xE9-s\xEB ma-ma" },
    "services bancaires": { ewo: "M\xE9s\xEB m\xE9 nda m\xF3ni", phonetic: "m\xE9-s\xEB m\xE9 n-da m\xF3-n\xED" },
    "notification": { ewo: "Nkat", phonetic: "n-kat" },
    "notifications": { ewo: "Minkat", phonetic: "m\xECn-kat" },
    "message": { ewo: "Nkat", phonetic: "n-kat" },
    "messages": { ewo: "Minkat", phonetic: "m\xECn-kat" },
    "motif du paiement": { ewo: "Asu dz\xE9", phonetic: "a-s\xFA dz\xE9" },
    "motif de paiement": { ewo: "Asu dz\xE9", phonetic: "a-s\xFA dz\xE9" },
    "motif": { ewo: "Asu dz\xE9", phonetic: "a-s\xFA dz\xE9" },
    "raison du paiement": { ewo: "Asu dz\xE9", phonetic: "a-s\xFA dz\xE9" },
    "ref": { ewo: "Nkat", phonetic: "n-kat" },
    "r\xE9f\xE9rence": { ewo: "Nkat", phonetic: "n-kat" },
    "reference": { ewo: "Nkat", phonetic: "n-kat" },
    "bonjour": { ewo: "Mb\xF3lo", phonetic: "m-b\xF3-lo" },
    "bonsoir": { ewo: "Mb\xF3lo ngoge", phonetic: "m-b\xF3-lo \u014Bo-ge" },
    "merci": { ewo: "Ak\xEDba", phonetic: "a-k\xED-ba" },
    "merci de votre confiance": { ewo: "Ak\xEDba", phonetic: "a-k\xED-ba" },
    "oui": { ewo: "\xC9y\xE9", phonetic: "\xE9-y\xE9" },
    "non": { ewo: "T\xE9g\xE9", phonetic: "t\xE9-g\xE9" },
    "attention": { ewo: "T\xE1b\xE9 a\xED mes\xF3", phonetic: "t\xE1-b\xE9 a-\xED me-s\xF3" },
    // Prepositions, Pronouns & Everyday Connectives
    "sur": { ewo: "\xE1", phonetic: "\xE1" },
    "dans": { ewo: "\xE9t\xE9", phonetic: "\xE9-t\xE9" },
    "en": { ewo: "\xE9", phonetic: "\xE9" },
    "pour": { ewo: "as\xFA", phonetic: "a-s\xFA" },
    "avec": { ewo: "a\xED", phonetic: "a-\xED" },
    "sans": { ewo: "t\xE9g\xE9", phonetic: "t\xE9-g\xE9" },
    "vers": { ewo: "\xE9 be", phonetic: "\xE9 be" },
    "de": { ewo: "y\xE1", phonetic: "y\xE1" },
    "du": { ewo: "y\xE1", phonetic: "y\xE1" },
    "des": { ewo: "m\xE9", phonetic: "m\xE9" },
    "et": { ewo: "a\xED", phonetic: "a-\xED" },
    "ou": { ewo: "ng\xE9", phonetic: "ng\xE9" },
    "est": { ewo: "ne", phonetic: "ne" },
    "sont": { ewo: "b\xE9 ne", phonetic: "b\xE9 ne" },
    "votre": { ewo: "w\xEAn", phonetic: "w\xEAn" },
    "vos": { ewo: "m\xEAn", phonetic: "m\xEAn" },
    "notre": { ewo: "w\xEDs", phonetic: "w\xEDs" },
    "nos": { ewo: "m\xEDs", phonetic: "m\xEDs" },
    "mon": { ewo: "wama", phonetic: "wa-ma" },
    "ma": { ewo: "wama", phonetic: "wa-ma" },
    "mes": { ewo: "mama", phonetic: "ma-ma" },
    "tout": { ewo: "m\xEBs\xEB", phonetic: "m\xEB-s\xEB" },
    "tous": { ewo: "b\xEBs\xEB", phonetic: "b\xEB-s\xEB" },
    "toute": { ewo: "\xE9s\xEB", phonetic: "\xE9-s\xEB" },
    "homme": { ewo: "m\xF4t", phonetic: "m\xF4t" },
    "femme": { ewo: "minga", phonetic: "min-ga" },
    "personne": { ewo: "m\xF4t", phonetic: "m\xF4t" },
    "gens": { ewo: "b\xF4t", phonetic: "b\xF4t" },
    "village": { ewo: "dzal", phonetic: "dzal" },
    "porte": { ewo: "mb\xE8", phonetic: "m-b\xE8" },
    "annee": { ewo: "mbu", phonetic: "m-bu" },
    "ann\xE9e": { ewo: "mbu", phonetic: "m-bu" },
    "jour": { ewo: "mos", phonetic: "mos" },
    "mois": { ewo: "ngon", phonetic: "ngon" }
  };
  var frToEwoMap = /* @__PURE__ */ new Map();
  var enToEwoMap = /* @__PURE__ */ new Map();
  var ewoPhoneticMap = /* @__PURE__ */ new Map();
  function registerBilingualTerm(fraRaw, enRaw, ewo, phonetic) {
    if (phonetic) {
      ewoPhoneticMap.set(ewo.toLowerCase().trim(), phonetic);
    }
    const fraParts = fraRaw.split(/[\/;]/).map((s) => s.toLowerCase().trim()).filter(Boolean);
    for (const part of fraParts) {
      frToEwoMap.set(part, ewo);
    }
    const fullFra = fraRaw.toLowerCase().trim();
    if (!frToEwoMap.has(fullFra)) {
      frToEwoMap.set(fullFra, ewo);
    }
    if (enRaw) {
      const enParts = enRaw.split(/[\/;]/).map((s) => s.toLowerCase().trim()).filter(Boolean);
      for (const part of enParts) {
        enToEwoMap.set(part, ewo);
      }
      const fullEn = enRaw.toLowerCase().trim();
      if (!enToEwoMap.has(fullEn)) {
        enToEwoMap.set(fullEn, ewo);
      }
    }
  }
  for (const entry of APERTIUM_EWONDO_ENTRIES) {
    const normFra = entry.fra.toLowerCase().trim();
    if (normFra && entry.ewo) {
      if (!frToEwoMap.has(normFra)) {
        frToEwoMap.set(normFra, entry.ewo);
      }
    }
  }
  for (const term of FINANCIAL_GLOSSARY_ENTRIES) {
    registerBilingualTerm(term.fra, term.en, term.ewo, term.phonetic);
  }
  for (const [key, val] of Object.entries(EXTENDED_BANKING_UI_LEXICON)) {
    registerBilingualTerm(key, val.en, val.ewo, val.phonetic);
  }
  var ENGLISH_COMMON_ENTRIES = {
    "what we do": "Dzam b\xED \xE1 b\xF4",
    "venture capital": "M\xF3ni \xE9sy\xE9",
    "impact": "Mb\xE9b\u0259\u0301",
    "insights": "Nf\xED \xE1y\u0259\u030C f\u0259\u0300k",
    "about": "\xC9 b\xEDs\xED\xE9 b\xEDs\u0259",
    "about us": "\xC9 b\xEDs\xED\xE9 b\xEDs\u0259",
    "helping": "V\xF3l",
    "turn": "Ts\xEE\u014B",
    "skills": "Ak\xF3b\xF3",
    "skill": "Ak\xF3b\xF3",
    "into": "\xC9",
    "jobs": "\xC9sy\xE9",
    "job": "\xC9sy\xE9",
    "businesses": "Nkap",
    "offers": "\xC1 v\u025B\u030C",
    "offer": "V\u025B\u030C",
    "hands-on": "\xC9k\u0254\u0300\u014B \xE9sy\xE9",
    "training": "Ay\u0259\u0301g\u0259\u0301l\xE1",
    "develop": "Y\xF3b\u0259\u0301",
    "ideas": "F\u0259\u0300k",
    "idea": "F\u0259\u0300k",
    "welcome": "Ny\u0259\u030C\u014B",
    "universities": "Nd\xE1 b\u0259k\xF3b\xF3",
    "university": "Nd\xE1 b\u0259k\xF3b\xF3",
    "employers": "B\xE9k\xF4n \xE9sy\xE9",
    "employer": "Nk\xF4n \xE9sy\xE9",
    "investors": "B\u0259\u0301s\u0259\u0301g\xED m\xF3ni",
    "investor": "Ns\u0259\u0301g\xED m\xF3ni",
    "want": "Y\xED",
    "support": "V\xF3l",
    "work": "\xC9sy\xE9",
    "find": "J\u0259\u014B",
    "get": "K\xFAs",
    "startup": "\xC9sy\xE9",
    "funding": "M\xF3ni",
    "computer": "k\u0254mp\xFAt\xE0",
    "lab": "\xC9f\xEDl\u0259",
    "laboratory": "\xC9f\xEDl\u0259",
    "platform": "\xE9f\xEDl\u0259",
    "center": "nda",
    // Navigation & Web menus
    "venture": "\xE9s\xE1ma",
    "contact": "K\xF3b\u0254\u0301 a\xED b\xEDa",
    "contact us": "K\xF3b\u0254\u0301 a\xED b\xEDa",
    "home": "Nda",
    "services": "M\xEDsa\xE9",
    "service": "\xC9sa\xE9",
    "careers": "M\xEDsa\xE9",
    "pricing": "M\xF3ni y\xE1 bise",
    "help": "Volo",
    "faq": "Mins\xEDl\xED a\xED meyal\xE1n",
    "blog": "F\xF3\xE9",
    "news": "F\xF3\xE9",
    "terms": "Mimb\xF3gl\xE1n",
    "privacy": "Mba\xE1n",
    "login": "Nyin",
    "sign in": "Nyin",
    "sign up": "Tili dz\xF3\xE9",
    "register": "Tili dz\xF3\xE9",
    "logout": "Kud\xFA",
    // General Conversational & Form Vocabulary
    "vocational education": "Ny\xE9gl\xE1n y\xE1 \xE9s\xE1ma",
    "say hello": "K\xF3b\u0254\u0301 Mb\xF3lo",
    "hello": "Mb\xF3lo",
    "hi": "Mb\xF3lo",
    "say": "k\xF3b\u0254\u0301",
    "send": "l\xF3m",
    "enquiry": "ns\xEDl\xED",
    "choose": "tob\xF4",
    "route": "nz\u025Bn",
    "team": "nk\xF4la",
    "direct": "l\xE9d\xED",
    "form": "k\xE1lada",
    "anything else": "mam m\xE9fe",
    // Core Nouns & Concepts
    "building": "nl\xF3nan",
    "build": "l\xF3n",
    "people": "b\xF4t",
    "person": "m\xF4t",
    "enterprises": "m\xEDmb\xF3gl\xE1n",
    "enterprise": "\xE9s\xE1ma",
    "productive": "y\xE1 mbuma",
    "systems": "mimb\xF3g",
    "system": "mb\xF3g",
    "cameroon": "Kam\u0259r\xFAn",
    "africa": "Afrik\xE1",
    "ecosystem": "mv\xF4k",
    "vocational": "y\xE1 \xE9s\xE1ma",
    "education": "ny\xE9gl\xE1n",
    "entrepreneurship": "\xE9s\xE1ma",
    "innovation": "mf\xE9f\xE9 mam",
    "capital": "m\xF3ni",
    "money": "m\xF3ni",
    "finance": "m\xF3ni",
    "financial": "y\xE1 m\xF3ni",
    "inclusion": "nyin asese",
    "connecting": "lad\xED",
    "connect": "lad\xED",
    "partner": "mv\xE1ba",
    "partners": "bemv\xE1ba",
    "community": "ay\u0254\u014B",
    "future": "melu mazu",
    "growth": "nk\u0254lan",
    "development": "nk\u0254lan",
    "business": "\xE9s\xE1ma",
    "company": "\xE9s\xE1ma",
    "message": "nk\xF3b\xF3",
    "phone": "f\xF3n",
    "mobile": "f\xF3n",
    "email": "nk\xF3b\xF3",
    "name": "dz\xF3\xE9",
    "account": "\xE9k\xF3bl\xF3",
    "balance": "m\xF3ni m\xED ne",
    "transfer": "l\xF3m m\xF3ni",
    "save": "b\xF3m m\xF3ni",
    "savings": "m\xF3ni m\xE9b\xF3man",
    "bank": "nda m\xF3ni",
    "banking": "nda m\xF3ni",
    "submit": "l\xF3m",
    "click": "fidi",
    "touch": "t\xE1mb\xED",
    "listen": "w\xF3g",
    "speak": "k\xF3b\u0254\u0301",
    "translate": "k\xF3b\u0254\u0301 \xE9fe",
    "security": "mba\xE1n",
    "secure": "mba\xE1n",
    "safe": "mba\xE1n",
    "trust": "mb\xFAmban",
    "customer": "nk\xFAs",
    "clients": "bink\xFAs",
    "client": "nk\xFAs",
    "user": "m\xF4t a bel\xE1n",
    "users": "b\xF4t ba bel\xE1n",
    "world": "si",
    "country": "\xE9y\u0254\u014B",
    "city": "titi",
    "village": "dzal",
    "code": "ndamba",
    "number": "namba",
    "fee": "m\xF3ni m\xE9bemb\xE1",
    "fees": "m\xF3ni m\xE9bemb\xE1",
    "amount": "m\xF3ni",
    "currency": "m\xF3ni",
    "loan": "nk\xF3l",
    "credit": "nk\xF3l",
    "payment": "ya m\xF3ni",
    "card": "k\xE1lada m\xF3ni",
    "rate": "m\xF3ni",
    "time": "\xE9y\u0254\u014B",
    "today": "\xE1n\xE1",
    "day": "am\xF4s",
    "history": "minl\xF3m m\xED ay\xE1a l\xF3t",
    // Prepositions & Connectors
    "for": "as\xFA y\xE1",
    "and": "a\xED",
    "or": "ng\xE9",
    "in": "\xE9t\xE9",
    "at": "\xE9",
    "to": "\xE9 be",
    "of": "y\xE1",
    "with": "a\xED",
    "from": "as\xFA",
    "is": "a ne",
    "are": "b\xE1 ne",
    "our": "d\xEDs\xF3",
    "your": "w\xEAn",
    "my": "dama",
    "their": "d\xE1b\xE1",
    "all": "m\xE9se",
    "more": "abui",
    "new": "mf\xE9f\xE9",
    "good": "mb\u0259mb\u0259",
    "great": "an\u025Bn",
    "yes": "\u0254w\u025B",
    "no": "t\xE9gu\xE9",
    // Banking & Financial Operations (English)
    "available balance": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
    "current balance": "M\xF3ni m\xED ne n\xE1n\xE1",
    "account balance": "M\xF3ni m\xED ne",
    "insufficient funds": "M\xF3ni m\xED ne t\xE9gu\xE9 abui",
    "insufficient balance": "M\xF3ni m\xED ne t\xE9gu\xE9 abui",
    "money transfer": "L\xF3m m\xF3ni",
    "transfer money": "L\xF3m m\xF3ni",
    "make a transfer": "L\xF3m m\xF3ni",
    "make a money transfer": "L\xF3m m\xF3ni",
    "send money": "L\xF3m m\xF3ni",
    "receive money": "N\xF2ng m\xF3ni",
    "cash withdrawal": "N\xF2ng m\xF3ni",
    "cash withdraw": "N\xF2ng m\xF3ni",
    "withdraw money": "N\xF2ng m\xF3ni",
    "withdraw cash": "N\xF2ng m\xF3ni",
    "cash out": "N\xF2ng m\xF3ni",
    "cash in": "W\xF3gl\xF4 m\xF3ni",
    "deposit money": "W\xF3gl\xF4 m\xF3ni",
    "deposit cash": "W\xF3gl\xF4 m\xF3ni",
    "make a deposit": "W\xF3gl\xF4 m\xF3ni",
    "make a withdrawal": "N\xF2ng m\xF3ni",
    "confirm transfer": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
    "confirm payment": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
    "confirm transaction": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
    "cancel transfer": "Dz\xE1gb\xE1 nl\xF3m",
    "cancel transaction": "Dz\xE1gb\xE1 nl\xF3m",
    "transfer fees": "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m",
    "withdrawal fees": "M\xF3ni m\xE9bemb\xE1 m\xE9 nn\xF2ng",
    "account maintenance fees": "M\xF3ni m\xE9bemb\xE1 m\xE9 \xE9k\xF3bl\xF3",
    "maintenance fees": "M\xF3ni m\xE9bemb\xE1 m\xE9 \xE9k\xF3bl\xF3",
    "free of charge": "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1",
    "zero fees": "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1",
    "no fees": "T\xE9g\xE9 m\xF3ni m\xE9bemb\xE1",
    "account statement": "Kalad\xED \xE9k\xF3bl\xF3",
    "bank statement": "Kalad\xED \xE9k\xF3bl\xF3",
    "savings account": "\xC9k\xF3bl\xF3 b\xF3m m\xF3ni",
    "current account": "\xC9k\xF3bl\xF3 \xE9t\xE1m",
    "checking account": "\xC9k\xF3bl\xF3 \xE9t\xE1m",
    "main account": "\xC9k\xF3bl\xF3 m\xF3ni ya \xE9t\xE1m",
    "account number": "Nlamb\xE1 \xE9k\xF3bl\xF3",
    "bank account": "\xC9k\xF3bl\xF3 nda m\xF3ni",
    "phone number": "Nlamb\xE1 telef\xF4n",
    "mobile number": "Nlamb\xE1 telef\xF4n",
    "recipient phone": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni",
    "recipient number": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni",
    "recipient mobile number": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni",
    "secret pin": "Nd\xE1mb\xE1 ts\xEDti",
    "pin code": "Nd\xE1mb\xE1 ts\xEDti",
    "enter your pin": "Tsil\xED nd\xE1mb\xE1 ts\xEDti w\xEAn",
    "enter pin": "Tsil\xED nd\xE1mb\xE1 ts\xEDti",
    "one-time password": "Nd\xE1mb\xE1 ts\xEDti \xE9y\u0254\u014B zia",
    "transaction history": "Minl\xF3m m\xED ay\xE1a l\xF3t",
    "transaction details": "Mimb\xF2n\xE1n m\xE9 nl\xF3m m\xF3ni",
    "transaction ID": "Nkat nl\xF3m m\xF3ni",
    "reference number": "Nkat nl\xF3m",
    "payment receipt": "Kalad\xED nl\xE1man",
    "digital receipt": "Kalad\xED nl\xE1man",
    "proof of payment": "Kalad\xED nl\xE1man",
    "download receipt": "N\xF2ng kalad\xED nl\xE1man",
    "view receipt": "Y\xEAn kalad\xED nl\xE1man",
    "transfer successful": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa",
    "transaction successful": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa",
    "payment successful": "T\xF3b\xF3 m\xF3ni l'ay\xE1a d\xFAa",
    "transfer failed": "L\xF3m m\xF3ni l'ab\xEA d\xFAa",
    "transaction failed": "L\xF3m m\xF3ni l'ab\xEA d\xFAa",
    "bill payment": "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED",
    "pay bills": "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED",
    "pay bill": "T\xF3b\xF3 m\xF3ni y\xE1 kalad\xED",
    "merchant payment": "T\xF3b\xF3 m\xF3ni nk\xFAs",
    "merchant code": "Nd\xE1mb\xE1 nk\xFAs",
    "scan to pay": "Nd\xE1mb\xE1 scan",
    "airtime recharge": "K\xF9s f\xF3n",
    "buy airtime": "K\xF9s f\xF3n",
    "mobile recharge": "K\xF9s f\xF3n",
    "data bundle": "K\xF9s f\xF3n",
    "tontine contribution": "M\xF3ni ts\u0254\u0301",
    "tontine turn": "\xC9y\u0254\u014B ts\u0254\u0301",
    "tontine meeting": "Esul\xE1n ts\u0254\u0301",
    "tontine payout": "N\xF2ng m\xF3ni ts\u0254\u0301",
    "microfinance institution": "Nda m\xF3ni ts\u0254\u0301",
    "microfinance": "Nda m\xF3ni ts\u0254\u0301",
    "personal loan": "K\xE1l\xE1 m\xF3ni",
    "loan repayment": "K\xF9s k\xE1l\xE1 m\xF3ni",
    "repay loan": "K\xF9s k\xE1l\xE1 m\xF3ni",
    "interest rate": "Abui m\xF3ni m\xE9bemb\xE1",
    "due date": "Mos y\xE1 man\xEB",
    "bank card": "Kalad\xED nda m\xF3ni",
    "debit card": "Kalad\xED m\xF3ni",
    "credit card": "Kalad\xED k\xE1l\xE1 m\xF3ni",
    "block card": "Dib kalad\xED m\xF3ni",
    "unblock card": "Yob kalad\xED m\xF3ni",
    "total amount": "Abui m\xF3ni m\xE9s\xEB",
    "transfer amount": "Abui m\xF3ni y\xE1 nl\xF3m",
    "payment amount": "Abui m\xF3ni y\xE1 t\xF3b\xF3",
    "automated teller machine": "Mas\xEDn m\xF3ni",
    "atm": "Mas\xEDn m\xF3ni",
    "branch": "T\xF2 nda m\xF3ni",
    "secured transfer": "L\xF3m m\xF3ni \xE9 ne mba\xE1n",
    "secured payment": "T\xF3b\xF3 m\xF3ni \xE9 ne mba\xE1n",
    "secure banking": "Nda m\xF3ni \xE9 ne mba\xE1n",
    "in progress": "\xC9 ng\xE1 b\u0254ban",
    "pending": "\xC9 ng\xE1 yange",
    "orange money": "Orange Money",
    "mtn momo": "MTN MoMo",
    "mobile money": "M\xF3ni f\xF3n",
    "purpose of payment": "Asu dz\xE9",
    "payment reason": "Asu dz\xE9"
  };
  for (const [enWord, ewoWord] of Object.entries(ENGLISH_COMMON_ENTRIES)) {
    enToEwoMap.set(enWord.toLowerCase().trim(), ewoWord);
  }
  var FRENCH_COMMON_ENTRIES = {
    "ce que nous faisons": "Dzam b\xED \xE1 b\xF4",
    "capital-risque": "M\xF3ni m\xEDmb\xF3gl\xE1n",
    "capital risque": "M\xF3ni m\xEDmb\xF3gl\xE1n",
    "impact": "Ngul",
    "actualit\xE9s": "F\xF3\xE9",
    "nouvelles": "F\xF3\xE9",
    "\xE0 propos": "As\xFA",
    "\xE0 propos de nous": "As\xFA y\xE1 b\xEDa",
    "contact": "K\xF3b\u0254\u0301 a\xED b\xEDa",
    "contactez-nous": "K\xF3b\u0254\u0301 a\xED b\xEDa",
    "nous contacter": "K\xF3b\u0254\u0301 a\xED b\xEDa",
    "accueil": "Nda",
    "services": "M\xEDsa\xE9",
    "service": "\xC9sa\xE9",
    "carri\xE8res": "M\xEDsa\xE9",
    "tarifs": "M\xF3ni y\xE1 bise",
    "assistance": "Volo",
    "aide": "Volo",
    "termes": "Mimb\xF3gl\xE1n",
    "conditions": "Mimb\xF3gl\xE1n",
    "confidentialit\xE9": "Mba\xE1n",
    "connexion": "Nyin",
    "se connecter": "Nyin",
    "s inscrire": "Tili dz\xF3\xE9",
    "inscription": "Tili dz\xF3\xE9",
    "d\xE9connexion": "Kud\xFA",
    "construire": "l\xF3n",
    "b\xE2tir": "l\xF3n",
    "construction": "nl\xF3nan",
    "personnes": "b\xF4t",
    "gens": "b\xF4t",
    "entreprises": "m\xEDmb\xF3gl\xE1n",
    "entreprise": "\xE9s\xE1ma",
    "productifs": "y\xE1 mbuma",
    "productif": "y\xE1 mbuma",
    "syst\xE8mes": "mimb\xF3g",
    "syst\xE8me": "mb\xF3g",
    "cameroun": "Kam\u0259r\xFAn",
    "afrique": "Afrik\xE1",
    "\xE9cosyst\xE8me": "mv\xF4k",
    "professionnelle": "y\xE1 \xE9s\xE1ma",
    "formation": "ny\xE9gl\xE1n",
    "entrepreneuriat": "\xE9s\xE1ma",
    "innovation": "mf\xE9f\xE9 mam",
    "capital": "m\xF3ni",
    "connecter": "lad\xED",
    "relier": "lad\xED",
    "partenaires": "bemv\xE1ba",
    "partenaire": "mv\xE1ba",
    "communaut\xE9": "ay\u0254\u014B",
    "avenir": "melu mazu",
    "croissance": "nk\u0254lan",
    "d\xE9veloppement": "nk\u0254lan",
    "affaires": "\xE9s\xE1ma",
    "soci\xE9t\xE9": "\xE9s\xE1ma",
    "formulaire": "k\xE1lada",
    "s\xE9lectionner": "tob\xF4",
    "choisir": "tob\xF4",
    "\xE9quipe": "nk\xF4la",
    "route": "nz\u025Bn",
    "chemin": "nz\u025Bn",
    "0": "z\xE9lo",
    "1": "f\u0254\u0301k",
    "2": "b\u025B\u030C",
    "3": "l\u01CEl",
    "4": "ny\u01D0n",
    "5": "t\xE1n",
    "6": "sam\u0259\u0301n",
    "7": "zangb\xE1",
    "8": "mw\xF4m",
    "9": "eb\xFAl",
    "10": "aw\xF3m",
    "01": "f\u0254\u0301k",
    "02": "b\u025B\u030C",
    "03": "l\u01CEl",
    "04": "ny\u01D0n",
    "05": "t\xE1n",
    "06": "sam\u0259\u0301n",
    "07": "zangb\xE1",
    "08": "mw\xF4m",
    "09": "eb\xFAl",
    "un": "f\u0254\u0301k",
    "une": "f\u0254\u0301k",
    "deux": "b\u025B\u030C",
    "trois": "l\u01CEl",
    "quatre": "ny\u01D0n",
    "cinq": "t\xE1n",
    "six": "sam\u0259\u0301n",
    "sept": "zangb\xE1",
    "huit": "mw\xF4m",
    "neuf": "eb\xFAl",
    "dix": "aw\xF3m",
    "one": "f\u0254\u0301k",
    "two": "b\u025B\u030C",
    "three": "l\u01CEl",
    "four": "ny\u01D0n",
    "five": "t\xE1n",
    "seven": "zangb\xE1",
    "eight": "mw\xF4m",
    "nine": "eb\xFAl",
    "ten": "aw\xF3m"
  };
  for (const [frWord, ewoWord] of Object.entries(FRENCH_COMMON_ENTRIES)) {
    frToEwoMap.set(frWord.toLowerCase().trim(), ewoWord);
  }
  function lookupEwondoWord(frenchWord) {
    const norm = frenchWord.toLowerCase().trim();
    return frToEwoMap.get(norm) || null;
  }
  function lookupEwondoFromEnglish(englishWord) {
    const norm = englishWord.toLowerCase().trim();
    return enToEwoMap.get(norm) || null;
  }
  function getEwondoPhonetic(ewondoText) {
    const norm = ewondoText.toLowerCase().trim();
    if (ewoPhoneticMap.has(norm)) {
      return ewoPhoneticMap.get(norm);
    }
    let working = norm;
    const multiWordPhonetics = Array.from(ewoPhoneticMap.keys()).filter((k) => k.includes(" ") || k.includes("'")).sort((a, b) => b.length - a.length);
    for (const phrase of multiWordPhonetics) {
      if (working.includes(phrase)) {
        working = working.split(phrase).join(ewoPhoneticMap.get(phrase));
      }
    }
    const tokens = working.split(/(\s+|[,;:.!?()\/\-])/);
    const phoneticTokens = tokens.map((tok) => {
      if (ewoPhoneticMap.has(tok.toLowerCase())) {
        return ewoPhoneticMap.get(tok.toLowerCase());
      }
      return tok.replace(/ɔ́/g, "\xF3").replace(/ɔ̀/g, "\xF2").replace(/ɔ/g, "o").replace(/ɛ́/g, "\xE9").replace(/ɛ̀/g, "\xE8").replace(/ɛ/g, "e").replace(/ə́/g, "\xE9").replace(/ə̀/g, "\xE8").replace(/ə/g, "e").replace(/ë/g, "e").replace(/kp/g, "kp").replace(/gb/g, "gb").replace(/[\u0300-\u036f]/g, "");
    });
    return phoneticTokens.join("");
  }
  function extractAndGuardEntities(text) {
    const spans = [];
    const PATTERNS = [
      // Monetary amounts with currencies (FCFA, XAF, CFA, EUR, USD, etc.) or k multiplier
      /\b(?:\d[\d\s,\.]*(?:\s*\d{3})*|\d+(?:[.,]\d+)?\s*k)\s*(?:FCFA|XAF|CFA|EUR|USD|GBP|NGN|GHS|FRS|F)\b/gi,
      // Formatted IBANs & banking account numbers (spaced or unspaced)
      /\b[A-Z]{2}\d{2}(?:[\s-]?[A-Z0-9]{4}){2,7}(?:[\s-]?[A-Z0-9]{1,4})?\b|\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/gi,
      // Transaction IDs & references (TXN, REF, ID, ORDER, #)
      /\b(?:TXN|REF|ID|ORDER|TX-)[A-Z0-9\-]{4,25}\b/gi,
      /#\d{3,10}\b/g,
      // Phone numbers (Cameroonian +237, 00237, 237, or 9-digit local)
      /(?:^|[^\w+])((?:\+237|00237|237)?[\s-]?[6-9](?:[\s-]?\d){8})\b/g,
      // Percentages
      /\b\d+(?:[.,]\d+)?\s*(?:%|pour\s*cent\b|percent\b)/gi
    ];
    for (const pat of PATTERNS) {
      const rx = new RegExp(pat.source, pat.flags);
      let m;
      while ((m = rx.exec(text)) !== null) {
        let raw = m[0];
        let start = m.index;
        if (m[1]) {
          raw = m[1].trim();
          start = m.index + m[0].indexOf(raw);
        }
        const end = start + raw.length;
        spans.push({ start, end, raw });
      }
    }
    spans.sort((a, b) => a.start - b.start);
    const nonOverlapping = [];
    for (const span of spans) {
      if (nonOverlapping.length === 0) {
        nonOverlapping.push(span);
        continue;
      }
      const last = nonOverlapping[nonOverlapping.length - 1];
      if (span.start < last.end) {
        if (span.end - span.start > last.end - last.start) {
          nonOverlapping[nonOverlapping.length - 1] = span;
        }
      } else {
        nonOverlapping.push(span);
      }
    }
    const entities = [];
    let result = "";
    let cursor = 0;
    for (let i = 0; i < nonOverlapping.length; i++) {
      const s = nonOverlapping[i];
      result += text.slice(cursor, s.start);
      const placeholder = `___FIN_GUARD_${i}___`;
      result += placeholder;
      entities.push({ placeholder, raw: s.raw, start: s.start, end: s.end });
      cursor = s.end;
    }
    result += text.slice(cursor);
    return { guardedText: result, entities };
  }
  function translateSentenceToEwondo(text) {
    const trimmed = text.trim();
    if (!trimmed) return text;
    const { guardedText, entities } = extractAndGuardEntities(trimmed);
    const exact = lookupEwondoWord(guardedText) || lookupEwondoFromEnglish(guardedText);
    if (exact) {
      let result = exact;
      if (guardedText === guardedText.toUpperCase() && guardedText.length > 1) {
        result = exact.toUpperCase();
      } else if (guardedText[0] === guardedText[0].toUpperCase()) {
        result = exact.charAt(0).toUpperCase() + exact.slice(1);
      }
      for (const ent of entities) {
        result = result.split(ent.placeholder).join(ent.raw);
      }
      return result;
    }
    let workingText = guardedText;
    const multiWordKeys = [
      ...Array.from(frToEwoMap.keys()),
      ...Array.from(enToEwoMap.keys())
    ].filter((k) => k.includes(" ") || k.includes("'")).sort((a, b) => b.length - a.length);
    for (const phrase of multiWordKeys) {
      const escaped = escapeRegExp(phrase);
      const regex = new RegExp(`(?:^|([^\\p{L}\\p{N}]))${escaped}(?=[^\\p{L}\\p{N}]|$)`, "giu");
      if (regex.test(workingText)) {
        const repl = frToEwoMap.get(phrase) || enToEwoMap.get(phrase);
        workingText = workingText.replace(regex, (_m, p1 = "") => {
          return p1 + repl;
        });
      }
    }
    const words = workingText.split(/(\s+|[,;:.!?()\/\-]|<\/?t\d+>|⟦T\d+:|⟧|(?<=[ldcsqnjm]['’])(?=[\p{L}]))/u);
    const translatedTokens = [];
    for (let i = 0; i < words.length; i++) {
      const token = words[i];
      if (!token) continue;
      if (/^(\s+|[,;:.!?()\/\-])$/.test(token)) {
        translatedTokens.push(token);
        continue;
      }
      if (/^___FIN_GUARD_\d+___$/.test(token) || /^<\/?t\d+>$/.test(token) || /^⟦T\d+:$/.test(token) || token === "\u27E7") {
        translatedTokens.push(token);
        continue;
      }
      const directMatch = lookupEwondoWord(token) || lookupEwondoFromEnglish(token);
      if (directMatch) {
        let result = directMatch;
        if (token === token.toUpperCase() && token.length > 1) {
          result = directMatch.toUpperCase();
        } else if (token[0] === token[0].toUpperCase()) {
          result = directMatch.charAt(0).toUpperCase() + directMatch.slice(1);
        }
        translatedTokens.push(result);
        continue;
      }
      if (/^[\d\s.,\u00a0]+$/.test(token) || /^(FCFA|XAF|CFA|EUR|USD|XOF)$/i.test(token)) {
        translatedTokens.push(token);
        continue;
      }
      if (/^[ldcsqnjm]['’]$/i.test(token)) {
        let nextWordIdx = i + 1;
        while (nextWordIdx < words.length && !words[nextWordIdx]) nextWordIdx++;
        if (nextWordIdx < words.length) {
          const nextWord = words[nextWordIdx];
          const matchNext = lookupEwondoWord(nextWord);
          if (matchNext) {
            let result = matchNext;
            if (nextWord === nextWord.toUpperCase() && nextWord.length > 1) {
              result = matchNext.toUpperCase();
            } else if (token[0] === token[0].toUpperCase()) {
              result = matchNext.charAt(0).toUpperCase() + matchNext.slice(1);
            }
            translatedTokens.push(result);
            i = nextWordIdx;
            continue;
          }
        }
        translatedTokens.push(token);
        continue;
      }
      translatedTokens.push(token);
    }
    let finalTranslation = translatedTokens.join("");
    for (const ent of entities) {
      finalTranslation = finalTranslation.split(ent.placeholder).join(ent.raw);
    }
    return finalTranslation;
  }
  function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function extractAndGuardEntities2(text) {
    const spans = [];
    const PATTERNS = [
      /\b(?:\d[\d\s,\.]*(?:\s*\d{3})*|\d+(?:[.,]\d+)?\s*k)\s*(?:FCFA|XAF|CFA|EUR|USD|GBP|NGN|GHS|FRS|F)\b/gi,
      /\b[A-Z]{2}\d{2}(?:[\s-]?[A-Z0-9]{4}){2,7}(?:[\s-]?[A-Z0-9]{1,4})?\b|\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/gi,
      /\b(?:TXN|REF|ID|ORDER|TX-)[A-Z0-9\-]{4,25}\b/gi,
      /#\d{3,10}\b/g,
      /(?:^|[^\w+])((?:\+237|00237|237)?[\s-]?[6-9](?:[\s-]?\d){8})\b/g,
      /\b\d+(?:[.,]\d+)?\s*(?:%|pour\s*cent\b|percent\b)/gi
    ];
    for (const pat of PATTERNS) {
      const rx = new RegExp(pat.source, pat.flags);
      let m;
      while ((m = rx.exec(text)) !== null) {
        let raw = m[0];
        let start = m.index;
        if (m[1]) {
          raw = m[1].trim();
          start = m.index + m[0].indexOf(raw);
        }
        const end = start + raw.length;
        spans.push({ start, end, raw });
      }
    }
    spans.sort((a, b) => a.start - b.start);
    const nonOverlapping = [];
    for (const span of spans) {
      if (nonOverlapping.length === 0) {
        nonOverlapping.push(span);
        continue;
      }
      const last = nonOverlapping[nonOverlapping.length - 1];
      if (span.start < last.end) {
        if (span.end - span.start > last.end - last.start) {
          nonOverlapping[nonOverlapping.length - 1] = span;
        }
      } else {
        nonOverlapping.push(span);
      }
    }
    const entities = [];
    let result = "";
    let cursor = 0;
    for (let i = 0; i < nonOverlapping.length; i++) {
      const s = nonOverlapping[i];
      result += text.slice(cursor, s.start);
      const placeholder = `___FIN_GUARD_${i}___`;
      result += placeholder;
      entities.push({ placeholder, raw: s.raw, start: s.start, end: s.end });
      cursor = s.end;
    }
    result += text.slice(cursor);
    return { guardedText: result, entities };
  }
  var SOVEREIGN_DICTIONARIES = {
    // ==========================================
    // 1. FULFULDE / PEUL (fuv-CM / fuv)
    // ==========================================
    fuv: {
      "0": "bolum",
      "1": "go'o",
      "2": "\u0257i\u0257i",
      "3": "tati",
      "4": "nay",
      "5": "jowi",
      "6": "jee-go'o",
      "7": "jee-\u0257i\u0257i",
      "8": "jee-tati",
      "9": "jee-nay",
      "10": "sappo",
      "01": "go'o",
      "02": "\u0257i\u0257i",
      "03": "tati",
      "04": "nay",
      "05": "jowi",
      "06": "jee-go'o",
      "07": "jee-\u0257i\u0257i",
      "08": "jee-tati",
      "09": "jee-nay",
      "un": "go'o",
      "une": "go'o",
      "deux": "\u0257i\u0257i",
      "trois": "tati",
      "quatre": "nay",
      "cinq": "jowi",
      "six": "jee-go'o",
      "sept": "jee-\u0257i\u0257i",
      "huit": "jee-tati",
      "neuf": "jee-nay",
      "dix": "sappo",
      "one": "go'o",
      "two": "\u0257i\u0257i",
      "three": "tati",
      "four": "nay",
      "five": "jowi",
      "seven": "jee-\u0257i\u0257i",
      "eight": "jee-tati",
      "nine": "jee-nay",
      "ten": "sappo",
      "what we do": "Ko min ngollata",
      "venture capital": "Ceede njulaaku",
      "impact": "Battane lob\u0253e",
      "insights": "Paamki e humpito",
      "about": "Kala amen",
      "about us": "Kala amen",
      "and": "e",
      "et": "e",
      "that": "ngal",
      "helps": "\u0257on walla",
      "helping": "Wallugo",
      "people": "Yim\u0253e",
      "turn": "Waylitugo",
      "skills": "Gandal",
      "skill": "Gandal",
      "into": "Wonta",
      "jobs": "Kuu\u0257e",
      "job": "Kuugal",
      "businesses": "Njulaaku",
      "business": "Njulaaku",
      "in": "Nder",
      "cameroon": "Kamerun",
      "offers": "\u018Aon hokka",
      "hands-on": "Kuu\u0257e juude",
      "training": "Ekkitinol",
      "develop": "\u0181amta",
      "ideas": "Miijooji",
      "idea": "Miijo",
      "we": "En",
      "welcome": "En \u0257on ja\u0253\u0253oo",
      "universities": "Jaa\u0253i-haatireeji",
      "university": "Jaa\u0253i-haatire",
      "employers": "Jom en kuu\u0257e",
      "employer": "Jom kuugal",
      "investors": "Wattoo\u0253e ceede",
      "investor": "Gattoowo ceede",
      "who": "\u0181e",
      "want": "Yi\u0257i",
      "support": "Wallugo",
      "work": "Kuugal",
      "find": "Teftu",
      "get": "He\u0253u",
      "startup": "Njulaaku kesu",
      "funding": "Ceede",
      "lab": "Nokku",
      "laboratory": "Nokku ekkitinol",
      "computer": "Kompiyuta",
      "platform": "dallol",
      "center": "nokku",
      "growth": "\u0253amtaare",
      "education": "janngirde",
      "community": "jama'aare",
      "our": "amen",
      "yaound\xE9": "Yaound\xE9",
      "yaounde": "Yaound\xE9",
      "douala": "Douala",
      "say hello": "Jam waali",
      "enquiry": "Yamiroore",
      "choose": "Su\u0253o",
      "matches": "Hawri",
      "bienvenue sur votre espace bancaire": "On nja\u0253\u0253ama e nokku banki moo\u0257on",
      "bienvenue sur votre espace client": "On nja\u0253\u0253ama e nokku ja\u0253\u0253orgo moo\u0257on",
      "bienvenue sur votre compte": "On nja\u0253\u0253ama e konta moo\u0257on",
      "espace bancaire": "Nokku banki",
      "espace client": "Nokku ja\u0253\u0253orgo",
      "effectuer un virement s\xE9curis\xE9": "Neldugol ceede e jam",
      "effectuer un virement": "Neldugol ceede",
      "virement s\xE9curis\xE9": "Neldugol ceede e jam",
      "solde de votre compte": "Ke\u0253al konta moo\u0257on",
      "solde de compte": "Ke\u0253al konta",
      "solde du compte": "Ke\u0253al konta",
      "en toute s\xE9curit\xE9": "e jam e kisal",
      "en s\xE9curit\xE9": "e jam",
      "de votre": "moo\u0257on",
      "de vos": "moo\u0257on",
      "de": "e",
      "du": "e",
      "des": "e",
      "sur votre": "dow moo\u0257on",
      "sur vos": "dow moo\u0257on",
      // Multi-word banking & financial terms
      "solde disponible (compte principal)": "Shede woodiide (asusu maw\u0257o)",
      "solde disponible": "Shede woodiide",
      "available balance": "Shede woodiide",
      "solde actuel": "Ceede jooni",
      "current balance": "Ceede jooni",
      "solde insuffisant": "Ceede \u0257on \u014Ba\u0253\u0253i",
      "insufficient balance": "Ceede \u0257on \u014Ba\u0253\u0253i",
      "votre solde est insuffisant": "Ke\u0253al moo\u0257on he\u0253aay",
      "solde est insuffisant": "Ke\u0253al he\u0253aay",
      "est insuffisant": "he\u0253aay",
      "insuffisant": "he\u0253aay",
      "pour couvrir": "ngam yo\u0253ugo",
      "couvrir": "yo\u0253ugo",
      "frais de timbre fiscal": "Ceede laminol laamu",
      "les frais de timbre fiscal": "Ceede laminol laamu",
      "frais de timbre": "Ceede laminol laamu",
      "timbre fiscal": "laminol laamu",
      "timbre": "laminol",
      "effectuer un transfert d'argent": "Neldugol ceede",
      "effectuer un transfert": "Neldugol ceede",
      "envoyer de l'argent": "Neldu ceede",
      "envoyer argent": "Neldu ceede",
      "frais de transfert": "Ceede neldugol",
      "transfer fees": "Ceede neldugol",
      "frais de retrait": "Ceede itto",
      "frais de transaction": "Ceede kuugal",
      "virement / transfert": "Neldugol ceede",
      "confirmer le transfert": "Tabbintingol neldugol",
      "historique des transactions": "Tariika golle ceede",
      "transaction history": "Tariika golle ceede",
      "num\xE9ro de compte": "Lamba konta",
      "account number": "Lamba konta",
      "num\xE9ro de t\xE9l\xE9phone": "Lamba telefo\u014B",
      "phone number": "Lamba telefo\u014B",
      "num\xE9ro du destinataire": "Lamba ke\u0253oowo",
      "carte bancaire": "Katti banki",
      "bank card": "Katti banki",
      "carte de cr\xE9dit": "Katti \xF1amaale",
      "credit card": "Katti \xF1amaale",
      "compte bancaire": "Konta banki",
      "bank account": "Konta banki",
      "mon compte": "Konta am",
      "my account": "Konta am",
      "cr\xE9er un compte": "Ma\u0253\u0253itugol konta",
      "create account": "Ma\u0253\u0253itugol konta",
      "se connecter": "Naatugol",
      "se d\xE9connecter": "Wurtaade",
      "mot de passe": "Kalima sirlu",
      "code secret": "Lamba sirlu",
      "code pin": "Lamba PIN",
      "pin code": "Lamba PIN",
      "en savoir plus": "\u0181eydu anndugo",
      "read more": "\u0181eydu anndugo",
      "voir plus": "\u01B3eewu \u0253eydaari",
      "contactez-nous": "Jokkondir e amen",
      "contact us": "Jokkondir e amen",
      "centre d'aide": "Nokku ballal",
      "help center": "Nokku ballal",
      "page d'accueil": "Ja\u0253\u0253orgo",
      "tableau de bord": "Alluwal golle",
      "veuillez patienter": "Tee\u014Bti he\u0257o see\u0257a",
      "please wait": "Tee\u014Bti he\u0257o see\u0257a",
      "op\xE9ration r\xE9ussie": "Kuugal he\u0253i e jam",
      "transfert r\xE9ussi": "Ceede neldaama e jam",
      "re\xE7u de paiement": "Kere\u0257i yo\u0253ol",
      "payment receipt": "Kere\u0257i yo\u0253ol",
      // Core nouns & vocabulary
      "accueil": "Ja\u0253\u0253orgo",
      "home": "Ja\u0253\u0253orgo",
      "menu": "Doggol",
      "services": "Kuu\u0257e",
      "service": "Kuugal",
      "banque": "Banki",
      "bank": "Banki",
      "compte": "Konta",
      "comptes": "Kontaaji",
      "account": "Konta",
      "accounts": "Kontaaji",
      "carte": "Katti",
      "card": "Katti",
      "solde": "Ke\u0253al",
      "balance": "Ke\u0253al",
      "virement": "Neldugol ceede",
      "transfert": "Neldugol ceede",
      "transfer": "Neldugol ceede",
      "retrait": "Ittugol ceede",
      "withdrawal": "Ittugol ceede",
      "withdraw": "Ittugo ceede",
      "retirer": "Ittugo",
      "d\xE9p\xF4t": "Wattingol ceede",
      "deposit": "Wattingol ceede",
      "d\xE9poser": "Wattingo",
      "paiement": "Yo\u0253ol",
      "payment": "Yo\u0253ol",
      "payer": "Yo\u0253ugo",
      "pay": "Yo\u0253ugo",
      "facture": "Kere\u0257i yo\u0253ol",
      "factures": "Kere\u0257iiji yo\u0253ol",
      "bill": "Kere\u0257i yo\u0253ol",
      "bills": "Kere\u0257iiji yo\u0253ol",
      "frais": "Ceede kuugal",
      "fees": "Ceede kuugal",
      "charges": "Ceede kuugal",
      "commission": "Hakke",
      "b\xE9n\xE9ficiaire": "Ke\u0253oowo",
      "destinataire": "Ke\u0253oowo",
      "beneficiary": "Ke\u0253oowo",
      "recipient": "Ke\u0253oowo",
      "montant": "Yawan ceede",
      "amount": "Yawan ceede",
      "total": "Kuu\u0253al",
      "argent": "Ceede",
      "money": "Ceede",
      "tontine": "Dente",
      "\xE9pargne": "Mopto",
      "savings": "Mopto",
      "cr\xE9dit": "\xD1amaale",
      "credit": "\xD1amaale",
      "pr\xEAt": "\xD1amaale",
      "loan": "\xD1amaale",
      "re\xE7u": "Kere\u0257i",
      "receipt": "Kere\u0257i",
      "historique": "Tariika",
      "history": "Tariika",
      "s\xE9curit\xE9": "Deenal",
      "security": "Deenal",
      "s\xE9curis\xE9": "Ko reenaa",
      "secure": "Ko reenaa",
      "profil": "Suura",
      "profile": "Suura",
      "param\xE8tres": "Ta\u01B4e",
      "settings": "Ta\u01B4e",
      "aide": "Ballal",
      "help": "Ballal",
      "contact": "Jokkondiral",
      "recherche": "Teftugol",
      "search": "Teftugol",
      "rechercher": "Teftugo",
      "connexion": "Naatugol",
      "login": "Naatugol",
      "d\xE9connexion": "Wurtaade",
      "logout": "Wurtaade",
      "inscription": "Winnditaade",
      "notifications": "Jeertinooji",
      "messages": "Bataakeeji",
      "message": "Bataake",
      "options": "Cu\u0253e",
      "option": "Su\u0253o",
      // Verbs & Actions
      "confirmer": "Tabintin",
      "confirm": "Tabintin",
      "valider": "Tabbintin",
      "submit": "Neldu",
      "annuler": "Haaytinu",
      "cancel": "Haaytinu",
      "envoyer": "Neldu",
      "send": "Neldu",
      "recevoir": "Ja\u0253\u0253o",
      "receive": "Ja\u0253\u0253o",
      "sauvegarder": "Danndu",
      "enregistrer": "Danndu",
      "save": "Danndu",
      "modifier": "Waylitugo",
      "edit": "Waylitugo",
      "supprimer": "Momtu",
      "delete": "Momtu",
      "fermer": "Ma\u0253\u0253u",
      "close": "Ma\u0253\u0253u",
      "continuer": "Jokku",
      "continue": "Jokku",
      "suivant": "Yeeso",
      "next": "Yeeso",
      "retour": "Caggal",
      "pr\xE9c\xE9dent": "Caggal",
      "back": "Caggal",
      "t\xE9l\xE9charger": "Jippin",
      "download": "Jippin",
      "imprimer": "Winnditugo",
      "print": "Winnditugo",
      "partager": "Sendindira",
      "share": "Sendindira",
      "ajouter": "\u0181eydu",
      "add": "\u0181eydu",
      "voir": "\u01B3eewu",
      "view": "\u01B3eewu",
      // Statuses & Courtesies
      "bienvenue": "On nja\u0253\u0253ama",
      "bonjour": "Jam waali",
      "bonsoir": "Jam nyalli",
      "salut": "No wa'i",
      "hello": "Jam waali",
      "merci": "A jaaraama",
      "thank you": "A jaaraama",
      "thanks": "Usoko",
      "oui": "Eey",
      "yes": "Eey",
      "non": "Aa'a",
      "no": "Aa'a",
      "succ\xE8s": "He\u0253i",
      "success": "He\u0253i",
      "r\xE9ussi": "He\u0253i jam",
      "erreur": "Aybe",
      "error": "Aybe",
      "\xE9chec": "Roondugol",
      "failed": "Roondugol",
      "en attente": "E he\u0257agol",
      "pending": "E he\u0257agol",
      "attention": "Reeno",
      "warning": "Reeno",
      "actif": "Gollay\u0257um",
      "inactif": "\u018Aon \u0257aani",
      "gratuit": "Meere",
      "free": "Meere",
      "nouveau": "Keso",
      "new": "Keso",
      "tous": "Fof",
      "all": "Fof",
      "date": "\xD1alaande",
      "heure": "Wakkati",
      "jour": "\xD1allande",
      "mois": "Lewru",
      "ann\xE9e": "Hitaande",
      "nom": "Innde",
      "d\xE9tails": "Ciftol",
      "details": "Ciftol",
      "avec": "e",
      "pour": "ngam",
      "dans": "nder",
      "sur": "dow",
      "votre": "moo\u0257on",
      "vos": "moo\u0257on",
      "notre": "amen",
      "nos": "amen",
      "mon": "am",
      "ma": "am",
      "mes": "am"
    },
    // ==========================================
    // 2. HAOUSSA (hau-CM / hau)
    // ==========================================
    hau: {
      "0": "sifili",
      "1": "daya",
      "2": "biyu",
      "3": "uku",
      "4": "hudu",
      "5": "biyar",
      "6": "shida",
      "7": "bakwai",
      "8": "takwas",
      "9": "tara",
      "10": "goma",
      "01": "daya",
      "02": "biyu",
      "03": "uku",
      "04": "hudu",
      "05": "biyar",
      "06": "shida",
      "07": "bakwai",
      "08": "takwas",
      "09": "tara",
      "un": "daya",
      "une": "daya",
      "deux": "biyu",
      "trois": "uku",
      "quatre": "hudu",
      "cinq": "biyar",
      "six": "shida",
      "sept": "bakwai",
      "huit": "takwas",
      "neuf": "tara",
      "dix": "goma",
      "one": "daya",
      "two": "biyu",
      "three": "uku",
      "four": "hudu",
      "five": "biyar",
      "seven": "bakwai",
      "eight": "takwas",
      "nine": "tara",
      "ten": "goma",
      "what we do": "Abin da muke yi",
      "venture capital": "Kudin kasuwanci",
      "impact": "Tasiri",
      "insights": "Fahimta da ilimi",
      "about": "Game da mu",
      "about us": "Game da mu",
      "and": "da",
      "et": "da",
      "that": "wannan",
      "helps": "yana taimakawa",
      "helping": "Taimaka",
      "people": "Mutane",
      "turn": "Mayar",
      "skills": "Dabaru",
      "skill": "Dabara",
      "into": "Zuwa",
      "jobs": "Ayyukan yi",
      "job": "Aiki",
      "businesses": "Kasuwanci",
      "business": "Kasuwanci",
      "in": "A",
      "cameroon": "Kamaru",
      "offers": "Na bayarwa",
      "hands-on": "A aikace",
      "training": "Horo",
      "develop": "Ha\u0253aka",
      "ideas": "Dabaru",
      "idea": "Dabara",
      "we": "Muna",
      "welcome": "Maraba",
      "universities": "Jami'o'i",
      "university": "Jami'a",
      "employers": "Masu \u0257aukar ma'aikata",
      "employer": "Mai \u0257aukar ma'aikaci",
      "investors": "Masu saka hannun jari",
      "investor": "Mai saka hannun jari",
      "who": "Wadanda",
      "want": "Suke son",
      "support": "Tallafa",
      "work": "Aiki",
      "find": "Nemi",
      "get": "Sami",
      "startup": "Fara kasuwanci",
      "funding": "Kudin tallafi",
      "lab": "Daki",
      "laboratory": "Dakin bincike",
      "computer": "Na'ura mai kwakwalwa",
      "platform": "dandamali",
      "center": "cibiyar",
      "growth": "ci gaba",
      "education": "ilimi",
      "community": "al'umma",
      "our": "namu",
      "yaound\xE9": "Yaound\xE9",
      "yaounde": "Yaound\xE9",
      "douala": "Douala",
      "say hello": "Gaishe mu",
      "enquiry": "Tambaya",
      "choose": "Zabi",
      "matches": "Dace",
      "bienvenue sur votre espace bancaire": "Barka da zuwa dakin bankin ku",
      "bienvenue sur votre espace client": "Barka da zuwa dakin abokin ciniki",
      "bienvenue sur votre compte": "Barka da zuwa asusun ku",
      "espace bancaire": "Dakin banki",
      "espace client": "Dakin abokin ciniki",
      "effectuer un virement s\xE9curis\xE9": "Tura ku\u0257i cikin tsaro",
      "effectuer un virement": "Tura ku\u0257i",
      "virement s\xE9curis\xE9": "Tura ku\u0257i cikin tsaro",
      "solde de votre compte": "Ragowar asusun ku",
      "solde de compte": "Ragowar asusu",
      "solde du compte": "Ragowar asusu",
      "en toute s\xE9curit\xE9": "cikin cikakken tsaro",
      "en s\xE9curit\xE9": "cikin tsaro",
      "de votre": "naku",
      "de vos": "naku",
      "de": "na",
      "du": "na",
      "des": "na",
      "sur votre": "akan naku",
      "sur vos": "akan naku",
      // Multi-word banking & financial terms
      "solde disponible (compte principal)": "Ragowar ku\u0257i (babban asusu)",
      "solde disponible": "Ragowar ku\u0257i",
      "available balance": "Ragowar ku\u0257i",
      "solde actuel": "Ku\u0257in da ke ciki yanzu",
      "current balance": "Ku\u0257in da ke ciki yanzu",
      "solde insuffisant": "Ku\u0257in asusu ba su isa ba",
      "insufficient balance": "Ku\u0257in asusu ba su isa ba",
      "votre solde est insuffisant": "Ragowar ku\u0257inku bai isa ba",
      "solde est insuffisant": "Ragowar ku\u0257i bai isa ba",
      "est insuffisant": "bai isa ba",
      "insuffisant": "bai isa ba",
      "pour couvrir": "don biyan",
      "couvrir": "biyan",
      "frais de timbre fiscal": "Ku\u0257in tambarin haraji",
      "les frais de timbre fiscal": "Ku\u0257in tambarin haraji",
      "frais de timbre": "Ku\u0257in tambari",
      "timbre fiscal": "tambarin haraji",
      "timbre": "tambari",
      "effectuer un transfert d'argent": "Tura ku\u0257i",
      "effectuer un transfert": "Tura ku\u0257i",
      "envoyer de l'argent": "Tura ku\u0257i",
      "envoyer argent": "Tura ku\u0257i",
      "frais de transfert": "Ku\u0257in sabis na turawa",
      "transfer fees": "Ku\u0257in sabis na turawa",
      "frais de retrait": "Ku\u0257in cirewa",
      "frais de transaction": "Ku\u0257in sabis",
      "virement / transfert": "Tura ku\u0257i",
      "confirmer le transfert": "Tabbatar da turawa",
      "historique des transactions": "Tarihin ma'amaloli",
      "transaction history": "Tarihin ma'amaloli",
      "num\xE9ro de compte": "Lambar asusu",
      "account number": "Lambar asusu",
      "num\xE9ro de t\xE9l\xE9phone": "Lambar waya",
      "phone number": "Lambar waya",
      "num\xE9ro du destinataire": "Lambar mai kar\u0253a",
      "carte bancaire": "Katin banki",
      "bank card": "Katin banki",
      "carte de cr\xE9dit": "Katin bashi",
      "credit card": "Katin bashi",
      "compte bancaire": "Asusun banki",
      "bank account": "Asusun banki",
      "mon compte": "Asusuna",
      "my account": "Asusuna",
      "cr\xE9er un compte": "Bude asusu",
      "create account": "Bude asusu",
      "se connecter": "Shiga ciki",
      "se d\xE9connecter": "Fita waje",
      "mot de passe": "Kalmar sirri",
      "code secret": "Lambar sirri",
      "code pin": "Lambar PIN",
      "pin code": "Lambar PIN",
      "en savoir plus": "Koyi \u0199ari",
      "read more": "Koyi \u0199ari",
      "voir plus": "Duba \u0199ari",
      "contactez-nous": "Tuntube mu",
      "contact us": "Tuntube mu",
      "centre d'aide": "Cibiyar taimako",
      "help center": "Cibiyar taimako",
      "page d'accueil": "Shafin gida",
      "tableau de bord": "Allon kula",
      "veuillez patienter": "Da fatan a jira",
      "please wait": "Da fatan a jira",
      "op\xE9ration r\xE9ussie": "Aiki ya yi nasara",
      "transfert r\xE9ussi": "An tura ku\u0257i cikin nasara",
      "re\xE7u de paiement": "Rasit na biya",
      "payment receipt": "Rasit na biya",
      // Core nouns & vocabulary
      "accueil": "Shafin gida",
      "home": "Shafin gida",
      "menu": "Menu",
      "services": "Ayyuka",
      "service": "Aiki",
      "banque": "Banki",
      "bank": "Banki",
      "compte": "Asusu",
      "comptes": "Asusuwa",
      "account": "Asusu",
      "accounts": "Asusuwa",
      "carte": "Kati",
      "card": "Kati",
      "solde": "Ragowar ku\u0257i",
      "balance": "Ragowar ku\u0257i",
      "virement": "Tura ku\u0257i",
      "transfert": "Tura ku\u0257i",
      "transfer": "Tura ku\u0257i",
      "retrait": "Cire ku\u0257i",
      "withdrawal": "Cire ku\u0257i",
      "withdraw": "Cire ku\u0257i",
      "retirer": "Cire",
      "d\xE9p\xF4t": "Sanya ku\u0257i",
      "deposit": "Sanya ku\u0257i",
      "d\xE9poser": "Sanya",
      "paiement": "Biya",
      "payment": "Biya",
      "payer": "Biya",
      "pay": "Biya",
      "facture": "Lissafin ku\u0257i",
      "factures": "Lissafin ku\u0257i",
      "bill": "Lissafin ku\u0257i",
      "bills": "Lissafin ku\u0257i",
      "frais": "Ku\u0257in sabis",
      "fees": "Ku\u0257in sabis",
      "charges": "Ku\u0257in sabis",
      "commission": "Hakki",
      "b\xE9n\xE9ficiaire": "Mai kar\u0253a",
      "destinataire": "Mai kar\u0253a",
      "beneficiary": "Mai kar\u0253a",
      "recipient": "Mai kar\u0253a",
      "montant": "Adadin ku\u0257i",
      "amount": "Adadin ku\u0257i",
      "total": "Jimilla",
      "argent": "Ku\u0257i",
      "money": "Ku\u0257i",
      "tontine": "Adashe",
      "\xE9pargne": "Asusun ajiya",
      "savings": "Asusun ajiya",
      "cr\xE9dit": "Bashi",
      "credit": "Bashi",
      "pr\xEAt": "Rance",
      "loan": "Rance",
      "re\xE7u": "Rasit",
      "receipt": "Rasit",
      "historique": "Tarihi",
      "history": "Tarihi",
      "s\xE9curit\xE9": "Tsaro",
      "security": "Tsaro",
      "s\xE9curis\xE9": "Mai tsaro",
      "secure": "Mai tsaro",
      "profil": "Bayanin mai amfani",
      "profile": "Bayanin mai amfani",
      "param\xE8tres": "Saituna",
      "settings": "Saituna",
      "aide": "Taimako",
      "help": "Taimako",
      "contact": "Tuntuba",
      "recherche": "Bincika",
      "search": "Bincika",
      "rechercher": "Bincika",
      "connexion": "Shiga ciki",
      "login": "Shiga ciki",
      "d\xE9connexion": "Fita",
      "logout": "Fita",
      "inscription": "Rijista",
      "notifications": "Sanarwa",
      "messages": "Sa\u0199onni",
      "message": "Sa\u0199o",
      "options": "Za\u0253u\u0253\u0253uka",
      "option": "Za\u0253i",
      // Verbs & Actions
      "confirmer": "Tabbatar",
      "confirm": "Tabbatar",
      "valider": "Tabbatar",
      "submit": "Aika",
      "annuler": "Soke",
      "cancel": "Soke",
      "envoyer": "Tura",
      "send": "Tura",
      "recevoir": "Kar\u0253a",
      "receive": "Kar\u0253a",
      "sauvegarder": "Ajiye",
      "enregistrer": "Ajiye",
      "save": "Ajiye",
      "modifier": "Gyara",
      "edit": "Gyara",
      "supprimer": "Goge",
      "delete": "Goge",
      "fermer": "Rufe",
      "close": "Rufe",
      "continuer": "Ci gaba",
      "continue": "Ci gaba",
      "suivant": "Na gaba",
      "next": "Na gaba",
      "retour": "Koma baya",
      "pr\xE9c\xE9dent": "Na baya",
      "back": "Koma baya",
      "t\xE9l\xE9charger": "Sauke",
      "download": "Sauke",
      "imprimer": "Buga",
      "print": "Buga",
      "partager": "Raba",
      "share": "Raba",
      "ajouter": "\u0198ara",
      "add": "\u0198ara",
      "voir": "Duba",
      "view": "Duba",
      // Statuses & Courtesies
      "bienvenue": "Barka da zuwa",
      "bonjour": "Barka da safe",
      "bonsoir": "Barka da yamma",
      "salut": "Sannu",
      "hello": "Sannu",
      "merci": "Na gode",
      "thank you": "Na gode",
      "thanks": "Na gode",
      "oui": "Eh",
      "yes": "Eh",
      "non": "A'a",
      "no": "A'a",
      "succ\xE8s": "Nasara",
      "success": "Nasara",
      "r\xE9ussi": "An yi nasara",
      "erreur": "Kuskure",
      "error": "Kuskure",
      "\xE9chec": "Kasa aiki",
      "failed": "Kasa aiki",
      "en attente": "Ana jira",
      "pending": "Ana jira",
      "attention": "Hattara",
      "warning": "Garga\u0257i",
      "actif": "Yana aiki",
      "inactif": "Ba ya aiki",
      "gratuit": "Kyauta",
      "free": "Kyauta",
      "nouveau": "Sabo",
      "new": "Sabo",
      "tous": "Duka",
      "all": "Duka",
      "date": "Kwanan wata",
      "heure": "Lokaci",
      "jour": "Rana",
      "mois": "Wata",
      "ann\xE9e": "Shekara",
      "nom": "Suna",
      "d\xE9tails": "Cikakken bayani",
      "details": "Cikakken bayani",
      "avec": "tare da",
      "pour": "don",
      "dans": "a cikin",
      "sur": "akan",
      "votre": "naku",
      "vos": "naku",
      "notre": "namu",
      "nos": "namu",
      "mon": "nawa",
      "ma": "nawa",
      "mes": "nawa"
    },
    // ==========================================
    // 3. KANURI (knc-CM / knc)
    // ==========================================
    knc: {
      "0": "sifili",
      "1": "t\xEDl\u014D",
      "2": "nd\xED",
      "3": "yakk\u0259\u0301",
      "4": "d\xE9y\xE9",
      "5": "\xFAw\xF9",
      "6": "arask\u0259\u0301",
      "7": "tulur",
      "8": "wusku",
      "9": "l\u0259gar",
      "10": "mewu",
      "01": "t\xEDl\u014D",
      "02": "nd\xED",
      "03": "yakk\u0259\u0301",
      "04": "d\xE9y\xE9",
      "05": "\xFAw\xF9",
      "06": "arask\u0259\u0301",
      "07": "tulur",
      "08": "wusku",
      "09": "l\u0259gar",
      "un": "t\xEDl\u014D",
      "une": "t\xEDl\u014D",
      "deux": "nd\xED",
      "trois": "yakk\u0259\u0301",
      "quatre": "d\xE9y\xE9",
      "cinq": "\xFAw\xF9",
      "six": "arask\u0259\u0301",
      "sept": "tulur",
      "huit": "wusku",
      "neuf": "l\u0259gar",
      "dix": "mewu",
      "one": "t\xEDl\u014D",
      "two": "nd\xED",
      "three": "yakk\u0259\u0301",
      "four": "d\xE9y\xE9",
      "five": "\xFAw\xF9",
      "seven": "tulur",
      "eight": "wusku",
      "nine": "l\u0259gar",
      "ten": "mewu",
      "what we do": "Cida b\u0259la",
      "venture capital": "Kudi cidaram",
      "impact": "Gadu",
      "insights": "Fahamuro",
      "about": "K\u0259la b\u0259la",
      "about us": "K\u0259la andibe",
      "helping": "Banat\u0259",
      "people": "Am",
      "turn": "Kalangt\u0259",
      "skills": "N\u0259mng\u0259la",
      "skill": "N\u0259mng\u0259la",
      "into": "Ro",
      "jobs": "Cida",
      "job": "Cida",
      "businesses": "Cidaram",
      "business": "Cidaram",
      "in": "Lan",
      "cameroon": "Cameroun",
      "offers": "Cin",
      "hands-on": "K\u0259skaye",
      "training": "K\u0259ra",
      "develop": "Sawuro",
      "ideas": "Faham",
      "idea": "Faham",
      "we": "Andi",
      "welcome": "Kalluro",
      "universities": "Jamiya so",
      "university": "Jamiya",
      "employers": "Kwaye cidabe",
      "employer": "Kwaye cida",
      "investors": "Am kudi cidarambe",
      "investor": "Kudi cidaramma",
      "who": "Ndu",
      "want": "Ragana",
      "support": "Banat\u0259",
      "work": "Cida",
      "find": "Mat\u0259",
      "get": "Sat\u0259",
      "startup": "Cidaram k\u0259labe",
      "funding": "Kudi cidaram",
      "lab": "Fato",
      "laboratory": "Fato",
      "computer": "Kompita",
      "and": "kuru",
      "platform": "dallol",
      "center": "fato",
      "growth": "n\u0259mng\u0259la",
      "education": "k\u0259ra",
      "community": "am so",
      "our": "andibe",
      "yaound\xE9": "Yaound\xE9",
      "yaounde": "Yaound\xE9",
      "douala": "Douala",
      "say hello": "Kalluro mana",
      "enquiry": "K\u0259ra manat\u0259",
      "choose": "Kalt\u0259",
      "matches": "Kalangt\u0259",
      "bienvenue sur votre espace bancaire": "Kallu fato banki n\u0259mbe ro",
      "bienvenue sur votre espace client": "Kallu fato k\u0259ji n\u0259mbe ro",
      "bienvenue sur votre compte": "Kallu asusu n\u0259mbe ro",
      "espace bancaire": "Fato banki",
      "espace client": "Fato k\u0259ji",
      "effectuer un virement s\xE9curis\xE9": "Kudi tewuro tsarobe",
      "effectuer un virement": "Kudi tewuro",
      "virement s\xE9curis\xE9": "Kudi tewuro tsarobe",
      "solde de votre compte": "Liman kali asusu n\u0259mbe",
      "solde de compte": "Liman kali asusu",
      "solde du compte": "Liman kali asusu",
      "en toute s\xE9curit\xE9": "tsaro k\u0259ji ro",
      "en s\xE9curit\xE9": "tsaro ro",
      "de votre": "n\u0259mbe",
      "de vos": "n\u0259mbe",
      "de": "be",
      "du": "be",
      "des": "be",
      "sur votre": "n\u0259mbe lan",
      "sur vos": "n\u0259mbe lan",
      // Multi-word banking & financial terms
      "solde disponible (compte principal)": "K\u0259la k\u0259labe mbeji (asusu kura)",
      "solde disponible": "K\u0259la k\u0259labe mbeji",
      "available balance": "K\u0259la k\u0259labe mbeji",
      "solde actuel": "Liman ngowo",
      "current balance": "Liman ngowo",
      "solde insuffisant": "Liman gana",
      "insufficient balance": "Liman gana",
      "votre solde est insuffisant": "Liman kalinz\u0259 yeya ba",
      "solde est insuffisant": "Liman kali yeya ba",
      "est insuffisant": "yeya ba",
      "insuffisant": "yeya ba",
      "pour couvrir": "ro biya ro",
      "couvrir": "biya",
      "frais de timbre fiscal": "Hakki lamin jomiyabe",
      "les frais de timbre fiscal": "Hakki lamin jomiyabe",
      "frais de timbre": "Hakki laminbe",
      "timbre fiscal": "lamin jomiyabe",
      "timbre": "lamin",
      "effectuer un transfert d'argent": "Kudi tewuro diyiram",
      "effectuer un transfert": "Kudi tewuro diyiram",
      "envoyer de l'argent": "Kudi tewuro",
      "envoyer argent": "Kudi tewuro",
      "frais de transfert": "Kudi tewuro ladan",
      "transfer fees": "Kudi tewuro ladan",
      "frais de retrait": "Kusu ladan",
      "frais de transaction": "Liman ladan",
      "virement / transfert": "Kudi tewuro",
      "confirmer le transfert": "Tewuro gade taro",
      "historique des transactions": "Kudi cidaram gargam",
      "transaction history": "Kudi cidaram gargam",
      "num\xE9ro de compte": "Namba asusu",
      "account number": "Namba asusu",
      "num\xE9ro de t\xE9l\xE9phone": "Namba talaho",
      "phone number": "Namba talaho",
      "num\xE9ro du destinataire": "Namba ngowoma",
      "carte bancaire": "Kati banki",
      "bank card": "Kati banki",
      "carte de cr\xE9dit": "Kati bashi",
      "credit card": "Kati bashi",
      "compte bancaire": "Asusu banki",
      "bank account": "Asusu banki",
      "mon compte": "Asusunyi",
      "my account": "Asusunyi",
      "cr\xE9er un compte": "Asusu kure",
      "create account": "Asusu kure",
      "se connecter": "G\u0259re",
      "se d\xE9connecter": "Kolji",
      "mot de passe": "Kalima asiri",
      "code secret": "Namba asiri",
      "code pin": "Namba PIN",
      "pin code": "Namba PIN",
      "en savoir plus": "Ngaso not\u0259",
      "read more": "Ngaso not\u0259",
      "voir plus": "Gade kurugo",
      "contactez-nous": "Mana ro bultiro",
      "contact us": "Mana ro bultiro",
      "centre d'aide": "Banat\u0259 cidaram",
      "help center": "Banat\u0259 cidaram",
      "page d'accueil": "Fato kuraram",
      "tableau de bord": "Alluwal cidaram",
      "veuillez patienter": "Ng\u0259la daji",
      "please wait": "Ng\u0259la daji",
      "op\xE9ration r\xE9ussie": "Cida ngelawa lan cidono",
      "transfert r\xE9ussi": "Kudi tewuro ngelawa lan cidono",
      "re\xE7u de paiement": "Risit biya",
      "payment receipt": "Risit biya",
      // Core nouns & vocabulary
      "accueil": "Fato kuraram",
      "home": "Fato kuraram",
      "menu": "Menu",
      "services": "Cidawa",
      "service": "Cida",
      "banque": "Banki",
      "bank": "Banki",
      "compte": "Asusu",
      "comptes": "Asusuwa",
      "account": "Asusu",
      "accounts": "Asusuwa",
      "carte": "Kati",
      "card": "Kati",
      "solde": "Liman kali",
      "balance": "Liman kali",
      "virement": "Kudi tewuro",
      "transfert": "Kudi tewuro",
      "transfer": "Kudi tewuro",
      "retrait": "Kusu",
      "withdrawal": "Kusu",
      "withdraw": "Kusu",
      "retirer": "Kusu roptiro",
      "d\xE9p\xF4t": "Fatt\u0259",
      "deposit": "Fatt\u0259",
      "d\xE9poser": "Kudi ciro",
      "paiement": "Biya",
      "payment": "Biya",
      "payer": "Biya",
      "pay": "Biya",
      "facture": "Kere\u0257i biya",
      "factures": "Kere\u0257i biya",
      "bill": "Kere\u0257i biya",
      "bills": "Kere\u0257i biya",
      "frais": "Hakki",
      "fees": "Hakki",
      "charges": "Hakki",
      "commission": "Ladan",
      "b\xE9n\xE9ficiaire": "Kudi ngowoma",
      "destinataire": "Kudi ngowoma",
      "beneficiary": "Kudi ngowoma",
      "recipient": "Kudi ngowoma",
      "montant": "Kudi yanyi",
      "amount": "Kudi yanyi",
      "total": "Samma",
      "argent": "Kudi",
      "money": "Kudi",
      "tontine": "Kenta cida",
      "\xE9pargne": "Kudi g\u0259nat\u0259",
      "savings": "Kudi g\u0259nat\u0259",
      "cr\xE9dit": "Bashi",
      "credit": "Bashi",
      "pr\xEAt": "Njiwo",
      "loan": "Njiwo",
      "re\xE7u": "Risit",
      "receipt": "Risit",
      "historique": "Gargam",
      "history": "Gargam",
      "s\xE9curit\xE9": "Riba",
      "security": "Riba",
      "s\xE9curis\xE9": "Tsarobe",
      "secure": "Tsarobe",
      "profil": "Su kuraram",
      "profile": "Su kuraram",
      "param\xE8tres": "Saita",
      "settings": "Saita",
      "aide": "Banat\u0259",
      "help": "Banat\u0259",
      "contact": "Manat\u0259",
      "recherche": "Mat\u0259",
      "search": "Mat\u0259",
      "rechercher": "Mat\u0259",
      "connexion": "G\u0259re",
      "login": "G\u0259re",
      "d\xE9connexion": "Kolji",
      "logout": "Kolji",
      "inscription": "Rajista",
      "notifications": "Not\u0259wa",
      "messages": "Batawawa",
      "message": "Batawa",
      "options": "Zawozawo",
      "option": "Zawo",
      // Verbs & Actions
      "confirmer": "Gade taro",
      "confirm": "Gade taro",
      "valider": "Gade taro",
      "submit": "Tewuro",
      "annuler": "Kola",
      "cancel": "Kola",
      "envoyer": "Tewuro",
      "send": "Tewuro",
      "recevoir": "Ngowo",
      "receive": "Ngowo",
      "sauvegarder": "G\u0259nat\u0259",
      "enregistrer": "G\u0259nat\u0259",
      "save": "G\u0259nat\u0259",
      "modifier": "Bultiro",
      "edit": "Bultiro",
      "supprimer": "Baza",
      "delete": "Baza",
      "fermer": "Kamburo",
      "close": "Kamburo",
      "continuer": "Fuwuro",
      "continue": "Fuwuro",
      "suivant": "Gade",
      "next": "Gade",
      "retour": "Ngawo",
      "pr\xE9c\xE9dent": "Ngawo",
      "back": "Ngawo",
      "t\xE9l\xE9charger": "Jippo",
      "download": "Jippo",
      "imprimer": "Ruwo",
      "print": "Ruwo",
      "partager": "Cidando",
      "share": "Cidando",
      "ajouter": "Gade ciro",
      "add": "Gade ciro",
      "voir": "Kurugo",
      "view": "Kurugo",
      // Statuses & Courtesies
      "bienvenue": "Wushe wushe",
      "bonjour": "Ndawuso",
      "bonsoir": "Wushe balan",
      "salut": "Wushe",
      "hello": "Wushe",
      "merci": "Wuaza",
      "thank you": "Wuaza",
      "thanks": "Wuaza",
      "oui": "Awo",
      "yes": "Awo",
      "non": "A'a",
      "no": "A'a",
      "succ\xE8s": "K\u0259lawa",
      "success": "K\u0259lawa",
      "r\xE9ussi": "Ngelawa",
      "erreur": "Aibi",
      "error": "Aibi",
      "\xE9chec": "Rowa",
      "failed": "Rowa",
      "en attente": "He\u0257aram",
      "pending": "He\u0257aram",
      "attention": "Hangal",
      "warning": "Hangal",
      "actif": "Cidaram",
      "inactif": "Kolzana",
      "gratuit": "Mba",
      "free": "Mba",
      "nouveau": "B\u0259lin",
      "new": "B\u0259lin",
      "tous": "Samma",
      "all": "Samma",
      "date": "K\u0259ntago",
      "heure": "Sa'a",
      "jour": "Kawa",
      "mois": "K\u0259ntago",
      "ann\xE9e": "Sawa",
      "nom": "Su",
      "d\xE9tails": "Bayan",
      "details": "Bayan",
      "avec": "lan",
      "pour": "ro",
      "dans": "lan",
      "sur": "k\u0259la",
      "votre": "n\u0259mbe",
      "vos": "n\u0259mbe",
      "notre": "ndaye",
      "nos": "ndaye",
      "mon": "nyi",
      "ma": "nyi",
      "mes": "nyi"
    },
    // ==========================================
    // 4. CAMEROON PIDGIN ENGLISH (pcm-CM / pcm)
    // ==========================================
    pcm: {
      "0": "zero",
      "1": "wan",
      "2": "tu",
      "3": "tri",
      "4": "fo",
      "5": "faiv",
      "6": "siks",
      "7": "s\u025Bvin",
      "8": "et",
      "9": "nain",
      "10": "t\u025Bn",
      "01": "wan",
      "02": "tu",
      "03": "tri",
      "04": "fo",
      "05": "faiv",
      "06": "siks",
      "07": "s\u025Bvin",
      "08": "et",
      "09": "nain",
      "un": "wan",
      "une": "wan",
      "deux": "tu",
      "trois": "tri",
      "quatre": "fo",
      "cinq": "faiv",
      "six": "siks",
      "sept": "s\u025Bvin",
      "huit": "et",
      "neuf": "nain",
      "dix": "t\u025Bn",
      "one": "wan",
      "two": "tu",
      "three": "tri",
      "four": "fo",
      "five": "faiv",
      "seven": "s\u025Bvin",
      "eight": "et",
      "nine": "nain",
      "ten": "t\u025Bn",
      "what we do": "Wetin we dey do",
      "venture capital": "Startup money",
      "impact": "Better change",
      "insights": "News and info",
      "about": "About us",
      "about us": "About us",
      "helping": "Dey help",
      "people": "Pipo",
      "turn": "Change",
      "skills": "Sabi work",
      "skill": "Sabi work",
      "into": "Into",
      "jobs": "Work",
      "job": "Work",
      "businesses": "Business",
      "business": "Business",
      "in": "For",
      "cameroon": "Cameroon",
      "offers": "Dey give",
      "hands-on": "Practical",
      "training": "Training",
      "develop": "Bring up",
      "ideas": "Ideas",
      "idea": "Idea",
      "we": "We",
      "welcome": "Welkom",
      "universities": "Universities",
      "university": "University",
      "employers": "Boss dem",
      "employer": "Boss",
      "investors": "Investors dem",
      "investor": "Investor",
      "who": "Wey",
      "want": "Want",
      "support": "Support",
      "work": "Work",
      "find": "Find",
      "get": "Get",
      "startup": "New business",
      "funding": "Money support",
      "lab": "Room",
      "laboratory": "Room",
      "computer": "Computer",
      "and": "and",
      "platform": "platform",
      "center": "corner",
      "growth": "progress",
      "education": "sabi book",
      "community": "pipo dem",
      "our": "our",
      "yaound\xE9": "Yaound\xE9",
      "yaounde": "Yaound\xE9",
      "douala": "Douala",
      "say hello": "Greet us",
      "enquiry": "Question",
      "choose": "Pick",
      "matches": "Fit",
      "bienvenue sur votre espace bancaire": "Welcome for ya bank corner",
      "bienvenue sur votre espace client": "Welcome for ya client corner",
      "bienvenue sur votre compte": "Welcome for ya account",
      "espace bancaire": "Bank corner",
      "espace client": "Client corner",
      "effectuer un virement s\xE9curis\xE9": "Send money tight security",
      "effectuer un virement": "Send money",
      "virement s\xE9curis\xE9": "Send money tight security",
      "solde de votre compte": "Ya account balance",
      "solde de compte": "Account balance",
      "solde du compte": "Account balance",
      "en toute s\xE9curit\xE9": "wit tight security",
      "en s\xE9curit\xE9": "wit security",
      "de votre": "for ya",
      "de vos": "for ya",
      "de": "for",
      "du": "for",
      "des": "for",
      "sur votre": "for ya",
      "sur vos": "for ya",
      // Multi-word banking & financial terms
      "solde disponible (compte principal)": "Money wey dey available (main account)",
      "solde disponible": "Money wey dey available",
      "available balance": "Money wey dey available",
      "solde actuel": "Money for account now",
      "current balance": "Money for account now",
      "solde insuffisant": "Money no reach",
      "insufficient balance": "Money no reach",
      "votre solde est insuffisant": "Ya balance no reach",
      "solde est insuffisant": "Balance no reach",
      "est insuffisant": "no reach",
      "insuffisant": "no reach",
      "pour couvrir": "for cover",
      "couvrir": "cover",
      "frais de timbre fiscal": "Tax stamp charges",
      "les frais de timbre fiscal": "Tax stamp charges",
      "frais de timbre": "Stamp charges",
      "timbre fiscal": "tax stamp",
      "timbre": "stamp",
      "effectuer un transfert d'argent": "Send money shap shap",
      "effectuer un transfert": "Send money nau",
      "envoyer de l'argent": "Send money",
      "envoyer argent": "Send money",
      "frais de transfert": "Transfer charges",
      "transfer fees": "Transfer charges",
      "frais de retrait": "Cash out charges",
      "frais de transaction": "Service charges",
      "virement / transfert": "Send money",
      "confirmer le transfert": "Confirm transfer",
      "historique des transactions": "Old transactions history",
      "transaction history": "Old transactions history",
      "num\xE9ro de compte": "Account number",
      "account number": "Account number",
      "num\xE9ro de t\xE9l\xE9phone": "Phone number",
      "phone number": "Phone number",
      "num\xE9ro du destinataire": "Person phone number",
      "carte bancaire": "Bank card",
      "bank card": "Bank card",
      "carte de cr\xE9dit": "Credit card",
      "credit card": "Credit card",
      "compte bancaire": "Bank account",
      "bank account": "Bank account",
      "mon compte": "My account",
      "my account": "My account",
      "cr\xE9er un compte": "Open new account",
      "create account": "Open new account",
      "se connecter": "Login",
      "se d\xE9connecter": "Log out",
      "mot de passe": "Password",
      "code secret": "Secret code",
      "code pin": "Secret PIN",
      "pin code": "Secret PIN",
      "en savoir plus": "Read more info",
      "read more": "Read more info",
      "voir plus": "See more",
      "contactez-nous": "Tok wit us",
      "contact us": "Tok wit us",
      "centre d'aide": "Help center",
      "help center": "Help center",
      "page d'accueil": "Home page",
      "tableau de bord": "Dashboard",
      "veuillez patienter": "Abeg wait small",
      "please wait": "Abeg wait small",
      "op\xE9ration r\xE9ussie": "Action don complete fine fine",
      "transfert r\xE9ussi": "Money don go fine fine",
      "re\xE7u de paiement": "Payment receipt",
      "payment receipt": "Payment receipt",
      // Core nouns & vocabulary
      "accueil": "Home",
      "home": "Home",
      "menu": "Menu",
      "services": "Services dem",
      "service": "Service",
      "banque": "Bank",
      "bank": "Bank",
      "compte": "Account",
      "comptes": "Accounts",
      "account": "Account",
      "accounts": "Accounts",
      "carte": "Card",
      "card": "Card",
      "solde": "Balance",
      "balance": "Balance",
      "virement": "Send money",
      "transfert": "Send money",
      "transfer": "Send money",
      "retrait": "Withdraw",
      "withdrawal": "Withdraw",
      "withdraw": "Withdraw",
      "retirer": "Komot money",
      "d\xE9p\xF4t": "Deposit",
      "deposit": "Deposit",
      "d\xE9poser": "Put money",
      "paiement": "Payment",
      "payment": "Payment",
      "payer": "Pay money",
      "pay": "Pay money",
      "facture": "Bill",
      "factures": "Bills",
      "bill": "Bill",
      "bills": "Bills",
      "frais": "Charges",
      "fees": "Charges",
      "charges": "Charges",
      "commission": "Small charge",
      "b\xE9n\xE9ficiaire": "Person wey dey receive",
      "destinataire": "Person wey dey receive",
      "beneficiary": "Person wey dey receive",
      "recipient": "Person wey dey receive",
      "montant": "Total money",
      "amount": "Total money",
      "total": "All money",
      "argent": "Money",
      "money": "Money",
      "tontine": "Njangi",
      "\xE9pargne": "Savings",
      "savings": "Savings",
      "cr\xE9dit": "Credit",
      "credit": "Credit",
      "pr\xEAt": "Loan",
      "loan": "Loan",
      "re\xE7u": "Receipt",
      "receipt": "Receipt",
      "historique": "History",
      "history": "History",
      "s\xE9curit\xE9": "Security",
      "security": "Security",
      "s\xE9curis\xE9": "Tight security",
      "secure": "Tight security",
      "profil": "Profile",
      "profile": "Profile",
      "param\xE8tres": "Settings",
      "settings": "Settings",
      "aide": "Help",
      "help": "Help",
      "contact": "Contact",
      "recherche": "Find",
      "search": "Find",
      "rechercher": "Find",
      "connexion": "Login",
      "login": "Login",
      "d\xE9connexion": "Log out",
      "logout": "Log out",
      "inscription": "Sign up",
      "notifications": "Alert dem",
      "messages": "Messages",
      "message": "Message",
      "options": "Options",
      "option": "Option",
      // Verbs & Actions
      "confirmer": "Confirm",
      "confirm": "Confirm",
      "valider": "Confirm",
      "submit": "Send am",
      "annuler": "Cancel",
      "cancel": "Cancel",
      "envoyer": "Send",
      "send": "Send",
      "recevoir": "Receive",
      "receive": "Receive",
      "sauvegarder": "Save am",
      "enregistrer": "Save am",
      "save": "Save am",
      "modifier": "Change am",
      "edit": "Change am",
      "supprimer": "Delete am",
      "delete": "Delete am",
      "fermer": "Close",
      "close": "Close",
      "continuer": "Continue",
      "continue": "Continue",
      "suivant": "Next",
      "next": "Next",
      "retour": "Go back",
      "pr\xE9c\xE9dent": "Back",
      "back": "Go back",
      "t\xE9l\xE9charger": "Download",
      "download": "Download",
      "imprimer": "Print am",
      "print": "Print am",
      "partager": "Share am",
      "share": "Share am",
      "ajouter": "Add am",
      "add": "Add am",
      "voir": "Check am",
      "view": "Check am",
      // Statuses & Courtesies
      "bienvenue": "Welkam",
      "bonjour": "Gud morning",
      "bonsoir": "Gud evening",
      "salut": "Salot",
      "hello": "Halo",
      "merci": "Tank yu",
      "thank you": "Tank yu",
      "thanks": "Tank yu",
      "oui": "Yes",
      "yes": "Yes",
      "non": "No",
      "no": "No",
      "succ\xE8s": "Success",
      "success": "Success",
      "r\xE9ussi": "Don work fine",
      "erreur": "Mistake",
      "error": "Mistake",
      "\xE9chec": "Fail",
      "failed": "Don fail",
      "en attente": "Dey wait",
      "pending": "Dey wait",
      "attention": "Look out",
      "warning": "Look out",
      "actif": "Active",
      "inactif": "Off",
      "gratuit": "Free",
      "free": "Free",
      "nouveau": "New",
      "new": "New",
      "tous": "All",
      "all": "All",
      "date": "Date",
      "heure": "Time",
      "jour": "Day",
      "mois": "Month",
      "ann\xE9e": "Year",
      "nom": "Name",
      "d\xE9tails": "Details",
      "details": "Details",
      "avec": "wit",
      "pour": "for",
      "dans": "inside",
      "sur": "on top",
      "votre": "ya",
      "vos": "ya",
      "notre": "auwa",
      "nos": "auwa",
      "mon": "ma",
      "ma": "ma",
      "mes": "ma"
    }
  };
  function normalizeLangCode(lang) {
    const norm = lang.trim().toLowerCase().replace(/_/, "-");
    if (norm.startsWith("ewo")) return "ewo";
    if (norm.startsWith("fuv") || norm.startsWith("fub")) return "fuv";
    if (norm.startsWith("hau")) return "hau";
    if (norm.startsWith("knc")) return "knc";
    if (norm.startsWith("pcm")) return "pcm";
    if (norm.startsWith("dua")) return "dua";
    return norm;
  }
  function translateSentenceToSovereign(text, targetLang) {
    const normLang = normalizeLangCode(targetLang);
    if (normLang === "ewo") {
      const translatedText = translateSentenceToEwondo(text);
      return {
        translatedText,
        status: translatedText === text ? "unverified" : "success",
        warnings: translatedText === text ? ["EWONDO_NO_MATCH"] : []
      };
    }
    if (normLang === "dua") {
      return {
        translatedText: text,
        status: "unverified",
        warnings: ["DUALA_QUARANTINED_UNVERIFIED", "DUALA_NO_VERIFIED_TRANSLATION"]
      };
    }
    const dict = SOVEREIGN_DICTIONARIES[normLang];
    if (!dict) {
      return {
        translatedText: text,
        status: "unverified",
        warnings: [`UNSUPPORTED_LANGUAGE_${targetLang}`]
      };
    }
    const trimmed = text.trim();
    if (!trimmed) {
      return { translatedText: text, status: "unverified", warnings: [] };
    }
    const { guardedText, entities } = extractAndGuardEntities2(trimmed);
    let workingText = guardedText;
    const multiWordKeys = Object.keys(dict).filter((k) => k.includes(" ") || k.includes("'")).sort((a, b) => b.length - a.length);
    let matched = false;
    for (const phrase of multiWordKeys) {
      const targetTerm = dict[phrase];
      const escaped = escapeRegExp2(phrase);
      const regex = new RegExp(`(^|[^\\p{L}\\p{N}])(${escaped})([^\\p{L}\\p{N}]|$)`, "giu");
      if (regex.test(workingText)) {
        matched = true;
        workingText = workingText.replace(regex, (match, prefix, captured, suffix) => {
          let replacement = targetTerm;
          if (captured === captured.toUpperCase() && captured.length > 1) {
            replacement = targetTerm.toUpperCase();
          } else if (captured[0] === captured[0].toUpperCase()) {
            replacement = targetTerm.charAt(0).toUpperCase() + targetTerm.slice(1);
          }
          return `${prefix}${replacement}${suffix}`;
        });
      }
    }
    const tokens = workingText.split(/(\s+|[,;:.!?()\/\\'\-–—«»""→←↑↓·•|]|<\/?t\d+>|⟦T\d+:|⟧)/u);
    const translatedTokens = [];
    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i];
      if (!token) continue;
      const wordKey = token.toLowerCase();
      const wordMatch = dict[wordKey];
      if (wordMatch) {
        matched = true;
        let repl = wordMatch;
        if (token === token.toUpperCase() && token.length > 1) {
          repl = wordMatch.toUpperCase();
        } else if (token[0] === token[0].toUpperCase()) {
          repl = wordMatch.charAt(0).toUpperCase() + wordMatch.slice(1);
        }
        translatedTokens.push(repl);
        continue;
      }
      if (/^(\s+|[,;:.!?()\/\\'\-–—«»""])$/.test(token) || /^___FIN_GUARD_\d+___$/.test(token) || /^<\/?t\d+>$/.test(token) || /^⟦T\d+:$/.test(token) || token === "\u27E7" || /^[\d\s.,\u00a0]+$/.test(token) || /^(FCFA|XAF|CFA|EUR|USD|XOF)$/i.test(token)) {
        translatedTokens.push(token);
        continue;
      }
      if (/^[ldcsqnjm]['’]$/i.test(token) && i + 1 < tokens.length) {
        let nextIdx = i + 1;
        while (nextIdx < tokens.length && !tokens[nextIdx].trim()) nextIdx++;
        if (nextIdx < tokens.length) {
          const nextWord = tokens[nextIdx];
          const nextLookup = dict[nextWord.toLowerCase()];
          if (nextLookup) {
            matched = true;
            let repl = nextLookup;
            if (nextWord === nextWord.toUpperCase() && nextWord.length > 1) {
              repl = nextLookup.toUpperCase();
            } else if (token[0] === token[0].toUpperCase()) {
              repl = nextLookup.charAt(0).toUpperCase() + nextLookup.slice(1);
            }
            translatedTokens.push(repl);
            i = nextIdx;
            continue;
          }
        }
      }
      translatedTokens.push(token);
    }
    let finalWorking = translatedTokens.join("");
    for (const ent of entities) {
      finalWorking = finalWorking.split(ent.placeholder).join(ent.raw);
    }
    return {
      translatedText: finalWorking,
      status: matched || entities.length > 0 ? "success" : "unverified",
      warnings: matched ? [] : ["NO_DIRECT_TERM_MATCH"]
    };
  }
  function escapeRegExp2(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function translateLocalText(text, sourceLang, targetLang) {
    const normTarget = targetLang.trim().toLowerCase();
    const sovereignPrefixes = ["ewo", "fuv", "fub", "hau", "knc", "pcm"];
    if (sovereignPrefixes.some((p) => normTarget.startsWith(p))) {
      return translateSentenceToSovereign(text, targetLang);
    }
    if (normTarget === "dua" || normTarget === "dua-cm") {
      return {
        translatedText: text,
        status: "unverified",
        warnings: ["DUALA_QUARANTINED_UNVERIFIED", "DUALA_NO_VERIFIED_TRANSLATION"]
      };
    }
    return { translatedText: text, status: "unverified", warnings: ["NO_LOCAL_TRANSLATION"] };
  }
  var FIXTURES = {
    // FR -> EN
    "fr:en:Bonjour": "Hello",
    "fr:en:Solde": "Balance",
    "fr:en:Solde disponible": "Available balance",
    "fr:en:Solde disponible (compte principal)": "Available balance (main account)",
    "fr:en:Virement": "Transfer",
    "fr:en:Transfert": "Transfer",
    "fr:en:Effectuer un transfert": "Make a transfer",
    "fr:en:Effectuer un transfert d'argent": "Make a money transfer",
    "fr:en:Confirmer": "Confirm",
    "fr:en:Confirmer le transfert": "Confirm transfer",
    "fr:en:Annuler": "Cancel",
    "fr:en:Frais": "Fees",
    "fr:en:Frais de transfert": "Transfer fees",
    "fr:en:Retrait": "Withdrawal",
    "fr:en:D\xE9p\xF4t": "Deposit",
    "fr:en:B\xE9n\xE9ficiaire": "Beneficiary",
    "fr:en:Transaction": "Transaction",
    "fr:en:Historique des transactions": "Transaction history",
    "fr:en:Num\xE9ro de t\xE9l\xE9phone": "Phone number",
    "fr:en:Num\xE9ro du destinataire": "Recipient mobile number",
    "fr:en:Num\xE9ro du destinataire (Orange / MTN)": "Recipient mobile number (Orange / MTN)",
    "fr:en:Montant": "Amount",
    "fr:en:Montant du transfert": "Transfer amount",
    "fr:en:Montant du transfert (FCFA)": "Transfer amount (FCFA)",
    "fr:en:Motif du paiement": "Payment reason",
    "fr:en:Motif du paiement / r\xE9f\xE9rence": "Payment reason / reference",
    "fr:en:Paiement tontine mensuelle": "Monthly tontine contribution",
    "fr:en:Frais de scolarit\xE9 trimestre 1": "Term 1 tuition fees",
    "fr:en:Facture \xE9lectricit\xE9 #48291": "Electricity bill #48291",
    "fr:en:Achats provisions": "Grocery shopping",
    "fr:en:Frais estim\xE9s: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie": "Estimated fees: 150 FCFA | Zero financial drift guaranteed",
    "fr:en:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Transfer completed successfully! Digital receipt generated.",
    // EN -> FR
    "en:fr:Hello": "Bonjour",
    "en:fr:Balance": "Solde",
    "en:fr:Available balance": "Solde disponible",
    "en:fr:Transfer": "Virement",
    "en:fr:Confirm": "Confirmer",
    "en:fr:Cancel": "Annuler",
    "en:fr:Fees": "Frais",
    "en:fr:Withdrawal": "Retrait",
    "en:fr:Deposit": "D\xE9p\xF4t",
    "en:fr:Beneficiary": "B\xE9n\xE9ficiaire",
    // 1. FR -> EWONDO (ewo-CM / ewo) — Certified NACALCO / Yaoundé I terms
    "fr:ewo-CM:Solde": "M\xF3ni m\xED ne",
    "fr:ewo-CM:Solde disponible": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
    "fr:ewo-CM:Solde disponible (compte principal)": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng (\xE9k\xF3bl\xF3 \xE9t\xE1m)",
    "fr:ewo-CM:Virement": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Transfert": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Effectuer un transfert": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Effectuer un transfert d'argent": "L\xF3m m\xF3ni",
    "fr:ewo-CM:Confirmer": "T\xEDb\xEDli t\xF3b\xF3",
    "fr:ewo-CM:Confirmer le transfert": "T\xEDb\xEDli t\xF3b\xF3 nl\xF3m",
    "fr:ewo-CM:Annuler": "Dz\xE1gb\xE1",
    "fr:ewo-CM:Frais": "M\xF3ni m\xE9bemb\xE1",
    "fr:ewo-CM:Frais de transfert": "M\xF3ni m\xE9bemb\xE1 m\xE9 nl\xF3m",
    "fr:ewo-CM:Retrait": "N\xF2ng m\xF3ni",
    "fr:ewo-CM:D\xE9p\xF4t": "W\xF3gl\xF4 m\xF3ni",
    "fr:ewo-CM:B\xE9n\xE9ficiaire": "Ny\xED a n\xF2ng m\xF3ni",
    "fr:ewo-CM:Transaction": "Nl\xF3m m\xF3ni",
    "fr:ewo-CM:Historique des transactions": "Minl\xF3m m\xED ay\xE1a l\xF3t",
    "fr:ewo-CM:Num\xE9ro de t\xE9l\xE9phone": "Nlamb\xE1 telef\xF4n",
    "fr:ewo-CM:Num\xE9ro du destinataire": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni",
    "fr:ewo-CM:Num\xE9ro du destinataire (Orange / MTN)": "Nlamb\xE1 ny\xED a n\xF2ng m\xF3ni (Orange / MTN)",
    "fr:ewo-CM:Montant": "Abui m\xF3ni",
    "fr:ewo-CM:Montant du transfert": "Abui m\xF3ni y\xE1 nl\xF3m",
    "fr:ewo-CM:Montant du transfert (FCFA)": "Abui m\xF3ni (FCFA)",
    "fr:ewo-CM:Motif du paiement": "Asu dz\xE9",
    "fr:ewo-CM:Motif du paiement / r\xE9f\xE9rence": "Asu dz\xE9 / nkat",
    "fr:ewo-CM:Paiement tontine mensuelle": "M\xF3ni ts\u0254\u0301 ng\u0254\u0301n",
    "fr:ewo-CM:Frais de scolarit\xE9 trimestre 1": "M\xF3ni suk\xFA ng\u0254\u0301n 1",
    "fr:ewo-CM:Facture \xE9lectricit\xE9 #48291": "Kalad\xED \xE9lekts\xEDki #48291",
    "fr:ewo-CM:Achats provisions": "K\xF9s bid\xED",
    "fr:ewo-CM:Frais estim\xE9s: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie": "M\xF3ni m\xE9bemb\xE1: 150 FCFA | Z\xE9ro d\xE9rive financi\xE8re garantie",
    "fr:ewo-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "L\xF3m m\xF3ni l'ay\xE1a d\xFAa ! Kalad\xED nl\xE1man ay\xE1a f\xF3b\xE1n.",
    // 2. FR -> FULFULDE (fuv-CM / fuv) — Northern Cameroon & CEMAC
    "fr:fuv-CM:Solde": "Ke\u0253al",
    "fr:fuv-CM:Solde disponible": "Ngalu he\u0253otoongu",
    "fr:fuv-CM:Solde disponible (compte principal)": "Ngalu he\u0253otoongu (konta maw\u0257o)",
    "fr:fuv-CM:Virement": "Neldugol ceede",
    "fr:fuv-CM:Transfert": "Neldugol ceede",
    "fr:fuv-CM:Effectuer un transfert": "Neldu ceede",
    "fr:fuv-CM:Effectuer un transfert d'argent": "Neldu ceede jaaw\u0257um",
    "fr:fuv-CM:Confirmer": "Tabintin",
    "fr:fuv-CM:Confirmer le transfert": "Tabintin neldugol",
    "fr:fuv-CM:Annuler": "Haaytinu",
    "fr:fuv-CM:Frais": "Ceede golle",
    "fr:fuv-CM:Frais de transfert": "Ceede neldugol",
    "fr:fuv-CM:Retrait": "Ittugol ceede",
    "fr:fuv-CM:D\xE9p\xF4t": "Watugol ceede",
    "fr:fuv-CM:B\xE9n\xE9ficiaire": "Ke\u0253oowo",
    "fr:fuv-CM:Transaction": "Golle ceede",
    "fr:fuv-CM:Historique des transactions": "Tariika golle ceede",
    "fr:fuv-CM:Num\xE9ro de t\xE9l\xE9phone": "Lamba telefo\u014B",
    "fr:fuv-CM:Num\xE9ro du destinataire": "Lamba ke\u0253oowo",
    "fr:fuv-CM:Num\xE9ro du destinataire (Orange / MTN)": "Lamba ke\u0253oowo (Orange / MTN)",
    "fr:fuv-CM:Montant": "Ke\u0253al ceede",
    "fr:fuv-CM:Montant du transfert": "Ke\u0253al ceede neldetee\u0257um",
    "fr:fuv-CM:Montant du transfert (FCFA)": "Ke\u0253al ceede (FCFA)",
    "fr:fuv-CM:Motif du paiement": "Daliila yo\u0253ol",
    "fr:fuv-CM:Paiement tontine mensuelle": "Yo\u0253ol dente lewru",
    "fr:fuv-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Ceede neldaama e jam ! Kere\u0257i he\u0253aama.",
    // 3. FR -> HAOUSSA (hau-CM / hau) — Northern Cameroon & CEMAC Corridors
    "fr:hau-CM:Solde": "Ragowar ku\u0257i",
    "fr:hau-CM:Solde disponible": "Ku\u0257in da za a iya amfani da su",
    "fr:hau-CM:Solde disponible (compte principal)": "Ku\u0257in da za a iya amfani da su (babban asusu)",
    "fr:hau-CM:Virement": "Tura ku\u0257i",
    "fr:hau-CM:Transfert": "Tura ku\u0257i",
    "fr:hau-CM:Effectuer un transfert": "Aika ku\u0257i",
    "fr:hau-CM:Effectuer un transfert d'argent": "Aika ku\u0257i cikin sauri",
    "fr:hau-CM:Confirmer": "Tabbatar",
    "fr:hau-CM:Confirmer le transfert": "Tabbatar da tura ku\u0257i",
    "fr:hau-CM:Annuler": "Soke",
    "fr:hau-CM:Frais": "Ku\u0257in sabis",
    "fr:hau-CM:Frais de transfert": "Ku\u0257in aika ku\u0257i",
    "fr:hau-CM:Retrait": "Cire ku\u0257i",
    "fr:hau-CM:D\xE9p\xF4t": "Sanya ku\u0257i",
    "fr:hau-CM:B\xE9n\xE9ficiaire": "Mai kar\u0253a",
    "fr:hau-CM:Transaction": "Mu'amalar ku\u0257i",
    "fr:hau-CM:Historique des transactions": "Tarihin ma'amaloli",
    "fr:hau-CM:Num\xE9ro de t\xE9l\xE9phone": "Lambar waya",
    "fr:hau-CM:Num\xE9ro du destinataire": "Lambar wayar mai kar\u0253a",
    "fr:hau-CM:Num\xE9ro du destinataire (Orange / MTN)": "Lambar mai kar\u0253a (Orange / MTN)",
    "fr:hau-CM:Montant": "Adadin ku\u0257i",
    "fr:hau-CM:Montant du transfert": "Adadin ku\u0257in da za a aika",
    "fr:hau-CM:Montant du transfert (FCFA)": "Adadin ku\u0257i (FCFA)",
    "fr:hau-CM:Motif du paiement": "Dalilin biya",
    "fr:hau-CM:Paiement tontine mensuelle": "Biyan adashe na wata",
    "fr:hau-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "An aika ku\u0257i cikin nasara ! An samar da rasit.",
    // 4. FR -> KANURI (knc-CM / knc) — Far North & Lake Chad
    "fr:knc-CM:Solde": "Liman kali",
    "fr:knc-CM:Solde disponible": "Liman sawawa",
    "fr:knc-CM:Solde disponible (compte principal)": "Liman sawawa (konta kura)",
    "fr:knc-CM:Virement": "Kudi tewuro",
    "fr:knc-CM:Transfert": "Kudi tewuro",
    "fr:knc-CM:Effectuer un transfert": "Kudi tewuro diyiram",
    "fr:knc-CM:Effectuer un transfert d'argent": "Kudi tewuro diyiram lewuro",
    "fr:knc-CM:Confirmer": "Gade taro",
    "fr:knc-CM:Confirmer le transfert": "Tewuro gade taro",
    "fr:knc-CM:Annuler": "Kola",
    "fr:knc-CM:Frais": "Liman ladan",
    "fr:knc-CM:Frais de transfert": "Kudi tewuro ladan",
    "fr:knc-CM:Retrait": "Kudi roptiro",
    "fr:knc-CM:D\xE9p\xF4t": "Kudi ciro",
    "fr:knc-CM:B\xE9n\xE9ficiaire": "Kudi ngowoma",
    "fr:knc-CM:Transaction": "Kudi cidaram",
    "fr:knc-CM:Historique des transactions": "Kudi cidaram gargam",
    "fr:knc-CM:Num\xE9ro de t\xE9l\xE9phone": "Namba talaho",
    "fr:knc-CM:Num\xE9ro du destinataire": "Namba ngowoma",
    "fr:knc-CM:Num\xE9ro du destinataire (Orange / MTN)": "Namba ngowoma (Orange / MTN)",
    "fr:knc-CM:Montant": "Kudi yanyi",
    "fr:knc-CM:Montant du transfert": "Kudi tewuro yanyi",
    "fr:knc-CM:Montant du transfert (FCFA)": "Kudi yanyi (FCFA)",
    "fr:knc-CM:Motif du paiement": "Dali biya ro",
    "fr:knc-CM:Paiement tontine mensuelle": "Kenta cida biya kambe",
    "fr:knc-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Kudi tewuro ngelawa lan cidono ! Risit goza.",
    // 5. FR -> CAMEROON PIDGIN ENGLISH (pcm-CM / pcm) — Urban markets, NW, SW, Littoral
    "fr:pcm-CM:Solde": "Moni wey de",
    "fr:pcm-CM:Solde disponible": "Moni wey yu fit yuz",
    "fr:pcm-CM:Solde disponible (compte principal)": "Moni wey yu fit yuz (men akaunt)",
    "fr:pcm-CM:Virement": "Send moni",
    "fr:pcm-CM:Transfert": "Send moni",
    "fr:pcm-CM:Effectuer un transfert": "Send moni nau",
    "fr:pcm-CM:Effectuer un transfert d'argent": "Send moni shap shap",
    "fr:pcm-CM:Confirmer": "Kofam",
    "fr:pcm-CM:Confirmer le transfert": "Kofam di transfer",
    "fr:pcm-CM:Annuler": "Kansul",
    "fr:pcm-CM:Frais": "Kach moni",
    "fr:pcm-CM:Frais de transfert": "Transfer chach",
    "fr:pcm-CM:Retrait": "Komot moni",
    "fr:pcm-CM:D\xE9p\xF4t": "Put moni",
    "fr:pcm-CM:B\xE9n\xE9ficiaire": "Pesin wey de resiv moni",
    "fr:pcm-CM:Transaction": "Pemen",
    "fr:pcm-CM:Historique des transactions": "Old pemen dem",
    "fr:pcm-CM:Num\xE9ro de t\xE9l\xE9phone": "Fon nomba",
    "fr:pcm-CM:Num\xE9ro du destinataire": "Pesin fon nomba",
    "fr:pcm-CM:Num\xE9ro du destinataire (Orange / MTN)": "Pesin fon nomba (Orange / MTN)",
    "fr:pcm-CM:Montant": "Haumoch moni",
    "fr:pcm-CM:Montant du transfert": "Moni wey yu wan send",
    "fr:pcm-CM:Montant du transfert (FCFA)": "Haumoch moni (FCFA)",
    "fr:pcm-CM:Motif du paiement": "Wetin dis moni na for",
    "fr:pcm-CM:Paiement tontine mensuelle": "Njangi moni for dis mont",
    "fr:pcm-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Moni don go fain fain ! Resit don redi.",
    // EN -> 5 LANGUAGES
    "en:ewo-CM:Balance": "M\xF3ni m\xED ne",
    "en:ewo-CM:Available balance": "M\xF3ni m\xED ne w\xE1 \xE9 b\u1EBDng",
    "en:ewo-CM:Transfer": "L\xF3m m\xF3ni",
    "en:ewo-CM:Confirm": "T\xEDb\xEDli t\xF3b\xF3",
    "en:ewo-CM:Cancel": "Dz\xE1gb\xE1",
    "en:ewo-CM:Fees": "M\xF3ni m\xE9bemb\xE1",
    "en:ewo-CM:Beneficiary": "Ny\xED a n\xF2ng m\xF3ni",
    "en:fuv-CM:Balance": "Ke\u0253al",
    "en:fuv-CM:Available balance": "Ngalu he\u0253otoongu",
    "en:fuv-CM:Transfer": "Neldugol ceede",
    "en:fuv-CM:Confirm": "Tabintin",
    "en:fuv-CM:Cancel": "Haaytinu",
    "en:hau-CM:Balance": "Ragowar ku\u0257i",
    "en:hau-CM:Available balance": "Ku\u0257in da za a iya amfani da su",
    "en:hau-CM:Transfer": "Tura ku\u0257i",
    "en:hau-CM:Confirm": "Tabbatar",
    "en:hau-CM:Cancel": "Soke",
    "en:knc-CM:Balance": "Liman kali",
    "en:knc-CM:Available balance": "Liman sawawa",
    "en:knc-CM:Transfer": "Kudi tewuro",
    "en:knc-CM:Confirm": "Gade taro",
    "en:knc-CM:Cancel": "Kola",
    "en:pcm-CM:Balance": "Moni wey de",
    "en:pcm-CM:Available balance": "Moni wey yu fit yuz",
    "en:pcm-CM:Transfer": "Send moni",
    "en:pcm-CM:Confirm": "Kofam",
    "en:pcm-CM:Cancel": "Kansul"
  };
  for (const [key, val] of Object.entries(FIXTURES)) {
    for (const code of ["ewo", "fuv", "hau", "knc", "pcm"]) {
      if (key.includes(`${code}-CM`)) {
        FIXTURES[key.replace(`${code}-CM`, code)] = val;
      }
    }
  }
  var NLLB_FINANCIAL_CACHE = {
    // Fulfulde (fuv-CM)
    "fr:fuv-CM:Solde": "Ke\u0253al",
    "fr:fuv-CM:Solde disponible": "Ngalu he\u0253otoongu",
    "fr:fuv-CM:Solde disponible (compte principal)": "Ngalu he\u0253otoongu (konta maw\u0257o)",
    "fr:fuv-CM:Virement": "Neldugol ceede",
    "fr:fuv-CM:Transfert": "Neldugol ceede",
    "fr:fuv-CM:Effectuer un transfert": "Neldu ceede",
    "fr:fuv-CM:Effectuer un transfert d'argent": "Neldu ceede jaaw\u0257um",
    "fr:fuv-CM:Confirmer": "Tabintin",
    "fr:fuv-CM:Confirmer le transfert": "Tabintin neldugol",
    "fr:fuv-CM:Annuler": "Haaytinu",
    "fr:fuv-CM:Frais": "Ceede golle",
    "fr:fuv-CM:Frais de transfert": "Ceede neldugol",
    "fr:fuv-CM:Retrait": "Ittugol ceede",
    "fr:fuv-CM:D\xE9p\xF4t": "Watugol ceede",
    "fr:fuv-CM:B\xE9n\xE9ficiaire": "Ke\u0253oowo",
    "fr:fuv-CM:Transaction": "Golle ceede",
    "fr:fuv-CM:Historique des transactions": "Tariika golle ceede",
    "fr:fuv-CM:Num\xE9ro de t\xE9l\xE9phone": "Lamba telefo\u014B",
    "fr:fuv-CM:Num\xE9ro du destinataire": "Lamba ke\u0253oowo",
    "fr:fuv-CM:Num\xE9ro du destinataire (Orange / MTN)": "Lamba ke\u0253oowo (Orange / MTN)",
    "fr:fuv-CM:Montant": "Ke\u0253al ceede",
    "fr:fuv-CM:Montant du transfert": "Ke\u0253al ceede neldetee\u0257um",
    "fr:fuv-CM:Montant du transfert (FCFA)": "Ke\u0253al ceede (FCFA)",
    "fr:fuv-CM:Motif du paiement": "Daliila yo\u0253ol",
    "fr:fuv-CM:Paiement tontine mensuelle": "Yo\u0253ol dente lewru",
    "fr:fuv-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Ceede neldaama e jam ! Kere\u0257i he\u0253aama.",
    "fr:fuv-CM:Bienvenue sur la plateforme financi\xE8re.": "On nja\u0253ii e nder fannu jaaynde.",
    // Haoussa (hau-CM)
    "fr:hau-CM:Solde": "Ragowar ku\u0257i",
    "fr:hau-CM:Solde disponible": "Ku\u0257in da za a iya amfani da su",
    "fr:hau-CM:Solde disponible (compte principal)": "Ku\u0257in da za a iya amfani da su (babban asusu)",
    "fr:hau-CM:Virement": "Tura ku\u0257i",
    "fr:hau-CM:Transfert": "Tura ku\u0257i",
    "fr:hau-CM:Effectuer un transfert": "Aika ku\u0257i",
    "fr:hau-CM:Effectuer un transfert d'argent": "Aika ku\u0257i cikin sauri",
    "fr:hau-CM:Confirmer": "Tabbatar",
    "fr:hau-CM:Confirmer le transfert": "Tabbatar da tura ku\u0257i",
    "fr:hau-CM:Annuler": "Soke",
    "fr:hau-CM:Frais": "Ku\u0257in sabis",
    "fr:hau-CM:Frais de transfert": "Ku\u0257in aika ku\u0257i",
    "fr:hau-CM:Retrait": "Cire ku\u0257i",
    "fr:hau-CM:D\xE9p\xF4t": "Sanya ku\u0257i",
    "fr:hau-CM:B\xE9n\xE9ficiaire": "Mai kar\u0253a",
    "fr:hau-CM:Transaction": "Mu'amalar ku\u0257i",
    "fr:hau-CM:Historique des transactions": "Tarihin ma'amaloli",
    "fr:hau-CM:Num\xE9ro de t\xE9l\xE9phone": "Lambar waya",
    "fr:hau-CM:Num\xE9ro du destinataire": "Lambar wayar mai kar\u0253a",
    "fr:hau-CM:Num\xE9ro du destinataire (Orange / MTN)": "Lambar mai kar\u0253a (Orange / MTN)",
    "fr:hau-CM:Montant": "Adadin ku\u0257i",
    "fr:hau-CM:Montant du transfert": "Adadin ku\u0257in da za a aika",
    "fr:hau-CM:Montant du transfert (FCFA)": "Adadin ku\u0257i (FCFA)",
    "fr:hau-CM:Motif du paiement": "Dalilin biya",
    "fr:hau-CM:Paiement tontine mensuelle": "Biyan adashe na wata",
    "fr:hau-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "An aika ku\u0257i cikin nasara ! An samar da rasit.",
    "fr:hau-CM:Bienvenue sur la plateforme financi\xE8re.": "Barka da zuwa dandalin hada-hadar kudi.",
    // Kanuri (knc-CM)
    "fr:knc-CM:Solde": "Liman kali",
    "fr:knc-CM:Solde disponible": "Liman sawawa",
    "fr:knc-CM:Solde disponible (compte principal)": "Liman sawawa (konta kura)",
    "fr:knc-CM:Virement": "Kudi tewuro",
    "fr:knc-CM:Transfert": "Kudi tewuro",
    "fr:knc-CM:Effectuer un transfert": "Kudi tewuro diyiram",
    "fr:knc-CM:Effectuer un transfert d'argent": "Kudi tewuro diyiram lewuro",
    "fr:knc-CM:Confirmer": "Gade taro",
    "fr:knc-CM:Confirmer le transfert": "Tewuro gade taro",
    "fr:knc-CM:Annuler": "Kola",
    "fr:knc-CM:Frais": "Liman ladan",
    "fr:knc-CM:Frais de transfert": "Kudi tewuro ladan",
    "fr:knc-CM:Retrait": "Kudi roptiro",
    "fr:knc-CM:D\xE9p\xF4t": "Kudi ciro",
    "fr:knc-CM:B\xE9n\xE9ficiaire": "Kudi ngowoma",
    "fr:knc-CM:Transaction": "Kudi cidaram",
    "fr:knc-CM:Historique des transactions": "Kudi cidaram gargam",
    "fr:knc-CM:Num\xE9ro de t\xE9l\xE9phone": "Namba talaho",
    "fr:knc-CM:Num\xE9ro du destinataire": "Namba ngowoma",
    "fr:knc-CM:Num\xE9ro du destinataire (Orange / MTN)": "Namba ngowoma (Orange / MTN)",
    "fr:knc-CM:Montant": "Kudi yanyi",
    "fr:knc-CM:Montant du transfert": "Kudi tewuro yanyi",
    "fr:knc-CM:Montant du transfert (FCFA)": "Kudi yanyi (FCFA)",
    "fr:knc-CM:Motif du paiement": "Dali biya ro",
    "fr:knc-CM:Paiement tontine mensuelle": "Kenta cida biya kambe",
    "fr:knc-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Kudi tewuro ngelawa lan cidono ! Risit goza.",
    // Cameroon Pidgin English (pcm-CM)
    "fr:pcm-CM:Solde": "Moni wey de",
    "fr:pcm-CM:Solde disponible": "Moni wey yu fit yuz",
    "fr:pcm-CM:Solde disponible (compte principal)": "Moni wey yu fit yuz (men akaunt)",
    "fr:pcm-CM:Virement": "Send moni",
    "fr:pcm-CM:Transfert": "Send moni",
    "fr:pcm-CM:Effectuer un transfert": "Send moni nau",
    "fr:pcm-CM:Effectuer un transfert d'argent": "Send moni shap shap",
    "fr:pcm-CM:Confirmer": "Kofam",
    "fr:pcm-CM:Confirmer le transfert": "Kofam di transfer",
    "fr:pcm-CM:Annuler": "Kansul",
    "fr:pcm-CM:Frais": "Kach moni",
    "fr:pcm-CM:Frais de transfert": "Transfer chach",
    "fr:pcm-CM:Retrait": "Komot moni",
    "fr:pcm-CM:D\xE9p\xF4t": "Put moni",
    "fr:pcm-CM:B\xE9n\xE9ficiaire": "Pesin wey de resiv moni",
    "fr:pcm-CM:Transaction": "Pemen",
    "fr:pcm-CM:Historique des transactions": "Old pemen dem",
    "fr:pcm-CM:Num\xE9ro de t\xE9l\xE9phone": "Fon nomba",
    "fr:pcm-CM:Num\xE9ro du destinataire": "Pesin fon nomba",
    "fr:pcm-CM:Num\xE9ro du destinataire (Orange / MTN)": "Pesin fon nomba (Orange / MTN)",
    "fr:pcm-CM:Montant": "Haumoch moni",
    "fr:pcm-CM:Montant du transfert": "Moni wey yu wan send",
    "fr:pcm-CM:Montant du transfert (FCFA)": "Haumoch moni (FCFA)",
    "fr:pcm-CM:Motif du paiement": "Wetin dis moni na for",
    "fr:pcm-CM:Paiement tontine mensuelle": "Njangi moni for dis mont",
    "fr:pcm-CM:Transfert effectu\xE9 avec succ\xE8s ! Le re\xE7u a \xE9t\xE9 g\xE9n\xE9r\xE9.": "Moni don go fain fain ! Resit don redi.",
    "fr:pcm-CM:Bienvenue sur la plateforme financi\xE8re.": "Welkam fo di moni platform.",
    "fr:pcm-CM:Envoyer de l'argent par t\xE9l\xE9phone rapidement.": "Send money by phone fast.",
    // English source phrases
    "en:fuv-CM:Balance": "Ke\u0253al",
    "en:fuv-CM:Available balance": "Ngalu he\u0253otoongu",
    "en:fuv-CM:Transfer": "Neldugol ceede",
    "en:fuv-CM:Confirm": "Tabintin",
    "en:fuv-CM:Cancel": "Haaytinu",
    "en:hau-CM:Balance": "Ragowar ku\u0257i",
    "en:hau-CM:Available balance": "Ku\u0257in da za a iya amfani da su",
    "en:hau-CM:Transfer": "Tura ku\u0257i",
    "en:hau-CM:Confirm": "Tabbatar",
    "en:hau-CM:Cancel": "Soke",
    "en:knc-CM:Balance": "Liman kali",
    "en:knc-CM:Available balance": "Liman sawawa",
    "en:knc-CM:Transfer": "Kudi tewuro",
    "en:knc-CM:Confirm": "Gade taro",
    "en:knc-CM:Cancel": "Kola",
    "en:pcm-CM:Balance": "Moni wey de",
    "en:pcm-CM:Available balance": "Moni wey yu fit yuz",
    "en:pcm-CM:Transfer": "Send moni",
    "en:pcm-CM:Confirm": "Kofam",
    "en:pcm-CM:Cancel": "Kansul"
  };
  for (const [key, val] of Object.entries(NLLB_FINANCIAL_CACHE)) {
    for (const code of ["fuv", "hau", "knc", "pcm"]) {
      if (key.includes(`${code}-CM`)) {
        NLLB_FINANCIAL_CACHE[key.replace(`${code}-CM`, code)] = val;
      }
    }
  }

  // src/content.ts
  function splitIntoAcousticClauses(text) {
    const clean = text.trim();
    if (!clean) return [];
    if (clean.length <= 48) return [clean];
    const clauses = [];
    const parts = clean.split(/(?<=[.!?;:,])\s+/);
    let current = "";
    for (const part of parts) {
      if (!part) continue;
      const candidate = current ? `${current} ${part}` : part;
      if (candidate.length <= 48) {
        current = candidate;
      } else {
        if (current) clauses.push(current.trim());
        if (part.length <= 48) {
          current = part;
        } else {
          const words = part.split(/\s+/);
          let sub = "";
          for (const w of words) {
            const candSub = sub ? `${sub} ${w}` : w;
            if (candSub.length <= 45) {
              sub = candSub;
            } else {
              if (sub) clauses.push(sub.trim());
              sub = w;
            }
          }
          current = sub;
        }
      }
    }
    if (current && current.trim()) clauses.push(current.trim());
    return clauses.filter((c) => c.length > 0);
  }
  var AfricanSpeechPlayer = class {
    isPlaying = false;
    audioCtx = null;
    activeSource = null;
    activeAudio = null;
    onEndCallback = null;
    currentUtteranceId = 0;
    activeUtterance = null;
    audioBufferCache = /* @__PURE__ */ new Map();
    onUnavailableCallback = null;
    constructor() {
      this.prewarm();
      if (typeof window !== "undefined") {
        const unlock = () => {
          this.ensureAudioContext();
        };
        window.addEventListener("pointerdown", unlock, { capture: true, passive: true });
        window.addEventListener("click", unlock, { capture: true, passive: true });
        window.addEventListener("keydown", unlock, { capture: true, passive: true });
        window.addEventListener("touchend", unlock, { capture: true, passive: true });
      }
    }
    prewarm() {
      if (typeof window === "undefined") return;
      try {
        this.ensureAudioContext();
      } catch {
      }
    }
    ensureAudioContext() {
      try {
        const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
        if (AudioCtxClass) {
          if (!this.audioCtx) {
            this.audioCtx = new AudioCtxClass();
          }
          if (this.audioCtx.state === "suspended") {
            this.audioCtx.resume().catch(() => {
            });
          }
        }
      } catch {
      }
    }
    isAudioContextSuspended() {
      return !this.audioCtx || this.audioCtx.state === "suspended";
    }
    speak(text, phonetic, onEnd, targetLang = "ewo-CM") {
      if (typeof window === "undefined") return;
      this.stop();
      this.currentUtteranceId++;
      const thisId = this.currentUtteranceId;
      this.onEndCallback = onEnd || null;
      const isEwondo = targetLang.startsWith("ewo");
      const spokenRaw = phonetic || (isEwondo ? getEwondoPhonetic(text) : text) || text;
      const spokenText = spokenRaw.replace(/-/g, "").trim();
      if (!spokenText) return;
      this.ensureAudioContext();
      const clauses = splitIntoAcousticClauses(spokenText);
      if (clauses.length <= 1) {
        this.playSingleClause(spokenText, thisId, targetLang, () => {
          this.finishUtterance(thisId);
        });
      } else {
        this.playClauseQueue(clauses, 0, thisId, targetLang);
      }
    }
    playClauseQueue(clauses, index, thisId, targetLang) {
      if (this.currentUtteranceId !== thisId || index >= clauses.length) {
        if (index >= clauses.length) {
          this.finishUtterance(thisId);
        }
        return;
      }
      const currentClause = clauses[index];
      if (index + 1 < clauses.length) {
        this.precache(clauses[index + 1], targetLang);
      }
      this.playSingleClause(currentClause, thisId, targetLang, () => {
        if (this.currentUtteranceId === thisId) {
          this.playClauseQueue(clauses, index + 1, thisId, targetLang);
        }
      });
    }
    playSingleClause(clauseText, thisId, targetLang, onClauseEnd) {
      const cacheKey = `${targetLang}:${clauseText.toLowerCase()}`;
      const cachedBuffer = this.audioBufferCache.get(cacheKey);
      if (cachedBuffer) {
        this.playBuffer(cachedBuffer, thisId, onClauseEnd);
        return;
      }
      const tryDirectFetch = () => {
        return fetch(`http://127.0.0.1:3002/synthesize?lang=${encodeURIComponent(targetLang)}&text=${encodeURIComponent(clauseText)}`).then((r) => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))).catch(
          () => fetch("http://127.0.0.1:3001/v1/speech/synthesize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: clauseText, lang: targetLang })
          }).then((r) => r.ok ? r.json() : Promise.reject(new Error(`API HTTP ${r.status}`)))
        ).then(async (data) => {
          if (this.currentUtteranceId !== thisId) return;
          const b64 = data?.audioBase64 || (typeof data?.audioUrl === "string" ? data.audioUrl.replace("data:audio/wav;base64,", "") : "");
          if (b64) {
            const audioUrl = `data:audio/wav;base64,${b64}`;
            await this.playNeuralAudio(audioUrl, thisId, clauseText, targetLang, cacheKey, onClauseEnd);
          } else {
            this.onUnavailableCallback?.("Serveur vocal (:3002) indisponible");
            onClauseEnd();
          }
        }).catch(() => {
          if (this.currentUtteranceId !== thisId) return;
          this.onUnavailableCallback?.("Serveur vocal (:3002) hors ligne");
          onClauseEnd();
        });
      };
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        try {
          chrome.runtime.sendMessage(
            {
              type: "SYNTHESIZE_SPEECH",
              text: clauseText,
              lang: targetLang
            },
            async (res) => {
              if (this.currentUtteranceId !== thisId) return;
              const runtimeErr = chrome.runtime?.lastError;
              if (!runtimeErr && res?.success && res.result?.audioUrl) {
                await this.playNeuralAudio(res.result.audioUrl, thisId, clauseText, targetLang, cacheKey, onClauseEnd);
              } else {
                tryDirectFetch();
              }
            }
          );
        } catch {
          tryDirectFetch();
        }
        return;
      }
      tryDirectFetch();
    }
    playBuffer(audioBuffer, thisId, onEnd) {
      if (!this.audioCtx) {
        this.ensureAudioContext();
      }
      if (!this.audioCtx || this.currentUtteranceId !== thisId) return;
      if (this.activeSource) {
        try {
          this.activeSource.stop();
          this.activeSource.disconnect();
        } catch {
        }
        this.activeSource = null;
      }
      if (this.audioCtx.state === "suspended") {
        this.audioCtx.resume().catch(() => {
        });
      }
      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.audioCtx.destination);
      this.activeSource = source;
      this.isPlaying = true;
      console.log(`[LinguaBridge Speech] AudioBuffer playback started (duration: ${audioBuffer.duration.toFixed(2)}s, ctx state: ${this.audioCtx.state})`);
      source.onended = () => {
        console.log("[LinguaBridge Speech] AudioBuffer playback finished");
        if (this.currentUtteranceId === thisId) {
          this.isPlaying = false;
          this.activeSource = null;
          if (onEnd) {
            onEnd();
          } else if (this.onEndCallback) {
            const cb = this.onEndCallback;
            this.onEndCallback = null;
            cb();
          }
        }
      };
      source.start(0);
    }
    async cacheAudioUrl(cacheKey, audioUrl) {
      try {
        this.ensureAudioContext();
        if (!this.audioCtx) return null;
        const base64Data = audioUrl.replace("data:audio/wav;base64,", "");
        const binaryStr = atob(base64Data);
        const len = binaryStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryStr.charCodeAt(i);
        }
        const audioBuffer = await this.audioCtx.decodeAudioData(bytes.buffer.slice(0));
        this.audioBufferCache.set(cacheKey, audioBuffer);
        return audioBuffer;
      } catch {
        return null;
      }
    }
    async precache(text, targetLang = "ewo-CM") {
      if (typeof window === "undefined" || !text) return;
      const isEwondo = targetLang.startsWith("ewo");
      const spokenRaw = isEwondo ? getEwondoPhonetic(text) : text;
      const spokenText = spokenRaw.replace(/-/g, "").trim();
      if (!spokenText) return;
      const clauses = splitIntoAcousticClauses(spokenText);
      const clauseToPrecache = clauses[0] || spokenText;
      const cacheKey = `${targetLang}:${clauseToPrecache.trim().toLowerCase()}`;
      if (this.audioBufferCache.has(cacheKey)) return;
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage(
          {
            type: "SYNTHESIZE_SPEECH",
            text: clauseToPrecache,
            lang: targetLang
          },
          async (res) => {
            if (res && res.success && res.result?.audioUrl) {
              await this.cacheAudioUrl(cacheKey, res.result.audioUrl);
            }
          }
        );
      }
    }
    async playNeuralAudio(audioUrl, thisId, spokenText, targetLang, cacheKey, onEnd) {
      console.log(`[LinguaBridge Speech] playNeuralAudio received payload (${audioUrl.length} chars) for "${spokenText.substring(0, 30)}"`);
      try {
        const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
        if (AudioCtxClass && audioUrl.startsWith("data:audio/wav;base64,")) {
          if (!this.audioCtx) {
            this.audioCtx = new AudioCtxClass();
          }
          if (this.audioCtx.state === "suspended") {
            await Promise.race([
              this.audioCtx.resume(),
              new Promise((resolve) => setTimeout(resolve, 180))
            ]);
          }
          if (this.audioCtx.state === "suspended") {
            throw new Error("AudioContext suspended");
          }
          const base64Data = audioUrl.replace("data:audio/wav;base64,", "");
          const binaryStr = atob(base64Data);
          const len = binaryStr.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
          }
          const audioBuffer = await this.audioCtx.decodeAudioData(bytes.buffer.slice(0));
          if (cacheKey) {
            this.audioBufferCache.set(cacheKey, audioBuffer);
          }
          if (this.currentUtteranceId !== thisId) return;
          this.playBuffer(audioBuffer, thisId, onEnd);
          return;
        }
      } catch {
      }
      try {
        const audio = new Audio(audioUrl);
        this.activeAudio = audio;
        audio.onplay = () => {
          if (this.currentUtteranceId === thisId) {
            this.isPlaying = true;
          }
        };
        const finish = () => {
          if (this.currentUtteranceId === thisId) {
            this.isPlaying = false;
            this.activeAudio = null;
            if (onEnd) {
              onEnd();
            } else if (this.onEndCallback) {
              const cb = this.onEndCallback;
              this.onEndCallback = null;
              cb();
            }
          }
        };
        audio.onended = finish;
        audio.onerror = () => {
          if (onEnd) {
            onEnd();
          } else {
            this.finishUtterance(thisId);
          }
        };
        const playPromise = audio.play();
        if (playPromise && typeof playPromise.catch === "function") {
          playPromise.catch(() => {
            if (onEnd) {
              onEnd();
            } else {
              this.finishUtterance(thisId);
            }
          });
        }
      } catch {
        if (onEnd) {
          onEnd();
        } else {
          this.finishUtterance(thisId);
        }
      }
    }
    playBrowserVoice(_text, _targetLang, thisId) {
      this.finishUtterance(thisId);
    }
    finishUtterance(thisId) {
      if (this.currentUtteranceId === thisId) {
        this.isPlaying = false;
        this.activeAudio = null;
        this.activeSource = null;
        this.activeUtterance = null;
        window.__linguaActiveUtterance = null;
        if (this.onEndCallback) {
          const cb = this.onEndCallback;
          this.onEndCallback = null;
          cb();
        }
      }
    }
    pause() {
      if (this.activeAudio && !this.activeAudio.paused) {
        this.activeAudio.pause();
      }
      if (typeof window !== "undefined" && "speechSynthesis" in window && window.speechSynthesis.speaking) {
        window.speechSynthesis.pause();
      }
    }
    resume() {
      if (this.activeAudio && this.activeAudio.paused) {
        this.activeAudio.play().catch(() => {
        });
      }
      if (typeof window !== "undefined" && "speechSynthesis" in window && window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
    stop() {
      this.currentUtteranceId++;
      if (this.activeSource) {
        try {
          this.activeSource.stop();
          this.activeSource.disconnect();
        } catch {
        }
        this.activeSource = null;
      }
      if (this.activeAudio) {
        try {
          this.activeAudio.pause();
          this.activeAudio.currentTime = 0;
        } catch {
        }
        this.activeAudio = null;
      }
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        try {
          window.speechSynthesis.cancel();
          window.speechSynthesis.resume();
        } catch {
        }
      }
      this.activeUtterance = null;
      window.__linguaActiveUtterance = null;
      this.isPlaying = false;
      this.onEndCallback = null;
    }
  };
  var EwondoSpeechPlayer = AfricanSpeechPlayer;
  var ExtensionAssistant = class _ExtensionAssistant {
    container = null;
    shadow = null;
    originalTextMap = /* @__PURE__ */ new Map();
    originalChildNodesMap = /* @__PURE__ */ new Map();
    static INLINE_TAGS = /* @__PURE__ */ new Set([
      "EM",
      "STRONG",
      "SPAN",
      "B",
      "I",
      "U",
      "A",
      "SMALL",
      "MARK",
      "SUB",
      "SUP",
      "CODE",
      "ABBR",
      "CITE",
      "TIME",
      "BDO",
      "BDI"
    ]);
    static CONTAINER_SELECTOR = 'h1, h2, h3, h4, h5, h6, p, li, button, label, dt, dd, td, th, blockquote, figcaption, summary, caption, [role="alert"], [role="dialog"], dialog, div.alert, div.modal, div.banner-alert, div.popup-error';
    static CONTAINER_BLOCK_TAGS = /* @__PURE__ */ new Set([
      "H1",
      "H2",
      "H3",
      "H4",
      "H5",
      "H6",
      "P",
      "LI",
      "BUTTON",
      "LABEL",
      "DT",
      "DD",
      "TD",
      "TH",
      "BLOCKQUOTE",
      "FIGCAPTION",
      "SUMMARY",
      "CAPTION",
      "DIALOG",
      '[ROLE="ALERT"]',
      '[ROLE="DIALOG"]',
      "DIV.ALERT",
      "DIV.MODAL",
      "DIV.BANNER-ALERT",
      "DIV.POPUP-ERROR"
    ]);
    originalAttrMap = /* @__PURE__ */ new Map();
    isPageTranslated = false;
    currentTargetLang = "ewo-CM";
    translateLocal(text) {
      return translateLocalText(text, this.currentSourceLang, this.currentTargetLang).translatedText;
    }
    currentSourceLang = typeof document !== "undefined" && document.documentElement?.lang?.toLowerCase().startsWith("en") ? "en" : "fr";
    isOpen = false;
    isCardOpen() {
      return this.isOpen;
    }
    activePanel = "translate";
    chatHistory = [];
    lastSelection = "";
    isTouchSpeakEnabled = false;
    userPausedVoice = false;
    isSiteDisabled = false;
    customPos = null;
    dragSuppressClick = false;
    activeBarState = { visible: false, text: "", phonetic: "" };
    speechPlayer = new EwondoSpeechPlayer();
    // Instant speech & phonetic cache to eliminate voice latency
    translationSpeechCache = /* @__PURE__ */ new Map();
    // Hover-to-speak tracking & debouncing ("survoler une section ça parle seul, une fois")
    hoverDwellTimeout = null;
    currentHoveredEl = null;
    currentSpokenEl = null;
    lastSpokenEl = null;
    // Lightweight debounced MutationObserver for dynamic SPA banking portals (Afriland, BICEC, Ecobank, UBA, Orange Money)
    mutationObserver = null;
    mutationDebounceTimeout = null;
    pendingMutations = /* @__PURE__ */ new Set();
    isTranslating = false;
    onMouseUpHandler = null;
    onRuntimeMessageHandler = null;
    onMouseOverHandler = null;
    onMouseOutHandler = null;
    onClickElementHandler = null;
    onTouchEndHandler = null;
    onFirstInteractionHandler = null;
    onDragMoveHandler = null;
    onDragEndHandler = null;
    onClickOutsideHandler = null;
    constructor() {
      this.speechPlayer.onUnavailableCallback = (reason) => {
        const phonEl = this.shadow?.getElementById("audio-phonetic");
        if (phonEl) {
          phonEl.textContent = reason;
          phonEl.style.color = "#fbbf24";
        }
      };
      this.init();
    }
    getCurrentHost() {
      if (typeof window === "undefined" || !window.location) return "";
      return window.location.hostname || window.location.origin || "";
    }
    clampPosition(left, top) {
      if (typeof window === "undefined") return { left, top };
      const vw = window.innerWidth || 1024;
      const vh = window.innerHeight || 768;
      const minTop = 12;
      const maxTop = Math.max(minTop, vh - 68);
      const leftEdge = 12;
      const rightEdge = Math.max(leftEdge, vw - 68);
      const midX = vw / 2;
      const snappedLeft = left < midX ? leftEdge : rightEdge;
      const clampedTop = Math.max(minTop, Math.min(maxTop, Math.round(top)));
      return {
        left: snappedLeft,
        top: clampedTop
      };
    }
    applyContainerPosition(left, top) {
      if (!this.container) return;
      const clamped = this.clampPosition(left, top);
      this.customPos = clamped;
      this.container.style.bottom = "auto";
      this.container.style.right = "auto";
      this.container.style.left = `${clamped.left}px`;
      this.container.style.top = `${clamped.top}px`;
    }
    getLangBadgeName(lang) {
      switch (lang) {
        case "ewo-CM":
          return "\u{1F1E8}\u{1F1F2} Ewondo";
        case "fuv-CM":
          return "\u{1F1E8}\u{1F1F2} Fulfulde";
        case "hau-CM":
          return "\u{1F1E8}\u{1F1F2} Haoussa";
        case "knc-CM":
          return "\u{1F1E8}\u{1F1F2} Kanuri";
        case "pcm-CM":
          return "\u{1F1E8}\u{1F1F2} Pidgin";
        default:
          return "\u{1F1E8}\u{1F1F2} Langue Nationale";
      }
    }
    detectSourceLanguage() {
      const declared = (document.documentElement.lang || "").toLowerCase();
      if (declared.startsWith("fr")) return "fr";
      if (declared.startsWith("en")) return "en";
      const sample = (document.body?.innerText || "").slice(0, 5e3).toLowerCase();
      const french = (sample.match(/\\b(le|la|les|des|vous|votre|pour|avec|compte|solde|frais|envoyer)\\b/g) || []).length;
      const english = (sample.match(/\\b(the|your|account|balance|fees|send|transfer|with|from|payment)\\b/g) || []).length;
      return english > french ? "en" : "fr";
    }
    isVoiceEnabled() {
      if (this.isSiteDisabled) return false;
      return this.isTouchSpeakEnabled || this.isPageTranslated && !this.userPausedVoice;
    }
    stopSpeech() {
      this.speechPlayer.stop();
      if (this.currentSpokenEl) {
        this.currentSpokenEl.style.outline = "";
        this.currentSpokenEl.style.cursor = "";
        if (this.currentHoveredEl === this.currentSpokenEl) {
          this.currentHoveredEl = null;
        }
        this.currentSpokenEl = null;
      }
    }
    init() {
      if (document.getElementById("linguabridge-extension-root")) return;
      const mount = () => {
        if (document.getElementById("linguabridge-extension-root")) return;
        const target = document.body || document.documentElement;
        if (!target) return;
        this.container = document.createElement("div");
        this.container.id = "linguabridge-extension-root";
        this.container.style.all = "initial";
        this.container.style.position = "fixed";
        this.container.style.bottom = "24px";
        this.container.style.right = "24px";
        this.container.style.zIndex = "2147483646";
        this.shadow = this.container.attachShadow({ mode: "open" });
        const markInside = (e) => {
          e.__lbInside = true;
        };
        this.shadow.addEventListener("click", markInside, true);
        this.container.addEventListener("click", markInside, true);
        this.render();
        target.appendChild(this.container);
        document.documentElement.setAttribute("data-linguabridge-extension", "active");
        if (typeof chrome !== "undefined" && chrome.storage?.local) {
          const host = this.getCurrentHost();
          chrome.storage.local.get(
            ["linguabridgeTargetLang", "linguabridgeAudioEnabled", "linguabridgeDisabledHosts", "linguabridgeWidgetPos"],
            (settings) => {
              const disabledHosts = Array.isArray(settings.linguabridgeDisabledHosts) ? settings.linguabridgeDisabledHosts : [];
              if (host && disabledHosts.includes(host)) {
                this.disableOnCurrentSite(false);
                return;
              }
              if (settings.linguabridgeTargetLang) this.currentTargetLang = settings.linguabridgeTargetLang;
              if (settings.linguabridgeAudioEnabled === true) {
                this.isTouchSpeakEnabled = true;
                this.userPausedVoice = false;
              } else if (settings.linguabridgeAudioEnabled === false) {
                this.isTouchSpeakEnabled = false;
              }
              if (settings.linguabridgeWidgetPos && typeof settings.linguabridgeWidgetPos.left === "number" && typeof settings.linguabridgeWidgetPos.top === "number") {
                this.applyContainerPosition(settings.linguabridgeWidgetPos.left, settings.linguabridgeWidgetPos.top);
              }
              this.render();
            }
          );
        }
        this.setupListeners();
        this.setupMutationObserver();
      };
      if (document.readyState === "loading") {
        window.addEventListener("DOMContentLoaded", mount);
      } else {
        mount();
      }
    }
    clearHoverState() {
      if (this.hoverDwellTimeout) {
        clearTimeout(this.hoverDwellTimeout);
        this.hoverDwellTimeout = null;
      }
      if (this.currentHoveredEl) {
        this.currentHoveredEl.style.outline = "";
        this.currentHoveredEl.style.cursor = "";
        this.currentHoveredEl = null;
      }
      this.stopSpeech();
      this.lastSpokenEl = null;
    }
    findMeaningfulSection(target) {
      if (!target) return null;
      if (this.isExtensionNode(target)) return null;
      const tag = target.tagName ? target.tagName.toLowerCase() : "";
      if (["script", "style", "code", "pre", "noscript", "svg", "path", "iframe"].includes(tag)) {
        return null;
      }
      const semanticBlock = target.closest(
        'h1, h2, h3, h4, h5, h6, p, button, a, li, td, th, label, dt, dd, summary, blockquote, figcaption, input, textarea, [role="button"], [role="link"], [role="heading"], [role="tab"], [role="menuitem"], [role="alert"], [role="dialog"], dialog, div.alert, div.modal, div.banner-alert, div.popup-error'
      );
      if (semanticBlock && !this.isExtensionNode(semanticBlock)) {
        const sTag = (semanticBlock.tagName || "").toLowerCase();
        const isInput = sTag === "input" || sTag === "textarea";
        const text2 = isInput ? semanticBlock.value?.trim() || semanticBlock.placeholder?.trim() || semanticBlock.getAttribute("aria-label")?.trim() || semanticBlock.getAttribute("title")?.trim() : semanticBlock.innerText?.trim() || semanticBlock.textContent?.trim() || semanticBlock.getAttribute("aria-label")?.trim() || semanticBlock.getAttribute("title")?.trim();
        if (text2 && text2.length >= 1) {
          return semanticBlock;
        }
      }
      if (target === document.body || target === document.documentElement) {
        return null;
      }
      if (target.querySelectorAll && target.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li, td, th, button, dt, dd").length > 0 && !target.matches?.('[role="alert"], [role="dialog"], dialog, div.alert, div.modal, div.banner-alert, div.popup-error')) {
        return null;
      }
      const tTag = (target.tagName || "").toLowerCase();
      const isTargetInput = tTag === "input" || tTag === "textarea";
      const text = isTargetInput ? target.value?.trim() || target.placeholder?.trim() || target.getAttribute("aria-label")?.trim() || target.getAttribute("title")?.trim() : target.innerText?.trim() || target.textContent?.trim() || target.getAttribute("aria-label")?.trim() || target.getAttribute("title")?.trim();
      if (text && text.length >= 1) {
        return target;
      }
      return null;
    }
    setupListeners() {
      this.onFirstInteractionHandler = () => {
        this.speechPlayer.prewarm();
        if (this.onFirstInteractionHandler) {
          window.removeEventListener("pointerdown", this.onFirstInteractionHandler);
          window.removeEventListener("keydown", this.onFirstInteractionHandler);
          this.onFirstInteractionHandler = null;
        }
      };
      window.addEventListener("pointerdown", this.onFirstInteractionHandler, { once: true });
      window.addEventListener("keydown", this.onFirstInteractionHandler, { once: true });
      this.onMouseUpHandler = () => {
        const selection = window.getSelection();
        const text = selection?.toString().trim();
        if (!text || text.length < 2) return;
        this.lastSelection = text;
        this.isOpen = true;
        this.activePanel = "translate";
        this.render();
        this.translateSelectedText(text);
      };
      document.addEventListener("mouseup", this.onMouseUpHandler);
      if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
        this.onRuntimeMessageHandler = (msg) => {
          if (msg.type === "CONTEXT_MENU_TRANSLATE" && msg.text) {
            this.isOpen = true;
            this.render();
            this.translateSelectedText(msg.text);
          } else if (msg.type === "POPUP_TRANSLATE_PAGE") {
            if (msg.targetLang) {
              this.currentTargetLang = msg.targetLang;
              this.currentSourceLang = this.detectSourceLanguage();
            }
            this.translateFullPage();
          } else if (msg.type === "POPUP_SET_TARGET_LANGUAGE") {
            this.currentTargetLang = msg.targetLang || "ewo-CM";
            this.render();
          } else if (msg.type === "POPUP_SET_SPEECH") {
            this.isTouchSpeakEnabled = msg.enabled === true;
            this.userPausedVoice = !this.isTouchSpeakEnabled;
            if (this.isTouchSpeakEnabled) this.speechPlayer.prewarm();
            if (!this.isVoiceEnabled()) this.clearHoverState();
            this.render();
          } else if (msg.type === "POPUP_DISABLE_SITE") {
            this.disableOnCurrentSite(false);
          } else if (msg.type === "POPUP_ENABLE_SITE") {
            this.enableOnCurrentSite();
          } else if (msg.type === "POPUP_STOP_SPEECH") {
            this.clearHoverState();
            const bar = this.shadow?.getElementById("audio-bar");
            if (bar) bar.style.display = "none";
          } else if (msg.type === "POPUP_TOGGLE_TOUCH_SPEAK" || msg.type === "POPUP_TOGGLE_HOVER_SPEAK") {
            this.toggleTouchSpeakMode();
          } else if (msg.type === "POPUP_RESTORE_PAGE") {
            this.restorePage();
          }
        };
        chrome.runtime.onMessage.addListener(this.onRuntimeMessageHandler);
      }
      window.addEventListener("message", (event) => {
        if (event?.data?.type === "LINGUABRIDGE_STOP_VOICE") {
          this.clearHoverState();
          this.stopSpeech();
          const bar = this.shadow?.getElementById("audio-bar");
          if (bar) bar.style.display = "none";
        } else if (event?.data?.type === "LINGUABRIDGE_MUTE_VOICE") {
          const muted = !!event.data.muted;
          this.userPausedVoice = muted;
          if (muted) {
            this.isTouchSpeakEnabled = false;
            this.clearHoverState();
            this.stopSpeech();
            const bar = this.shadow?.getElementById("audio-bar");
            if (bar) bar.style.display = "none";
          }
          this.render();
        }
      });
      window.addEventListener("linguabridge:stop-speech", () => {
        this.clearHoverState();
        this.stopSpeech();
        const bar = this.shadow?.getElementById("audio-bar");
        if (bar) bar.style.display = "none";
      });
      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          this.clearHoverState();
          this.stopSpeech();
          const bar = this.shadow?.getElementById("audio-bar");
          if (bar) bar.style.display = "none";
        }
      });
      this.onMouseOverHandler = (e) => {
        if (!this.isVoiceEnabled()) return;
        const target = e.target;
        if (!target || this.isExtensionNode(target)) return;
        const section = this.findMeaningfulSection(target);
        if (!section) return;
        if (this.currentHoveredEl === section) return;
        if (this.hoverDwellTimeout) {
          clearTimeout(this.hoverDwellTimeout);
          this.hoverDwellTimeout = null;
        }
        if (this.currentHoveredEl && this.currentHoveredEl !== section) {
          this.currentHoveredEl.style.outline = "";
          this.currentHoveredEl.style.cursor = "";
        }
        this.currentHoveredEl = section;
        section.style.outline = "2px solid #16a34a";
        section.style.outlineOffset = "2px";
        section.style.cursor = "pointer";
        if (this.lastSpokenEl === section) return;
        this.speechPlayer.prewarm();
        try {
          const secTag = (section.tagName || "").toLowerCase();
          const isSecInput = secTag === "input" || secTag === "textarea";
          const textToPrecache = isSecInput ? section.value?.trim() || section.placeholder?.trim() || section.getAttribute("aria-label")?.trim() : section.innerText?.trim() || section.textContent?.trim() || section.getAttribute("aria-label")?.trim();
          if (textToPrecache && textToPrecache.length >= 1) {
            const trans = this.translateLocal(textToPrecache);
            if (trans) {
              this.speechPlayer.precache(trans, this.currentTargetLang);
            }
          }
        } catch {
        }
        this.hoverDwellTimeout = setTimeout(() => {
          if (this.currentHoveredEl === section && this.lastSpokenEl !== section) {
            this.lastSpokenEl = section;
            if (this.currentSpokenEl && this.currentSpokenEl !== section) {
              this.stopSpeech();
            }
            const secTag = (section.tagName || "").toLowerCase();
            const isSecInput = secTag === "input" || secTag === "textarea";
            const text = isSecInput ? section.value?.trim() || section.placeholder?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim() : section.innerText?.trim() || section.textContent?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim();
            if (text && text.length >= 1) {
              this.speakTextSection(text, section);
            }
          }
        }, 200);
      };
      this.onMouseOutHandler = (e) => {
        if (!this.isVoiceEnabled()) return;
        const target = e.target;
        if (!target || this.isExtensionNode(target)) return;
        const section = this.findMeaningfulSection(target);
        if (!section) return;
        const related = e.relatedTarget;
        if (related && section.contains(related)) {
          return;
        }
        if (this.currentHoveredEl === section) {
          if (this.hoverDwellTimeout) {
            clearTimeout(this.hoverDwellTimeout);
            this.hoverDwellTimeout = null;
          }
          section.style.outline = "";
          section.style.cursor = "";
          this.currentHoveredEl = null;
        }
        if (this.lastSpokenEl === section) {
          this.lastSpokenEl = null;
        }
      };
      this.onClickElementHandler = (e) => {
        if (!this.isVoiceEnabled()) return;
        const target = e.target;
        if (!target || this.isExtensionNode(target)) return;
        const section = this.findMeaningfulSection(target);
        if (!section) return;
        if (this.hoverDwellTimeout) {
          clearTimeout(this.hoverDwellTimeout);
          this.hoverDwellTimeout = null;
        }
        const secTag = (section.tagName || "").toLowerCase();
        const isSecInput = secTag === "input" || secTag === "textarea";
        const text = isSecInput ? section.value?.trim() || section.placeholder?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim() : section.innerText?.trim() || section.textContent?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim();
        if (!text || text.length < 1) return;
        if (target.closest('input:not([type="button"]):not([type="submit"]):not([type="reset"]), select, textarea, [contenteditable="true"]')) return;
        this.speechPlayer.prewarm();
        this.stopSpeech();
        this.lastSpokenEl = section;
        this.speakTextSection(text, section);
      };
      this.onTouchEndHandler = (e) => {
        if (!this.isVoiceEnabled()) return;
        const touch = e.changedTouches[0];
        if (!touch) return;
        const target = document.elementFromPoint(touch.clientX, touch.clientY);
        if (!target || this.isExtensionNode(target)) return;
        const section = this.findMeaningfulSection(target);
        if (!section) return;
        const secTag = (section.tagName || "").toLowerCase();
        const isSecInput = secTag === "input" || secTag === "textarea";
        const text = isSecInput ? section.value?.trim() || section.placeholder?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim() : section.innerText?.trim() || section.textContent?.trim() || section.getAttribute("aria-label")?.trim() || section.getAttribute("title")?.trim();
        if (!text || text.length < 1) return;
        if (target.closest('input:not([type="button"]):not([type="submit"]):not([type="reset"]), select, textarea, [contenteditable="true"]')) return;
        this.speechPlayer.prewarm();
        this.stopSpeech();
        this.lastSpokenEl = section;
        this.speakTextSection(text, section);
      };
      document.addEventListener("mouseover", this.onMouseOverHandler, true);
      document.addEventListener("mouseout", this.onMouseOutHandler, true);
      document.addEventListener("pointerover", this.onMouseOverHandler, true);
      document.addEventListener("pointerout", this.onMouseOutHandler, true);
      document.addEventListener("click", this.onClickElementHandler, true);
      document.addEventListener("touchend", this.onTouchEndHandler, { capture: true, passive: false });
      this.onClickOutsideHandler = (e) => {
        if (!this.isOpen) return;
        if (this.dragSuppressClick) return;
        if (this.isEventInsideWidget(e)) return;
        const selection = typeof window.getSelection === "function" ? window.getSelection() : null;
        if (selection && selection.toString().trim().length >= 2) return;
        this.isOpen = false;
        this.render();
      };
      document.addEventListener("click", this.onClickOutsideHandler);
    }
    toggleTouchSpeakMode() {
      this.isTouchSpeakEnabled = !this.isTouchSpeakEnabled;
      this.userPausedVoice = !this.isTouchSpeakEnabled;
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        chrome.storage.local.set({ linguabridgeAudioEnabled: this.isTouchSpeakEnabled });
      }
      if (this.isTouchSpeakEnabled) this.speechPlayer.prewarm();
      if (!this.isVoiceEnabled()) {
        this.clearHoverState();
        this.speechPlayer.stop();
        this.activeBarState = { visible: false, text: "", phonetic: "" };
        const bar = this.shadow?.getElementById("audio-bar");
        if (bar) bar.style.display = "none";
      }
      this.render();
    }
    disableOnCurrentSite(persist = true) {
      this.isSiteDisabled = true;
      this.isOpen = false;
      this.stopSpeech();
      this.clearHoverState();
      if (this.isPageTranslated) {
        this.restorePage();
      }
      document.documentElement.removeAttribute("data-linguabridge-extension");
      if (this.container) {
        this.container.style.display = "none";
      }
      if (persist && typeof chrome !== "undefined" && chrome.storage?.local) {
        const host = this.getCurrentHost();
        if (host) {
          chrome.storage.local.get(["linguabridgeDisabledHosts"], (data) => {
            const list = Array.isArray(data?.linguabridgeDisabledHosts) ? data.linguabridgeDisabledHosts : [];
            if (!list.includes(host)) {
              chrome.storage.local.set({ linguabridgeDisabledHosts: [...list, host] });
            }
          });
        }
      }
    }
    enableOnCurrentSite() {
      this.isSiteDisabled = false;
      document.documentElement.setAttribute("data-linguabridge-extension", "active");
      if (this.container) {
        this.container.style.display = "";
      }
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        const host = this.getCurrentHost();
        if (host) {
          chrome.storage.local.get(["linguabridgeDisabledHosts"], (data) => {
            const list = Array.isArray(data?.linguabridgeDisabledHosts) ? data.linguabridgeDisabledHosts : [];
            chrome.storage.local.set({ linguabridgeDisabledHosts: list.filter((h) => h !== host) });
          });
        }
      }
      this.render();
    }
    speakTextSection(rawText, targetEl) {
      if (!rawText || !rawText.trim()) return;
      const cacheKey = `${this.currentTargetLang}:${rawText.trim()}`;
      let spokenTranslation;
      let phonetic;
      const cached = this.translationSpeechCache.get(cacheKey);
      if (cached) {
        spokenTranslation = cached.spokenTranslation;
        phonetic = cached.phonetic;
      } else {
        spokenTranslation = this.translateLocal(rawText);
        phonetic = this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(spokenTranslation) : "";
        this.translationSpeechCache.set(cacheKey, { spokenTranslation, phonetic });
      }
      if (this.currentSpokenEl && this.currentSpokenEl !== targetEl) {
        this.currentSpokenEl.style.outline = "";
        this.currentSpokenEl.style.cursor = "";
      }
      if (targetEl) {
        this.currentSpokenEl = targetEl;
        targetEl.style.outline = "2px solid #16a34a";
        targetEl.style.outlineOffset = "2px";
      }
      this.showAudioFloatingBar(spokenTranslation, phonetic);
      this.speechPlayer.speak(spokenTranslation, phonetic, () => {
        if (this.currentSpokenEl === targetEl) {
          if (targetEl && targetEl !== this.currentHoveredEl) {
            targetEl.style.outline = "";
            targetEl.style.cursor = "";
          }
          this.currentSpokenEl = null;
        }
      }, this.currentTargetLang);
    }
    showAudioFloatingBar(text, phonetic) {
      this.activeBarState = { visible: true, text, phonetic };
      const bar = this.shadow?.getElementById("audio-bar");
      if (!bar) return;
      bar.style.display = "flex";
      const textEl = this.shadow?.getElementById("audio-spoken-text");
      const phonEl = this.shadow?.getElementById("audio-phonetic");
      if (textEl) textEl.textContent = text;
      if (phonEl) {
        phonEl.style.color = "#86efac";
        phonEl.textContent = phonetic ? `[${phonetic}]` : "";
      }
    }
    async translateSelectedText(text) {
      const box = this.shadow?.getElementById("selection-preview");
      if (!box) return;
      box.style.display = "block";
      const localTrans = this.translateLocal(text);
      const localPhonetic = this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(localTrans) : "";
      const renderPreview = (translatedText, phonetic, warnings) => {
        box.innerHTML = `
        <div style="font-weight: 600; margin-bottom: 2px; color: #111827;">S\xE9lectionn\xE9 : "${text}"</div>
        <div style="color: #15803d; font-weight: 700; font-size: 14px;">"${translatedText}"</div>
        ${phonetic ? `<div style="color: #4b5563; font-size: 11px; margin-top: 2px; font-style: italic;">Prononciation : [${phonetic}]</div>` : ""}
        <div style="margin-top: 6px; display: flex; gap: 8px;">
          <button id="btn-speak-selection" style="background: #16a34a; color: #ffffff; border: 1px solid #15803d; padding: 6px 12px; border-radius: 4px; font-size: 12px; font-weight: 600; cursor: pointer;">
            \xC9couter en langue maternelle
          </button>
        </div>
        ${warnings.length > 0 ? `<div style="margin-top: 6px; padding: 6px 8px; background: #f9fafb; border: 1px solid #d1d5db; border-radius: 4px; color: #111827; font-size: 11px;">
                <strong>Garde financi\xE8re :</strong> ${warnings.join(", ")}
              </div>` : ""}
      `;
        this.shadow?.getElementById("btn-speak-selection")?.addEventListener("click", (e) => {
          const btn = e.currentTarget;
          const orig = btn ? btn.innerHTML : "";
          if (btn) btn.innerHTML = "Lecture vocale...";
          this.speechPlayer.speak(translatedText, phonetic, () => {
            if (btn) btn.innerHTML = orig;
          }, this.currentTargetLang);
        });
      };
      renderPreview(localTrans, localPhonetic, translateLocalText(text, this.currentSourceLang, this.currentTargetLang).warnings);
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage(
          {
            type: "TRANSLATE_TEXT",
            text,
            sourceLang: this.currentSourceLang,
            targetLang: this.currentTargetLang,
            domain: "financial"
          },
          (response) => {
            if (response?.success && response.result) {
              const phon = this.currentTargetLang.startsWith("ewo") ? response.result.phonetic || getEwondoPhonetic(response.result.translatedText) : "";
              renderPreview(response.result.translatedText, phon, response.result.warnings || []);
            }
          }
        );
      }
    }
    setupMutationObserver() {
      if (typeof MutationObserver === "undefined") return;
      if (typeof document === "undefined" || !document.body) return;
      this.mutationObserver = new MutationObserver((mutations) => {
        if (this.isTranslating) return;
        if (!this.isPageTranslated) return;
        let hasRelevantMutations = false;
        for (let i = 0; i < mutations.length; i++) {
          const m = mutations[i];
          if (m.type === "childList") {
            for (let j = 0; j < m.addedNodes.length; j++) {
              const node = m.addedNodes[j];
              if (this.isExtensionNode(node)) continue;
              this.pendingMutations.add(node);
              hasRelevantMutations = true;
            }
          } else if (m.type === "characterData") {
            const target = m.target;
            if (this.isExtensionNode(target)) continue;
            this.pendingMutations.add(target);
            hasRelevantMutations = true;
          }
        }
        if (hasRelevantMutations) {
          this.scheduleDebouncedMutation();
        }
      });
      this.mutationObserver.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true
      });
    }
    isEventInsideWidget(e) {
      if (e.__lbInside) return true;
      if (!this.container) return false;
      if (typeof e.composedPath === "function") {
        const path = e.composedPath();
        if (Array.isArray(path)) {
          if (path.includes(this.container) || this.shadow && path.includes(this.shadow)) {
            return true;
          }
        }
      }
      const target = e.target;
      if (!target) return false;
      if (target === this.container) return true;
      if (this.container.contains(target)) return true;
      if (this.shadow && this.shadow.contains(target)) return true;
      if (typeof target.getRootNode === "function" && target.getRootNode() === this.shadow) {
        return true;
      }
      if (this.isExtensionNode(target)) return true;
      return false;
    }
    isExtensionNode(node) {
      if (!node) return false;
      if (node.nodeType === 1) {
        const el = node;
        if (el.id === "linguabridge-extension-root" || el.closest?.("#linguabridge-extension-root")) {
          return true;
        }
      } else if (node.parentElement) {
        if (node.parentElement.id === "linguabridge-extension-root" || node.parentElement.closest?.("#linguabridge-extension-root")) {
          return true;
        }
      }
      return false;
    }
    scheduleDebouncedMutation() {
      if (this.mutationDebounceTimeout) {
        clearTimeout(this.mutationDebounceTimeout);
      }
      this.mutationDebounceTimeout = setTimeout(() => {
        this.processPendingMutations();
      }, 50);
    }
    processPendingMutations() {
      if (!this.isPageTranslated || this.pendingMutations.size === 0) {
        this.pendingMutations.clear();
        return;
      }
      this.isTranslating = true;
      try {
        for (const node of this.pendingMutations) {
          this.translateNodeSubtree(node);
        }
        if (this.mutationObserver) {
          this.mutationObserver.takeRecords();
        }
      } finally {
        this.pendingMutations.clear();
        this.isTranslating = false;
      }
    }
    translateElementAttributes(el) {
      if (!el || typeof el.getAttribute !== "function" || this.isExtensionNode(el)) return;
      const tag = (el.tagName || "").toLowerCase();
      if (tag === "input" || tag === "textarea") {
        const inputEl = el;
        const ph = inputEl.placeholder;
        if (ph && ph.trim()) {
          const orig = this.originalAttrMap.get(el);
          if (!orig || orig.placeholder === void 0) {
            this.originalAttrMap.set(el, { ...orig, placeholder: ph });
          }
          const sourcePh = (this.originalAttrMap.get(el)?.placeholder ?? ph).trim();
          const translatedPh = this.translateLocal(sourcePh);
          if (translatedPh && translatedPh !== sourcePh) {
            inputEl.placeholder = translatedPh;
            const cacheKey = `${this.currentTargetLang}:${translatedPh.trim()}`;
            this.translationSpeechCache.set(cacheKey, {
              spokenTranslation: translatedPh,
              phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translatedPh) : ""
            });
          } else {
            inputEl.placeholder = this.originalAttrMap.get(el)?.placeholder ?? ph;
          }
        }
      }
      if (tag === "input") {
        const inputEl = el;
        const type = (inputEl.type || "").toLowerCase();
        if (["button", "submit", "reset"].includes(type) && inputEl.value && inputEl.value.trim()) {
          const orig = this.originalAttrMap.get(el);
          if (!orig || orig.value === void 0) {
            this.originalAttrMap.set(el, { ...orig, value: inputEl.value });
          }
          const sourceVal = (this.originalAttrMap.get(el)?.value ?? inputEl.value).trim();
          const translatedVal = this.translateLocal(sourceVal);
          if (translatedVal && translatedVal !== sourceVal) {
            inputEl.value = translatedVal;
            const cacheKey = `${this.currentTargetLang}:${translatedVal.trim()}`;
            this.translationSpeechCache.set(cacheKey, {
              spokenTranslation: translatedVal,
              phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translatedVal) : ""
            });
          } else {
            inputEl.value = this.originalAttrMap.get(el)?.value ?? inputEl.value;
          }
        }
      }
      const title = el.getAttribute("title");
      if (title && title.trim()) {
        const orig = this.originalAttrMap.get(el);
        if (!orig || orig.title === void 0) {
          this.originalAttrMap.set(el, { ...orig, title });
        }
        const sourceTitle = (this.originalAttrMap.get(el)?.title ?? title).trim();
        const translatedTitle = this.translateLocal(sourceTitle);
        if (translatedTitle && translatedTitle !== sourceTitle) {
          el.setAttribute("title", translatedTitle);
          const cacheKey = `${this.currentTargetLang}:${translatedTitle.trim()}`;
          this.translationSpeechCache.set(cacheKey, {
            spokenTranslation: translatedTitle,
            phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translatedTitle) : ""
          });
        } else {
          const origTitle = this.originalAttrMap.get(el)?.title;
          if (origTitle !== void 0) el.setAttribute("title", origTitle);
        }
      }
      const ariaLabel = el.getAttribute("aria-label");
      if (ariaLabel && ariaLabel.trim()) {
        const orig = this.originalAttrMap.get(el);
        if (!orig || orig.ariaLabel === void 0) {
          this.originalAttrMap.set(el, { ...orig, ariaLabel });
        }
        const sourceAria = (this.originalAttrMap.get(el)?.ariaLabel ?? ariaLabel).trim();
        const translatedAria = this.translateLocal(sourceAria);
        if (translatedAria && translatedAria !== sourceAria) {
          el.setAttribute("aria-label", translatedAria);
          const cacheKey = `${this.currentTargetLang}:${translatedAria.trim()}`;
          this.translationSpeechCache.set(cacheKey, {
            spokenTranslation: translatedAria,
            phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translatedAria) : ""
          });
        } else {
          const origAria = this.originalAttrMap.get(el)?.ariaLabel;
          if (origAria !== void 0) el.setAttribute("aria-label", origAria);
        }
      }
      if (tag === "img") {
        const alt = el.getAttribute("alt");
        if (alt && alt.trim()) {
          const orig = this.originalAttrMap.get(el);
          if (!orig || orig.alt === void 0) {
            this.originalAttrMap.set(el, { ...orig, alt });
          }
          const sourceAlt = (this.originalAttrMap.get(el)?.alt ?? alt).trim();
          const translatedAlt = this.translateLocal(sourceAlt);
          if (translatedAlt && translatedAlt !== sourceAlt) {
            el.setAttribute("alt", translatedAlt);
            const cacheKey = `${this.currentTargetLang}:${translatedAlt.trim()}`;
            this.translationSpeechCache.set(cacheKey, {
              spokenTranslation: translatedAlt,
              phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translatedAlt) : ""
            });
          } else {
            const origAlt = this.originalAttrMap.get(el)?.alt;
            if (origAlt !== void 0) el.setAttribute("alt", origAlt);
          }
        }
      }
    }
    buildMaskedSentence(node, inlineElements) {
      let res = "";
      for (let i = 0; i < node.childNodes.length; i++) {
        const child = node.childNodes[i];
        if (child.nodeType === 3) {
          res += child.textContent || "";
        } else if (child.nodeType === 1) {
          const childEl = child;
          const tag = (childEl.tagName || "").toUpperCase();
          if (_ExtensionAssistant.INLINE_TAGS.has(tag)) {
            const idx = inlineElements.length;
            inlineElements.push(childEl);
            const inner = this.buildMaskedSentence(childEl, inlineElements);
            res += `<t${idx}>${inner}</t${idx}>`;
          } else if (tag === "BR") {
            res += "\n";
          } else {
            res += childEl.textContent || "";
          }
        }
      }
      return res;
    }
    reassembleTranslatedSentence(translated, inlineElements) {
      const fragment = document.createDocumentFragment();
      const stack = [fragment];
      const tokenRegex = /(<t(\d+)>)|(<\/t(\d+)>)|(⟦T(\d+):)|(⟧)/g;
      let lastIndex = 0;
      let match;
      while ((match = tokenRegex.exec(translated)) !== null) {
        const textBefore = translated.slice(lastIndex, match.index);
        if (textBefore) {
          stack[stack.length - 1].appendChild(document.createTextNode(textBefore));
        }
        if (match[1]) {
          const idx = parseInt(match[2], 10);
          const top = stack[stack.length - 1];
          if (idx >= 0 && idx < inlineElements.length) {
            const el = inlineElements[idx];
            while (el.firstChild) el.removeChild(el.firstChild);
            top.appendChild(el);
            stack.push(el);
          } else {
            const span = document.createElement("span");
            top.appendChild(span);
            stack.push(span);
          }
        } else if (match[3]) {
          if (stack.length > 1) stack.pop();
        } else if (match[5]) {
          const idx = parseInt(match[6], 10);
          const top = stack[stack.length - 1];
          if (idx >= 0 && idx < inlineElements.length) {
            const el = inlineElements[idx];
            while (el.firstChild) el.removeChild(el.firstChild);
            top.appendChild(el);
            stack.push(el);
          } else {
            const span = document.createElement("span");
            top.appendChild(span);
            stack.push(span);
          }
        } else if (match[7]) {
          if (stack.length > 1) stack.pop();
        }
        lastIndex = tokenRegex.lastIndex;
      }
      const remainingText = translated.slice(lastIndex);
      if (remainingText) {
        stack[stack.length - 1].appendChild(document.createTextNode(remainingText));
      }
      return fragment;
    }
    saveElementChildrenRecursively(el) {
      if (!this.originalChildNodesMap.has(el)) {
        this.originalChildNodesMap.set(el, Array.from(el.childNodes));
        for (let i = 0; i < el.childNodes.length; i++) {
          const child = el.childNodes[i];
          if (child.nodeType === 3) {
            if (!this.originalTextMap.has(child)) {
              this.originalTextMap.set(child, child.textContent || "");
            }
          } else if (child.nodeType === 1) {
            this.saveElementChildrenRecursively(child);
          }
        }
      }
    }
    restoreCompositeContainers() {
      const entries = Array.from(this.originalChildNodesMap.entries()).reverse();
      for (const [el, origChildren] of entries) {
        while (el.firstChild) el.removeChild(el.firstChild);
        for (const child of origChildren) {
          if (child.nodeType === 3 && this.originalTextMap.has(child)) {
            child.textContent = this.originalTextMap.get(child);
          }
          el.appendChild(child);
        }
      }
      this.originalChildNodesMap.clear();
    }
    restoreSingleCompositeContainer(container) {
      const entries = Array.from(this.originalChildNodesMap.entries()).reverse();
      for (const [el, origChildren] of entries) {
        if (el === container || container.contains(el)) {
          while (el.firstChild) el.removeChild(el.firstChild);
          for (const child of origChildren) {
            if (child.nodeType === 3 && this.originalTextMap.has(child)) {
              child.textContent = this.originalTextMap.get(child);
            }
            el.appendChild(child);
          }
          this.originalChildNodesMap.delete(el);
        }
      }
    }
    translateCompositeContainer(container) {
      if (this.originalChildNodesMap.has(container)) {
        this.restoreSingleCompositeContainer(container);
      }
      this.saveElementChildrenRecursively(container);
      const inlineElements = [];
      const maskedText = this.buildMaskedSentence(container, inlineElements);
      const wsMatch = maskedText.match(/^(\s*)([\s\S]*?)(\s*)$/);
      const leading = wsMatch ? wsMatch[1] : "";
      const trimmed = wsMatch ? wsMatch[2] : "";
      const trailing = wsMatch ? wsMatch[3] : "";
      if (!trimmed) return false;
      const translated = this.translateLocal(trimmed);
      if (!translated || translated === trimmed) return false;
      const fullTranslated = leading + translated + trailing;
      const newFragment = this.reassembleTranslatedSentence(fullTranslated, inlineElements);
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
      container.appendChild(newFragment);
      const fullText = container.textContent || "";
      if (fullText) {
        const cacheKey = `${this.currentTargetLang}:${fullText.trim()}`;
        if (!this.translationSpeechCache.has(cacheKey)) {
          this.translationSpeechCache.set(cacheKey, {
            spokenTranslation: fullText,
            phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(fullText) : ""
          });
        }
      }
      return true;
    }
    translateNodeSubtree(rootNode) {
      if (!rootNode || !rootNode.isConnected) return;
      if (this.isExtensionNode(rootNode)) return;
      if (rootNode.nodeType === 3) {
        this.translateSingleTextNode(rootNode);
        return;
      }
      if (rootNode.nodeType === 1 || rootNode.nodeType === 11) {
        const el = rootNode;
        const tag = el.tagName?.toLowerCase();
        if (["script", "style", "code", "pre", "noscript"].includes(tag)) return;
        if (rootNode.nodeType === 1) {
          this.translateElementAttributes(el);
        }
        if (el.querySelectorAll) {
          const attrElements = el.querySelectorAll("input, textarea, [title], [aria-label], img[alt]");
          for (let i = 0; i < attrElements.length; i++) {
            this.translateElementAttributes(attrElements[i]);
          }
        }
        if (el.shadowRoot && !this.isExtensionNode(el.shadowRoot)) {
          this.translateNodeSubtree(el.shadowRoot);
        }
        if (el.querySelectorAll) {
          const customElements = el.querySelectorAll("*");
          for (let i = 0; i < customElements.length; i++) {
            const shadow = customElements[i].shadowRoot;
            if (shadow && !this.isExtensionNode(shadow)) {
              this.translateNodeSubtree(shadow);
            }
          }
        }
        const translatedContainers = /* @__PURE__ */ new Set();
        if (el.querySelectorAll) {
          const candidateContainers = el.querySelectorAll(_ExtensionAssistant.CONTAINER_SELECTOR);
          for (let i = 0; i < candidateContainers.length; i++) {
            const c = candidateContainers[i];
            if (this.isExtensionNode(c)) continue;
            if (c.querySelector(_ExtensionAssistant.CONTAINER_SELECTOR)) continue;
            const hasInline = Array.from(c.children).some(
              (child) => _ExtensionAssistant.INLINE_TAGS.has((child.tagName || "").toUpperCase())
            );
            if (hasInline) {
              const didTranslate = this.translateCompositeContainer(c);
              if (didTranslate) {
                translatedContainers.add(c);
              }
            }
          }
        }
        const elTag = (el.tagName || "").toUpperCase();
        const isContainerBlock = _ExtensionAssistant.CONTAINER_BLOCK_TAGS.has(elTag) || typeof el.matches === "function" && el.matches(_ExtensionAssistant.CONTAINER_SELECTOR);
        if (isContainerBlock && !el.querySelector?.(_ExtensionAssistant.CONTAINER_SELECTOR)) {
          const hasInline = Array.from(el.children).some(
            (child) => _ExtensionAssistant.INLINE_TAGS.has((child.tagName || "").toUpperCase())
          );
          if (hasInline && !translatedContainers.has(el)) {
            const didTranslate = this.translateCompositeContainer(el);
            if (didTranslate) {
              translatedContainers.add(el);
            }
          }
        }
        if (el.querySelectorAll) {
          const candidateLinks = el.querySelectorAll("a");
          for (let i = 0; i < candidateLinks.length; i++) {
            const a = candidateLinks[i];
            if (this.isExtensionNode(a)) continue;
            if (a.closest(_ExtensionAssistant.CONTAINER_SELECTOR)) continue;
            const hasInline = Array.from(a.children).some(
              (child) => _ExtensionAssistant.INLINE_TAGS.has((child.tagName || "").toUpperCase())
            );
            if (hasInline && !translatedContainers.has(a)) {
              const didTranslate = this.translateCompositeContainer(a);
              if (didTranslate) {
                translatedContainers.add(a);
              }
            }
          }
        }
        const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
          acceptNode: (node) => {
            if (!node.textContent || !node.textContent.trim()) return NodeFilter.FILTER_REJECT;
            const parent = node.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            const parentTag = parent.tagName?.toLowerCase();
            if (["script", "style", "code", "pre", "noscript"].includes(parentTag)) {
              return NodeFilter.FILTER_REJECT;
            }
            if (this.isExtensionNode(parent)) return NodeFilter.FILTER_REJECT;
            for (const tc of translatedContainers) {
              if (tc.contains(node)) return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        });
        let curr = walker.nextNode();
        while (curr) {
          this.translateSingleTextNode(curr);
          curr = walker.nextNode();
        }
      }
    }
    translateSingleTextNode(node) {
      if (!this.originalTextMap.has(node)) {
        this.originalTextMap.set(node, node.textContent || "");
      }
      const sourceText = this.originalTextMap.get(node) || node.textContent || "";
      const trimmed = sourceText.trim();
      if (trimmed) {
        const match = sourceText.match(/^(\s*)([\s\S]*?)(\s*)$/);
        const leading = match ? match[1] : "";
        const trailing = match ? match[3] : "";
        const translated = this.translateLocal(trimmed);
        if (translated && translated !== trimmed) {
          node.textContent = leading + translated + trailing;
          const cacheKey = `${this.currentTargetLang}:${translated.trim()}`;
          if (!this.translationSpeechCache.has(cacheKey)) {
            this.translationSpeechCache.set(cacheKey, {
              spokenTranslation: translated,
              phonetic: this.currentTargetLang.startsWith("ewo") ? getEwondoPhonetic(translated) : ""
            });
          }
        } else {
          node.textContent = sourceText;
        }
      }
    }
    translateFullPage() {
      this.isTranslating = true;
      try {
        this.speechPlayer.prewarm();
        this.translateNodeSubtree(document.body);
        this.isPageTranslated = true;
        this.render();
        this.precacheVisibleSections();
        if (this.mutationObserver) {
          this.mutationObserver.takeRecords();
        }
      } finally {
        this.isTranslating = false;
      }
    }
    precacheVisibleSections() {
      try {
        if (typeof window === "undefined" || !document.body) return;
        const elements = Array.from(
          document.querySelectorAll('h1, h2, h3, button, [role="button"]')
        );
        const candidates = [];
        for (const el of elements) {
          if (this.isExtensionNode(el)) continue;
          const text = (el.innerText || el.textContent || "").trim();
          if (text.length >= 2 && text.length <= 60 && !candidates.includes(text)) {
            candidates.push(text);
            if (candidates.length >= 3) break;
          }
        }
        candidates.forEach((t, index) => {
          const translated = this.translateLocal(t);
          const speechText = (translated || t).trim();
          if (index === 0) {
            this.speechPlayer.precache(speechText, this.currentTargetLang);
          } else {
            setTimeout(() => {
              this.speechPlayer.precache(speechText, this.currentTargetLang);
            }, index * 300);
          }
        });
      } catch {
      }
    }
    restorePage() {
      this.isTranslating = true;
      try {
        this.restoreCompositeContainers();
        for (const [node, original] of this.originalTextMap.entries()) {
          if (node.nodeType === 3 && node.isConnected) {
            node.textContent = original;
          }
        }
        for (const [el, orig] of this.originalAttrMap.entries()) {
          if (el.isConnected) {
            const inputEl = el;
            const tag = (el.tagName || "").toLowerCase();
            if (orig.placeholder !== void 0 && (tag === "input" || tag === "textarea")) {
              inputEl.placeholder = orig.placeholder;
            }
            if (orig.value !== void 0 && tag === "input") {
              inputEl.value = orig.value;
            }
            if (orig.title !== void 0) {
              el.setAttribute("title", orig.title);
            }
            if (orig.ariaLabel !== void 0) {
              el.setAttribute("aria-label", orig.ariaLabel);
            }
            if (orig.alt !== void 0 && tag === "img") {
              el.setAttribute("alt", orig.alt);
            }
          }
        }
        this.isPageTranslated = false;
        this.clearHoverState();
        this.speechPlayer.stop();
        this.render();
        if (this.mutationObserver) {
          this.mutationObserver.takeRecords();
        }
      } finally {
        this.isTranslating = false;
      }
    }
    render() {
      if (!this.shadow) return;
      const vw = typeof window !== "undefined" ? window.innerWidth || 1024 : 1024;
      const vh = typeof window !== "undefined" ? window.innerHeight || 768 : 768;
      const openDownward = this.customPos ? this.customPos.top < vh / 2 : false;
      const openRightward = this.customPos ? this.customPos.left < vw / 2 : false;
      const voiceActive = this.isVoiceEnabled();
      const launcherIconSvg = voiceActive ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#6be18c" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>' : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6" stroke="#6be18c"/></svg>';
      this.shadow.innerHTML = `
      <style>
        .assistant-btn {
          position: relative;
          width: 52px;
          height: 52px;
          border-radius: 14px;
          background: #111111;
          color: #ffffff;
          border: 1.5px solid ${voiceActive ? "#22c55e" : "#15803d"};
          box-shadow: 0 6px 18px rgba(0, 0, 0, 0.22);
          cursor: grab;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
          user-select: none;
          touch-action: none;
          transition: background 0.15s ease, transform 0.15s ease;
        }
        .assistant-btn:active {
          cursor: grabbing;
        }
        .assistant-btn:hover {
          transform: scale(1.04);
          background: #1f2937;
        }
        .assistant-btn.active-speak {
          background: #0f291a;
          border: 2px solid #22c55e;
          box-shadow: 0 4px 16px rgba(21, 128, 61, 0.35);
        }
        .voice-dot {
          position: absolute;
          top: 5px;
          right: 5px;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: ${voiceActive ? "#22c55e" : "transparent"};
          box-shadow: ${voiceActive ? "0 0 6px #22c55e" : "none"};
        }
        .drag-grip {
          display: flex;
          align-items: center;
          justify-content: space-between;
          cursor: grab;
          user-select: none;
          touch-action: none;
          padding: 4px 6px;
          margin: -6px -4px 8px;
          border-radius: 6px;
          color: #6b7280;
          font-size: 11px;
          font-weight: 600;
        }
        .drag-grip:hover {
          background: #f3f4f6;
          color: #111827;
        }
        .drag-grip:active {
          cursor: grabbing;
        }
        .btn-disable-site {
          width: 100%;
          margin-top: 10px;
          padding: 7px 10px;
          border-radius: 6px;
          border: 1px dashed #d1d5db;
          background: transparent;
          color: #4b5563;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }
        .btn-disable-site:hover {
          background: #fef2f2;
          border-color: #fca5a5;
          color: #b91c1c;
        }
        .card {
          display: ${this.isOpen ? "block" : "none"};
          position: absolute;
          ${openDownward ? "top: 64px; bottom: auto;" : "bottom: 64px; top: auto;"}
          ${openRightward ? "left: 0; right: auto;" : "right: 0; left: auto;"}
          width: min(360px, calc(100vw - 48px));
          background: #ffffff;
          border-radius: 8px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
          border: 1px solid #e5e7eb;
          padding: 16px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          font-size: 13px;
          color: #111827;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-weight: 700;
          font-size: 14px;
          border-bottom: 1px solid #f3f4f6;
          padding-bottom: 8px;
          margin-bottom: 10px;
        }
        .badge-nat {
          font-size: 11px;
          font-weight: 600;
          background: #f0fdf4;
          color: #15803d;
          border: 1px solid #bbf7d0;
          padding: 2px 6px;
          border-radius: 4px;
        }
        .btn-action {
          width: 100%;
          padding: 9px 12px;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          border: 1px solid #d1d5db;
          background: #ffffff;
          color: #111827;
          margin-top: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          box-sizing: border-box;
          transition: background 0.15s ease;
        }
        .btn-action:hover {
          background: #f9fafb;
        }
        .btn-action.primary {
          background: #111;
          color: #ffffff;
          border-color: #111;
        }
        .btn-action.primary:hover {
          background: #292929;
        }
        .btn-action.speak-toggle {
          background: ${voiceActive ? "#15803d" : "#f9fafb"};
          color: ${voiceActive ? "#ffffff" : "#111827"};
          border-color: ${voiceActive ? "#15803d" : "#d1d5db"};
        }
        .speak-hint {
          display: ${voiceActive ? "block" : "none"};
          margin-top: 8px;
          padding: 8px;
          background: #f0fdf4;
          border: 1px solid #bbf7d0;
          border-radius: 6px;
          color: #15803d;
          font-size: 11px;
          line-height: 1.4;
        }
        .lb-quick{border:1px solid #e0e3e7;border-radius:8px;background:#f7f8f9;padding:7px 9px;font-size:11px;cursor:pointer}
        .preview-box {
          display: none;
          margin-top: 10px;
          padding: 10px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          border-radius: 6px;
          font-size: 12px;
        }
        /* Floating Audio Player Subtitle Bar */
        .audio-bar {
          display: none;
          position: fixed;
          bottom: 24px;
          left: 50%;
          transform: translateX(-50%);
          background: #111827;
          color: #ffffff;
          border-radius: 8px;
          padding: 10px 16px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.25);
          align-items: center;
          gap: 12px;
          z-index: 2147483647;
          max-width: 90vw;
          border: 1px solid #374151;
        }
        .audio-btn {
          background: #111;
          color: #ffffff;
          border: none;
          padding: 5px 10px;
          border-radius: 4px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
        }
        .audio-btn:hover {
          background: #292929;
        }
        .audio-btn.stop-btn {
          background: #374151;
          color: #ffffff;
        }
        .audio-btn.stop-btn:hover {
          background: #4b5563;
        }
      </style>

      <div class="card">
        <div class="drag-grip" id="lb-drag-handle" title="Glisser pour d\xE9placer LinguaBridge">
          <span style="display:inline-flex;align-items:center;gap:5px;">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/></svg>
            D\xE9placer l'assistant
          </span>
          <span style="font-size:10px;color:#9ca3af;">glisser</span>
        </div>
        <div style="display:flex;gap:5px;background:#f3f4f6;padding:4px;border-radius:10px;margin-bottom:14px;">
          <button id="lb-tab-translate" style="flex:1;border:0;padding:10px;border-radius:8px;background:${this.activePanel === "translate" ? "#fff" : "transparent"};cursor:pointer;font-weight:650;">Traduction</button>
          <button id="lb-tab-assistant" style="flex:1;border:0;padding:10px;border-radius:8px;background:${this.activePanel === "assistant" ? "#fff" : "transparent"};cursor:pointer;font-weight:650;">Assistant</button>
        </div>
        <div style="display:${this.activePanel === "translate" ? "block" : "none"};">
        <div class="header">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span>LinguaBridge</span>
            <span class="badge-nat">${this.getLangBadgeName(this.currentTargetLang)}</span>
          </div>
          <button id="close-card" style="background:none;border:none;cursor:pointer;color:#6b7280;font-size:16px;">\u2715</button>
        </div>

        <div style="margin-bottom: 8px;">
          <label style="font-weight: 600; font-size: 12px; color: #4b5563;">Langue maternelle :</label>
          <select id="target-lang" style="width: 100%; padding: 7px; border-radius: 6px; border: 1px solid #d1d5db; margin-top: 4px; font-size: 13px; font-weight: 600; background: #ffffff;">
            <option value="ewo-CM" ${this.currentTargetLang === "ewo-CM" ? "selected" : ""}>Ewondo (Centre, Sud, Est)</option>
            <option value="fuv-CM" ${this.currentTargetLang === "fuv-CM" ? "selected" : ""}>Fulfulde / Peul (Grand Nord, CEMAC)</option>
            <option value="hau-CM" ${this.currentTargetLang === "hau-CM" ? "selected" : ""}>Haoussa (Grand Nord, Corridors)</option>
            <option value="knc-CM" ${this.currentTargetLang === "knc-CM" ? "selected" : ""}>Kanuri (Extr\xEAme-Nord, Lac Tchad)</option>
            <option value="pcm-CM" ${this.currentTargetLang === "pcm-CM" ? "selected" : ""}>Pidgin English (NO, SO, March\xE9s)</option>
          </select>
          <p style="font-size:11px;color:#667085;margin-top:9px;">Fran\xE7ais et anglais d\xE9tect\xE9s automatiquement. V\xE9rifiez les montants avant une transaction.</p>
        </div>

        <div style="margin-top: 10px;">
          ${this.isPageTranslated ? `<button class="btn-action" id="btn-restore"><span></span><span>Restaurer le texte d'origine</span></button>` : `<button class="btn-action primary" id="btn-translate-page"><span></span><span>Traduire toute la page</span></button>`}
        </div>

        <button class="btn-action speak-toggle" id="btn-toggle-speak">
          <span></span>
          <span>${this.isTouchSpeakEnabled ? "D\xE9sactiver la lecture au toucher" : "Activer la lecture sur demande"}</span>
        </button>

        <div class="speak-hint">
          <strong>Mode vocal actif :</strong> Survolez, touchez ou cliquez sur n'importe quelle section pour l'\xE9couter en langue maternelle.
        </div>

        <div id="selection-preview" class="preview-box"></div>
        <button type="button" class="btn-disable-site" id="btn-disable-site" title="Masquer et d\xE9sactiver LinguaBridge sur ce site">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>
          D\xE9sactiver sur ce site
        </button>
        </div>
        <div style="display:${this.activePanel === "assistant" ? "block" : "none"};">
          <div class="header"><span>Assistant financier</span><button id="lb-close-chat" style="border:0;background:transparent;cursor:pointer;">Fermer</button></div>
          <p style="font-size:12px;color:#667085;">Questions bancaires courantes. R\xE9ponses locales limit\xE9es.</p>
          <div id="lb-chat-log" style="height:200px;overflow:auto;display:flex;flex-direction:column;gap:9px;margin:12px 0;"></div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;"><button class="lb-quick" data-question="Comment envoyer de l\u2019argent ?">Transfert</button><button class="lb-quick" data-question="Comment consulter mon solde ?">Solde</button><button class="lb-quick" data-question="Quels sont les frais de retrait ?">Frais</button><button class="lb-quick" data-question="Comment s\xE9curiser mon compte ?">S\xE9curit\xE9</button></div>
          <form id="lb-chat-form" style="display:flex;gap:6px;"><input id="lb-chat-input" maxlength="500" placeholder="Votre question..." style="flex:1;min-width:0;border:1px solid #d0d5dd;border-radius:8px;padding:9px;"><button type="submit" style="background:#111;color:#fff;border:0;border-radius:8px;padding:9px;">Envoyer</button></form>
          <p style="font-size:11px;color:#667085;">Ne communiquez jamais votre PIN ou mot de passe.</p>
        </div>
      </div>

      <button class="assistant-btn ${voiceActive ? "active-speak" : ""}" id="btn-toggle" title="LinguaBridge - Glisser pour d\xE9placer, clic gauche pour ouvrir, clic droit pour d\xE9sactiver sur ce site">
        ${launcherIconSvg}
        <span class="voice-dot"></span>
      </button>

      <!-- Bottom floating speech indicator bar -->
      <div id="audio-bar" class="audio-bar" style="${this.activeBarState.visible ? "display:flex;" : ""}">
        <span style="font-size: 16px;"></span>
        <div style="max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
          <div id="audio-spoken-text" style="font-weight: 700; font-size: 13px; color: #ffffff;">${this.activeBarState.visible ? this.activeBarState.text : ""}</div>
          <div id="audio-phonetic" style="font-size: 11px; color: #86efac; font-style: italic;">${this.activeBarState.visible && this.activeBarState.phonetic ? `[${this.activeBarState.phonetic}]` : ""}</div>
        </div>
        <button class="audio-btn" id="audio-replay">Rejouer</button>
        <button class="audio-btn stop-btn" id="audio-stop">Arr\xEAter</button>
        <button id="audio-close" style="background:none;border:none;color:#9ca3af;cursor:pointer;font-size:14px;padding:2px 6px;">\u2715</button>
      </div>
    `;
      const btnToggle = this.shadow.getElementById("btn-toggle");
      const dragHandle = this.shadow.getElementById("lb-drag-handle");
      const startDrag = (e) => {
        if (e.button !== 0 || !this.container) return;
        const startX = e.clientX;
        const startY = e.clientY;
        const rect = this.container.getBoundingClientRect();
        const origLeft = this.customPos ? this.customPos.left : rect.left || (typeof window !== "undefined" ? window.innerWidth - 76 : 900);
        const origTop = this.customPos ? this.customPos.top : rect.top || (typeof window !== "undefined" ? window.innerHeight - 76 : 600);
        let moved = false;
        if (this.onDragMoveHandler) window.removeEventListener("mousemove", this.onDragMoveHandler);
        if (this.onDragEndHandler) window.removeEventListener("mouseup", this.onDragEndHandler);
        this.onDragMoveHandler = (moveEvt) => {
          const dx = moveEvt.clientX - startX;
          const dy = moveEvt.clientY - startY;
          if (!moved && Math.hypot(dx, dy) < 5) return;
          moved = true;
          this.applyContainerPosition(origLeft + dx, origTop + dy);
        };
        this.onDragEndHandler = (endEvt) => {
          if (this.onDragMoveHandler) {
            window.removeEventListener("mousemove", this.onDragMoveHandler);
            this.onDragMoveHandler = null;
          }
          if (this.onDragEndHandler) {
            window.removeEventListener("mouseup", this.onDragEndHandler);
            this.onDragEndHandler = null;
          }
          if (moved) {
            if (endEvt && typeof endEvt.clientX === "number") {
              const dx = endEvt.clientX - startX;
              const dy = endEvt.clientY - startY;
              this.applyContainerPosition(origLeft + dx, origTop + dy);
            }
            this.dragSuppressClick = true;
            setTimeout(() => {
              this.dragSuppressClick = false;
            }, 60);
            if (this.customPos && typeof chrome !== "undefined" && chrome.storage?.local) {
              chrome.storage.local.set({ linguabridgeWidgetPos: this.customPos });
            }
            this.render();
          }
        };
        window.addEventListener("mousemove", this.onDragMoveHandler);
        window.addEventListener("mouseup", this.onDragEndHandler);
      };
      btnToggle?.addEventListener("mousedown", startDrag);
      dragHandle?.addEventListener("mousedown", startDrag);
      btnToggle?.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        if (this.isSiteDisabled) {
          this.enableOnCurrentSite();
        } else {
          this.disableOnCurrentSite(true);
        }
      });
      btnToggle?.addEventListener("click", (e) => {
        e.__lbInside = true;
        e.stopPropagation();
        if (this.dragSuppressClick) {
          this.dragSuppressClick = false;
          return;
        }
        this.speechPlayer.prewarm();
        this.isOpen = !this.isOpen;
        this.render();
      });
      this.shadow.getElementById("close-card")?.addEventListener("click", () => {
        this.isOpen = false;
        this.render();
      });
      this.shadow.getElementById("btn-translate-page")?.addEventListener("click", () => {
        this.speechPlayer.prewarm();
        this.translateFullPage();
      });
      this.shadow.getElementById("btn-restore")?.addEventListener("click", () => {
        this.restorePage();
      });
      this.shadow.getElementById("btn-toggle-speak")?.addEventListener("click", () => {
        this.speechPlayer.prewarm();
        this.toggleTouchSpeakMode();
      });
      this.shadow.getElementById("btn-disable-site")?.addEventListener("click", () => {
        this.disableOnCurrentSite(true);
      });
      this.shadow.getElementById("target-lang")?.addEventListener("change", (e) => {
        this.currentTargetLang = e.target.value;
        this.currentSourceLang = this.detectSourceLanguage();
        chrome.storage?.local?.set({ linguabridgeTargetLang: this.currentTargetLang });
        this.translationSpeechCache.clear();
        this.stopSpeech();
        if (this.isPageTranslated) {
          this.translateFullPage();
        } else {
          this.render();
        }
      });
      this.shadow.getElementById("lb-tab-translate")?.addEventListener("click", () => {
        this.activePanel = "translate";
        this.render();
      });
      this.shadow.getElementById("lb-tab-assistant")?.addEventListener("click", () => {
        this.activePanel = "assistant";
        this.render();
      });
      this.shadow.getElementById("lb-close-chat")?.addEventListener("click", () => {
        this.isOpen = false;
        this.render();
      });
      const chatLog = this.shadow.getElementById("lb-chat-log");
      if (chatLog) {
        const history = this.chatHistory.length ? this.chatHistory : [{ role: "assistant", text: "Bonjour. Posez une question sur un transfert, un solde ou la s\xE9curit\xE9." }];
        for (const message of history) {
          const item = document.createElement("div");
          item.textContent = message.text;
          item.style.cssText = "max-width:90%;padding:10px;border-radius:10px;white-space:pre-wrap;overflow-wrap:anywhere;background:" + (message.role === "user" ? "#111;color:#fff;align-self:flex-end" : "#f2f3f5;color:#111;align-self:flex-start");
          chatLog.appendChild(item);
        }
        chatLog.scrollTop = chatLog.scrollHeight;
      }
      const ask = (question) => {
        if (!question.trim()) return;
        const response = generateBankingResponse(question.trim(), this.currentTargetLang);
        this.chatHistory.push({ role: "user", text: question.trim() }, { role: "assistant", text: response.text });
        this.render();
      };
      this.shadow.getElementById("lb-chat-form")?.addEventListener("submit", (e) => {
        e.preventDefault();
        ask(this.shadow?.getElementById("lb-chat-input")?.value || "");
      });
      this.shadow.querySelectorAll(".lb-quick").forEach((b) => b.addEventListener("click", () => ask(b.dataset.question || "")));
      this.shadow.getElementById("audio-replay")?.addEventListener("click", () => {
        const text = this.shadow?.getElementById("audio-spoken-text")?.textContent || "";
        const phonetic = this.shadow?.getElementById("audio-phonetic")?.textContent?.replace(/[\[\]]/g, "") || "";
        this.speechPlayer.speak(text, phonetic, void 0, this.currentTargetLang);
      });
      this.shadow.getElementById("audio-stop")?.addEventListener("click", () => {
        this.stopSpeech();
      });
      this.shadow.getElementById("audio-close")?.addEventListener("click", () => {
        this.stopSpeech();
        this.activeBarState = { visible: false, text: "", phonetic: "" };
        const bar = this.shadow?.getElementById("audio-bar");
        if (bar) bar.style.display = "none";
      });
    }
    destroy() {
      document.documentElement.removeAttribute("data-linguabridge-extension");
      this.stopSpeech();
      if (this.isPageTranslated) {
        this.restorePage();
      }
      this.clearHoverState();
      if (this.container && this.container.parentNode) {
        this.container.parentNode.removeChild(this.container);
        this.container = null;
        this.shadow = null;
      }
      if (this.onMouseUpHandler) {
        document.removeEventListener("mouseup", this.onMouseUpHandler);
        this.onMouseUpHandler = null;
      }
      if (this.onClickOutsideHandler) {
        document.removeEventListener("click", this.onClickOutsideHandler);
        this.onClickOutsideHandler = null;
      }
      if (this.onRuntimeMessageHandler && typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
        chrome.runtime.onMessage.removeListener(this.onRuntimeMessageHandler);
        this.onRuntimeMessageHandler = null;
      }
      if (this.onMouseOverHandler) {
        document.removeEventListener("mouseover", this.onMouseOverHandler, true);
        document.removeEventListener("pointerover", this.onMouseOverHandler, true);
        this.onMouseOverHandler = null;
      }
      if (this.onMouseOutHandler) {
        document.removeEventListener("mouseout", this.onMouseOutHandler, true);
        document.removeEventListener("pointerout", this.onMouseOutHandler, true);
        this.onMouseOutHandler = null;
      }
      if (this.onClickElementHandler) {
        document.removeEventListener("click", this.onClickElementHandler, true);
        this.onClickElementHandler = null;
      }
      if (this.onTouchEndHandler) {
        document.removeEventListener("touchend", this.onTouchEndHandler, true);
        this.onTouchEndHandler = null;
      }
      if (this.onFirstInteractionHandler) {
        window.removeEventListener("pointerdown", this.onFirstInteractionHandler);
        window.removeEventListener("keydown", this.onFirstInteractionHandler);
        this.onFirstInteractionHandler = null;
      }
      if (this.onDragMoveHandler) {
        window.removeEventListener("mousemove", this.onDragMoveHandler);
        this.onDragMoveHandler = null;
      }
      if (this.onDragEndHandler) {
        window.removeEventListener("mouseup", this.onDragEndHandler);
        this.onDragEndHandler = null;
      }
      if (this.mutationObserver) {
        this.mutationObserver.disconnect();
        this.mutationObserver = null;
      }
      if (this.mutationDebounceTimeout) {
        clearTimeout(this.mutationDebounceTimeout);
        this.mutationDebounceTimeout = null;
      }
      this.pendingMutations.clear();
      this.originalTextMap.clear();
      this.originalAttrMap.clear();
      this.translationSpeechCache.clear();
    }
  };
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    new ExtensionAssistant();
  }
})();
