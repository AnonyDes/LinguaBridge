"use strict";
(() => {
  // ../../packages/sdk-js/dist/index.mjs
  var LinguaBridgeError = class extends Error {
    constructor(message, statusCode, details) {
      super(message);
      this.statusCode = statusCode;
      this.details = details;
      this.name = "LinguaBridgeError";
    }
    statusCode;
    details;
  };
  var LinguaBridgeClient = class {
    baseUrl;
    apiKey;
    timeout;
    tenantId;
    memoryCache = /* @__PURE__ */ new Map();
    constructor(options = {}) {
      this.baseUrl = (options.baseUrl || "http://localhost:3001").replace(/\/$/, "");
      this.apiKey = options.apiKey;
      this.timeout = options.timeout || 1e4;
      this.tenantId = options.tenantId;
    }
    async request(endpoint, options = {}) {
      const url = `${this.baseUrl}${endpoint}`;
      const headers = {
        "Content-Type": "application/json",
        Accept: "application/json",
        ...options.headers
      };
      if (this.apiKey) {
        headers["Authorization"] = `Bearer ${this.apiKey}`;
        headers["x-api-key"] = this.apiKey;
      }
      if (this.tenantId) {
        headers["x-tenant-id"] = this.tenantId;
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);
      try {
        const response = await fetch(url, {
          ...options,
          headers,
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
          let errorData = {};
          try {
            errorData = await response.json();
          } catch {
          }
          throw new LinguaBridgeError(
            errorData.message || `HTTP ${response.status}: ${response.statusText}`,
            response.status,
            errorData
          );
        }
        return await response.json();
      } catch (err) {
        clearTimeout(timeoutId);
        if (err instanceof LinguaBridgeError) throw err;
        if (err.name === "AbortError") {
          throw new LinguaBridgeError(`Request timed out after ${this.timeout}ms`, 408);
        }
        throw new LinguaBridgeError(`Network failure: ${err.message}`, 0, err);
      }
    }
    async translate(params) {
      const cacheKey = `${params.sourceLang}:${params.targetLang}:${params.text}`;
      if (params.useCache !== false && this.memoryCache.has(cacheKey)) {
        return this.memoryCache.get(cacheKey);
      }
      const result = await this.request("/v1/translate", {
        method: "POST",
        body: JSON.stringify({
          sourceText: params.text,
          sourceLang: params.sourceLang,
          targetLang: params.targetLang,
          domain: params.domain || "general",
          context: params.context
        })
      });
      if (params.useCache !== false && result.status !== "failed") {
        this.memoryCache.set(cacheKey, result);
      }
      return result;
    }
    async translateBatch(items) {
      const requests = items.map((item, index) => ({
        id: `req-${Date.now()}-${index}`,
        sourceText: item.text,
        sourceLang: item.sourceLang,
        targetLang: item.targetLang,
        domain: item.domain || "general",
        context: item.context
      }));
      const response = await this.request("/v1/translate/batch", {
        method: "POST",
        body: JSON.stringify({ items: requests })
      });
      return response.results;
    }
    async getLanguages() {
      const response = await this.request("/v1/languages");
      return response.languages;
    }
    async getPacks() {
      const response = await this.request("/v1/packs");
      return response.packs;
    }
    async checkHealth() {
      return this.request("/health");
    }
    clearLocalCache() {
      this.memoryCache.clear();
    }
  };

  // src/popup.ts
  var client = new LinguaBridgeClient({ baseUrl: "http://localhost:3001" });
  document.addEventListener("DOMContentLoaded", async () => {
    const statusEl = document.getElementById("api-status");
    const langCountEl = document.getElementById("lang-count");
    const triggerPageBtn = document.getElementById("btn-trigger-page");
    const triggerSpeakBtn = document.getElementById("btn-trigger-speak");
    try {
      const health = await client.checkHealth();
      if (statusEl) {
        statusEl.textContent = `Connect\xE9 (API :3001)`;
        statusEl.style.color = "#15803d";
      }
      const languages = await client.getLanguages();
      if (langCountEl) {
        langCountEl.textContent = `${languages.length} langues certifi\xE9es (K\xF3b\u0254\u0301 Ewondo, FR, EN)`;
      }
    } catch {
      if (statusEl) {
        statusEl.textContent = "Autonome (Moteur local actif)";
        statusEl.style.color = "#15803d";
      }
      if (langCountEl) {
        langCountEl.textContent = "470+ termes (Apertium & NACALCO embarqu\xE9s)";
      }
    }
    triggerPageBtn?.addEventListener("click", async () => {
      if (typeof chrome !== "undefined" && chrome.tabs?.query) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
          chrome.tabs.sendMessage(tab.id, { type: "POPUP_TRANSLATE_PAGE", targetLang: "ewo-CM" });
          window.close();
        }
      }
    });
    triggerSpeakBtn?.addEventListener("click", async () => {
      if (typeof chrome !== "undefined" && chrome.tabs?.query) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
          chrome.tabs.sendMessage(tab.id, { type: "POPUP_TOGGLE_TOUCH_SPEAK" });
          window.close();
        }
      }
    });
  });
})();
