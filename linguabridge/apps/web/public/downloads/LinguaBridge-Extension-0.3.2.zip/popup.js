"use strict";
(() => {
  // ../../packages/widget/src/banking-engine.ts
  function extractFinancialEntities(text) {
    const entities = [];
    const seen = /* @__PURE__ */ new Set();
    const amountRegex = /\b(\d[\d\s,\.]*(?:\s*\d{3})*|\d+)\s*(FCFA|XAF|CFA|F|EUR|USD)\b/gi;
    let match;
    while ((match = amountRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "amount",
          raw,
          normalized: raw.replace(/\s+/g, " ").toUpperCase()
        });
      }
    }
    const phoneRegex = /(?:\+?237\s*)?[6-9]\d{2}[\s.-]?\d{3}[\s.-]?\d{3}\b/g;
    while ((match = phoneRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "phone",
          raw,
          normalized: raw.replace(/[\s.-]/g, "")
        });
      }
    }
    const refRegex = /\b(?:TXN|REF|ID|ACC)-[A-Z0-9]{4,16}\b/gi;
    while ((match = refRegex.exec(text)) !== null) {
      const raw = match[0].trim();
      if (!seen.has(raw)) {
        seen.add(raw);
        entities.push({
          type: "reference",
          raw,
          normalized: raw.toUpperCase()
        });
      }
    }
    return entities;
  }
  function detectBankingIntent(query) {
    const lower = query.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (lower.includes("secur") || lower.includes("pin") || lower.includes("otp") || lower.includes("code") || lower.includes("perdu") || lower.includes("vol") || lower.includes("arnaque") || lower.includes("fraude") || lower.includes("bloqu")) {
      return "security";
    }
    if (lower.includes("envoy") || lower.includes("transfer") || lower.includes("virement") || lower.includes("send") || lower.includes("payer") || lower.includes("loma") || lower.includes("neldu") || lower.includes("tura") || lower.includes("s\u0259nd")) {
      return "transfer";
    }
    if (lower.includes("frais") || lower.includes("retrait") || lower.includes("distributeur") || lower.includes("gab") || lower.includes("atm") || lower.includes("cout") || lower.includes("tarif") || lower.includes("fee") || lower.includes("charge") || lower.includes("hakke")) {
      return "fees";
    }
    if (lower.includes("solde") || lower.includes("balance") || lower.includes("compte") || lower.includes("reste") || lower.includes("combien") || lower.includes("kudi") || lower.includes("ceede") || lower.includes("moni")) {
      return "balance";
    }
    return "general";
  }
  function generateBankingResponse(query, targetLang = "ewo-CM") {
    const intent = detectBankingIntent(query);
    const entities = extractFinancialEntities(query);
    let text = "";
    let phonetic = "";
    const langCode = targetLang.toLowerCase();
    if (langCode.startsWith("ewo")) {
      switch (intent) {
        case "transfer":
          text = "Asu ya nloman m\xF3ni, kele va 'Virement', nyi\xF1i nomb\xE1 ya nlemba ai abim m\xF3ni, tsin\xED k\xF3d PIN wo\xE9. M\xF3ni mak\xE9 nlem-nlem a nda m\xF4t nu.";
          phonetic = "Asou ya nloman moni, kele va Virement, nyini nomba ya nlemba ai abim moni, tsini kod PIN woe. Moni make nlem-nlem.";
          break;
        case "balance":
          text = "M\xF3ni m\xED ne wo a k\xF4mba: F\xE1an etere o ne abim m\xF3ni ya nlemba. K\xF3d PIN wu\xE9 \xE9 ne mb\xF3l asu ya ngeng \xF3se.";
          phonetic = "Moni mi ne wo a komba: Faan etere o ne abim moni ya nlemba. Kod PIN wue e ne mbol asu ya ngeng ose.";
          break;
        case "fees":
          text = "Frais ya nk\xF3b\xF3l m\xF3ni a GAB / Agence: 1% ya abim m\xF3ni, ke ve 500 FCFA a nsisin. Nk\xF3b\xF3l m\xF3ni \xE9 ne 0 FCFA a Guichet nlemba.";
          phonetic = "Frais ya nkobol moni a GAB / Agence: un pour cent ya abim moni, ke ve 500 FCFA a nsisin. Nkobol moni e ne zero FCFA a Guichet nlemba.";
          break;
        case "security":
          text = "Mfi ya k\xF4mba: Te va k\xF3d PIN wu\xE9 ke nomb\xE1 OTP ai m\xF4t teke teke. Banque \xE9 se laa yi wo k\xF3d wu\xE9 a t\xE9lefon!";
          phonetic = "Mfi ya komba: Te va kod PIN wue ke nomba OTP ai mot teke teke. Banque e se laa yi wo kod wue a telefon!";
          break;
        default:
          text = "Mb\xF3lani! Me ne assistant bancaire LinguaBridge. Me ne wo vol\xF3 asu ya nloman m\xF3ni, solde, nk\xF3b\xF3l m\xF3ni ai mbamba k\xF4mba.";
          phonetic = "Mbolani! Me ne assistant bancaire LinguaBridge. Me ne wo volo asu ya nloman moni, solde, nkobol moni ai mbamba komba.";
          break;
      }
    } else if (langCode.startsWith("fuv")) {
      switch (intent) {
        case "transfer":
          text = "Ngam neldugo ceede, jahda to 'Neldugo', mbinnda lamba ja\u0253oowo e limoore ceede, katin ndokka PIN maada. Ceede \u0257en nylan jonta.";
          phonetic = "Ngam neldugo tcheede, jahda to Neldugo, mbinnda lamba jaboowo e limoore tcheede, katin ndokka PIN maada. Tcheede den nylan jonta.";
          break;
        case "balance":
          text = "Ceede maada heddii\u0257e: A\u0257a jogii limoore ceede maada haa ashirgol maada. Koodi maada deenaama jam.";
          phonetic = "Tcheede maada heddiide: Ada jogii limoore tcheede maada haa ashirgol maada. Koodi maada deenaama jam.";
          break;
        case "fees":
          text = "Hakke ittego ceede haa GAB: 1% e dow limoore itteteende, ko fam\u0257i fuu 500 FCFA. Ittego haa suudu banki walaa hakke (0 FCFA).";
          phonetic = "Hakke ittego tcheede haa GAB: go'o pour cent e dow limoore itteteende, ko famdi fuu 500 FCFA. Ittego haa suudu banki walaa hakke zero FCFA.";
          break;
        case "security":
          text = "Deenal ashirgol maada: Taa hokku koodi maada sirri ko lamba OTP to hay gooto. Banki \u0257on \u01B4amataa sirri maada sam!";
          phonetic = "Deenal ashirgol maada: Taa hokku koodi maada sirri ko lamba OTP to hay gooto. Banki don yamataa sirri maada sam!";
          break;
        default:
          text = "Jam waali! Mi\u0257o wallu ma e golle banki: neldugo ceede, limol ceede, hakke ittego e deenal kisndam.";
          phonetic = "Jam waali! Mido wallu ma e golle banki: neldugo tcheede, limol tcheede, hakke ittego e deenal kisndam.";
          break;
      }
    } else if (langCode.startsWith("hau")) {
      switch (intent) {
        case "transfer":
          text = "Don tura kudi, je shafin 'Aika Kudi', sa lambar asusun mai karba da adadin kudi, sannan ka tabbatar da lambar PIN. Kudin zasu isa nan take.";
          phonetic = "Don toura koudi, je shafin Aika Kudi, sa lambar asusun mai karba da adadin kudi, sannan ka tabbatar da lambar PIN. Kudin zasu isa nan take.";
          break;
        case "balance":
          text = "Sauran kudin ka a asusu: Zaka iya duba adadin kudin ka a kowane lokaci. Lambar sirrinka tana nan a kiyaye.";
          phonetic = "Saouran koudin ka a asousou: Zaka iya douba adadin kudin ka a kowane lokatsi. Lambar sirrinka tana nan a kiyaye.";
          break;
        case "fees":
          text = "Kudin cire kudi a ATM: Kashi 1% na adadin kudi, ko a kalla 500 FCFA. Cire kudi a ofishin banki kyauta ne (0 FCFA).";
          phonetic = "Kudin tsire kudi a ATM: Kashi 1% na adadin kudi, ko a kalla 500 FCFA. Tsire kudi a ofishin banki kyauta ne.";
          break;
        case "security":
          text = "Kariyar asusunka: Kada ka taba bayyana lambar PIN ko lambar sirri ta OTP ga kowa. Banki ba zai taba tambayar lambar sirrinka ta waya ba!";
          phonetic = "Kariyar asusunka: Kada ka taba bayyana lambar PIN ko lambar sirri ta OTP ga kowa. Banki ba zai taba tambayar lambar sirrinka ta waya ba!";
          break;
        default:
          text = "Sannu! Ni ne mataimakin banki na LinguaBridge. Zan taimake ka da aika kudi, duba asusu, da kiyaye kudadenka.";
          phonetic = "Sannu! Ni ne mataimakin banki na LinguaBridge. Zan taimake ka da aika kudi, duba asusu, da kiyaye kudadenka.";
          break;
      }
    } else if (langCode.startsWith("knc")) {
      switch (intent) {
        case "transfer":
          text = "K\u0259la k\u0259la ci kudi s\u0259ndoye: Fuwuro 'Cidiya Kudi' ro lewone, lamba k\u0259la maiye kuru lamba kudiye ruwone, kuru lambaro PIN-nam cukkuro. Kudiye cidiya karrin fannoto.";
          phonetic = "Kala kala tsi koudi sandoye: Fouworro Tsidiya Kudi ro lewone, lamba kala maiye kuru lamba kudiye, kuru lambaro PIN-nam tsoukkouro. Kudiye tsidiya karrin fannoto.";
          break;
        case "balance":
          text = "Kudi asusun\u0259mye b\u0259lindi: Adadu kudiye nam kuru asusun\u0259mye k\u0259l\u0259wanz\u0259 kalkallo shidoni. Lambaro sirriye garuwanz\u0259 t\u0259rnoma.";
          phonetic = "Koudi asousounamye balindi: Adadou kudiye nam kuru asousounamye kalawanza kalkallo shidoni. Lambaro sirriye garuwanza tarnoma.";
          break;
        case "fees":
          text = "Kudi k\u0259la ATM-ro s\u0259ndoye: 1% k\u0259la adadu kudiye, ko 500 FCFA ganawo. Bankinro kudi fidoye kudi bawo (0 FCFA).";
          phonetic = "Koudi kala ATM-ro sandoye: fal pour cent kala adadou kudiye, ko 500 FCFA ganawo. Bankinro kudi fidoye kudi bawo zero FCFA.";
          break;
        case "security":
          text = "Lafiya asusun\u0259mye: Lambaro PIN-nam kuru OTP-nam nduro yaye k\u0259mbuwone. Bankiye lambaro sirrin\u0259m k\u0259la wayabe kura wande!";
          phonetic = "Lafiya asousounamye: Lambaro PIN-nam kuru OTP-nam ndouro yaye kambuwone. Bankiye lambaro sirrinam kala wayabe kura wande!";
          break;
        default:
          text = "Wushe wushe! N\u0259m zaye assistant bankiye LinguaBridge. Kudi s\u0259ndoye, adadu asusuye, kuru k\u0259la lafiya asusuyero kpanza k\u0259ljin.";
          phonetic = "Wushe wushe! Nam zaye assistant bankiye LinguaBridge. Kudi sandoye, adadu asusuye, kuru kala lafiya asusuyero kpanza kaljin.";
          break;
      }
    } else if (langCode.startsWith("pcm")) {
      switch (intent) {
        case "transfer":
          text = "To send money, go to 'Transfer', put the person account number and amount, then enter your secret PIN. The money go enter one time without wahala.";
          phonetic = "To send moni, go to Transfer, put di pesin akownt nomba and amownt, den enta ya secret PIN. Di moni go enta wan taym witawt wahala.";
          break;
        case "balance":
          text = "Your account balance: You fit check your money anytime inside the app. Your secret PIN code dey protected strong strong.";
          phonetic = "Ya akownt balans: Yu fit chek ya moni enitaym insayd di app. Ya sikret PIN kod dey prot\xE8kted stron stron.";
          break;
        case "fees":
          text = "Withdrawal charges for ATM: 1% of the money, minimum 500 FCFA. To withdraw inside bank branch na completely free (0 FCFA).";
          phonetic = "Widrowal chajiz fo ATM: wan pesent of di moni, minimom 500 FCFA. To widrow insayd bank branch na komplitli fri zero FCFA.";
          break;
        case "security":
          text = "Security for your account: Make you never give your secret PIN or OTP code to any person for this world. Bank go never ask you your PIN for phone!";
          phonetic = "Sekyuriti fo ya akownt: Mek yu neva giv ya sikret PIN o OTP kod to eni pesin fo dis wol. Bank go neva ask yu ya PIN fo fon!";
          break;
        default:
          text = "How far! Na me be your LinguaBridge Bank Assistant. I fit help you send money, check balance, check charges, and secure your account.";
          phonetic = "Haw fa! Na mi bi ya LingwaBrij Bank Asistant. Ay fit help yu send moni, chek balans, chek chajiz, and sekyur ya akownt.";
          break;
      }
    } else {
      switch (intent) {
        case "transfer":
          text = "Pour envoyer de l'argent, acc\xE9dez \xE0 l'onglet 'Virement', saisissez le num\xE9ro de compte ou t\xE9l\xE9phone du destinataire ainsi que le montant, puis validez avec votre code PIN confidentiel.";
          phonetic = text;
          break;
        case "balance":
          text = "Pour consulter votre solde, acc\xE9dez \xE0 'Mon Espace' ou saisissez votre code PIN. Votre solde disponible est synchronis\xE9 en temps r\xE9el.";
          phonetic = text;
          break;
        case "fees":
          text = "Les frais de retrait au distributeur (GAB) sont de 1% du montant retir\xE9 (minimum 500 FCFA). Les retraits au guichet de votre banque sont gratuits (0 FCFA).";
          phonetic = text;
          break;
        case "security":
          text = "S\xE9curit\xE9 de votre compte : Ne communiquez jamais votre code secret PIN ni votre code OTP par SMS. Votre banque ne vous contactera jamais pour vous demander vos identifiants confidentiels.";
          phonetic = text;
          break;
        default:
          text = "Bonjour ! Je suis l'assistant bancaire IA LinguaBridge. Je peux vous renseigner sur vos virements, solde, frais de retrait et s\xE9curit\xE9 bancaire.";
          phonetic = text;
          break;
      }
    }
    if (entities.length > 0) {
      const entityStrings = entities.map((e) => e.raw).join(", ");
      const entityNotice = ` [\u{1F6E1}\uFE0F AST Guard: ${entityStrings}]`;
      text += entityNotice;
      phonetic += ` [${entityStrings}]`;
    }
    return {
      intent,
      text,
      phonetic,
      lang: targetLang,
      entities,
      zeroDriftVerified: true
    };
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var supported = /* @__PURE__ */ new Set(["ewo-CM", "fuv-CM", "hau-CM", "knc-CM", "pcm-CM", "en", "fr"]);
  async function activeTabMessage(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return false;
    try {
      await chrome.tabs.sendMessage(tab.id, message);
      return true;
    } catch {
      try {
        const contentScript = chrome.runtime.getManifest().content_scripts?.[0]?.js?.[0];
        if (!contentScript) return false;
        await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: [contentScript] });
        await chrome.tabs.sendMessage(tab.id, message);
        return true;
      } catch {
        return false;
      }
    }
  }
  function showStatus(text) {
    const el = $("popup-status");
    if (el) el.textContent = text;
  }
  async function refreshPageWorkload() {
    const el = $("page-workload");
    if (!el) return;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const metrics = tab?.id ? await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_METRICS" }) : null;
      if (!metrics || typeof metrics.segments !== "number") {
        el.textContent = "Cette page ne permet pas l\u2019analyse.";
        return;
      }
      const size = metrics.characters > 25e3 ? "grande" : metrics.characters > 5e3 ? "moyenne" : "petite";
      const pageLabel = `Page ${size} \xB7 ${metrics.segments.toLocaleString("fr")} segments \xB7 ${metrics.characters.toLocaleString("fr")} caract\xE8res`;
      el.textContent = pageLabel;
      if (tab?.id) {
        void chrome.tabs.sendMessage(tab.id, { type: "GET_SITE_SIZE" }).then((site) => {
          if (!site || typeof site.pages !== "number") return;
          if (el.textContent !== pageLabel) return;
          const label = site.source === "sitemap" ? "pages identifi\xE9es via sitemap et liens" : "liens internes trouv\xE9s sur cette page";
          el.textContent += ` \xB7 ${site.pages.toLocaleString("fr")} ${label}${site.complete ? "" : " (estimation partielle)"}`;
        }).catch(() => {
        });
      }
    } catch {
      el.textContent = "Cette page ne permet pas l\u2019analyse.";
    }
  }
  function showTab(tab) {
    for (const name of ["translate", "assistant"]) {
      $("tab-" + name)?.setAttribute("aria-selected", String(name === tab));
      const panel = $("panel-" + name);
      if (panel) panel.hidden = name !== tab;
    }
  }
  document.addEventListener("DOMContentLoaded", async () => {
    const select = $("popup-target-lang");
    const toggle = $("btn-speech-toggle");
    const enhancedToggle = $("btn-enhanced-toggle");
    const apiUrl = $("api-url");
    const apiKey = $("api-key");
    const saved = await chrome.storage.local.get(["linguabridgeTargetLang", "linguabridgeAudioEnabled", "linguabridgeAutoTranslate", "linguabridgeEnhancedTranslation", "linguabridgeApiBaseUrl", "linguabridgeApiKey"]);
    select.value = supported.has(saved.linguabridgeTargetLang) ? saved.linguabridgeTargetLang : "ewo-CM";
    toggle.setAttribute("aria-checked", String(saved.linguabridgeAudioEnabled === true));
    enhancedToggle.setAttribute("aria-checked", String(saved.linguabridgeEnhancedTranslation === true || select.value === "en" || select.value === "fr"));
    apiUrl.value = saved.linguabridgeApiBaseUrl || "https://api-production-72bac574.up.railway.app";
    apiKey.value = saved.linguabridgeApiKey || "";
    let serverKeySaved = Boolean(saved.linguabridgeApiKey);
    void refreshPageWorkload();
    if (saved.linguabridgeAudioEnabled === true && !saved.linguabridgeApiKey && apiUrl.value.startsWith("https://")) {
      showStatus("Lecture activ\xE9e, mais aucune cl\xE9 serveur enregistr\xE9e. Saisissez la cl\xE9 LinguaBridge et cliquez sur \xAB Enregistrer le serveur \xBB.");
    } else if (saved.linguabridgeAutoTranslate === true) {
      showStatus("Traduction automatique active. Les passages inconnus restent dans la langue source.");
    }
    $("tab-translate")?.addEventListener("click", () => showTab("translate"));
    $("tab-assistant")?.addEventListener("click", () => showTab("assistant"));
    select.addEventListener("change", async () => {
      const needsServer = select.value === "en" || select.value === "fr";
      await chrome.storage.local.set({
        linguabridgeTargetLang: select.value,
        ...needsServer ? { linguabridgeEnhancedTranslation: true } : {}
      });
      if (needsServer) {
        enhancedToggle.setAttribute("aria-checked", "true");
        await activeTabMessage({ type: "POPUP_SET_ENHANCED_TRANSLATION", enabled: true });
      }
      await activeTabMessage({ type: "POPUP_SET_TARGET_LANGUAGE", targetLang: select.value });
      showStatus(needsServer ? serverKeySaved ? "Langue enregistr\xE9e. La traduction EN/FR utilise le serveur configur\xE9." : "Langue enregistr\xE9e. Ajoutez la cl\xE9 LinguaBridge et cliquez sur \xAB Enregistrer le serveur \xBB pour traduire en EN/FR." : "Langue enregistr\xE9e.");
    });
    $("btn-trigger-page")?.addEventListener("click", async () => {
      if ((select.value === "en" || select.value === "fr") && !serverKeySaved) {
        showStatus("La traduction EN/FR n\xE9cessite la cl\xE9 LinguaBridge. Enregistrez le serveur avant de traduire.");
        return;
      }
      await chrome.storage.local.set({ linguabridgeAutoTranslate: true });
      const ok = await activeTabMessage({ type: "POPUP_TRANSLATE_PAGE", targetLang: select.value });
      showStatus(ok ? "Traduction activ\xE9e pour les pages suivantes. Le lexique local peut laisser des passages inchang\xE9s." : "Traduction activ\xE9e, mais cette page ne permet pas l\u2019injection de l\u2019extension.");
      setTimeout(() => void refreshPageWorkload(), 350);
    });
    $("btn-restore-page")?.addEventListener("click", async () => {
      await chrome.storage.local.set({ linguabridgeAutoTranslate: false });
      const ok = await activeTabMessage({ type: "POPUP_RESTORE_PAGE" });
      showStatus(ok ? "Texte original restaur\xE9." : "Page non accessible.");
    });
    enhancedToggle.addEventListener("click", async () => {
      const enabled = enhancedToggle.getAttribute("aria-checked") !== "true";
      if (!enabled && (select.value === "en" || select.value === "fr")) {
        showStatus("La traduction EN/FR n\xE9cessite la traduction approfondie et le serveur LinguaBridge.");
        return;
      }
      await chrome.storage.local.set({ linguabridgeEnhancedTranslation: enabled });
      enhancedToggle.setAttribute("aria-checked", String(enabled));
      await activeTabMessage({ type: "POPUP_SET_ENHANCED_TRANSLATION", enabled });
      showStatus(enabled ? "Traduction approfondie activ\xE9e. Le texte de la page peut \xEAtre envoy\xE9 au serveur configur\xE9." : "Traduction approfondie d\xE9sactiv\xE9e.");
    });
    $("btn-save-server")?.addEventListener("click", async () => {
      const value = apiUrl.value.trim() || "https://api-production-72bac574.up.railway.app";
      let url;
      try {
        url = new URL(value);
      } catch {
        showStatus("Adresse du serveur invalide.");
        return;
      }
      if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
        showStatus("Utilisez HTTPS, ou localhost pour un serveur sur cet ordinateur.");
        return;
      }
      if (url.protocol === "https:" && !apiKey.value.trim()) {
        showStatus("Ajoutez la cl\xE9 LinguaBridge avant d\u2019enregistrer le serveur vocal Railway.");
        return;
      }
      if (url.protocol === "https:") {
        const granted = await chrome.permissions.request({ origins: [`${url.origin}/*`] });
        if (!granted) {
          showStatus("Acc\xE8s au serveur non accord\xE9.");
          return;
        }
      }
      await chrome.storage.local.set({ linguabridgeApiBaseUrl: value.replace(/\/$/, ""), linguabridgeApiKey: apiKey.value.trim() });
      serverKeySaved = Boolean(apiKey.value.trim());
      if (enhancedToggle.getAttribute("aria-checked") === "true") {
        await activeTabMessage({ type: "POPUP_SET_ENHANCED_TRANSLATION", enabled: true });
      }
      showStatus(enhancedToggle.getAttribute("aria-checked") === "true" ? "Serveur enregistr\xE9. Traduction approfondie et voix disponibles." : "Serveur enregistr\xE9. La lecture vocale est pr\xEAte si elle est activ\xE9e.");
    });
    toggle.addEventListener("click", async () => {
      const enabled = toggle.getAttribute("aria-checked") !== "true";
      if (enabled && apiUrl.value.startsWith("https://") && !serverKeySaved) {
        showStatus("Ajoutez la cl\xE9 LinguaBridge, puis cliquez sur \xAB Enregistrer le serveur \xBB avant d\u2019activer la voix.");
        return;
      }
      await chrome.storage.local.set({ linguabridgeAudioEnabled: enabled });
      toggle.setAttribute("aria-checked", String(enabled));
      await activeTabMessage({ type: "POPUP_SET_SPEECH", enabled });
      showStatus(enabled ? "Lecture sur demande activ\xE9e." : "Lecture d\xE9sactiv\xE9e.");
    });
    $("btn-stop-speech")?.addEventListener("click", async () => {
      await activeTabMessage({ type: "POPUP_STOP_SPEECH" });
      showStatus("Lecture arr\xEAt\xE9e.");
    });
    const log = $("chat-log");
    const input = $("chat-input");
    function addMessage(role, text) {
      const bubble = document.createElement("div");
      bubble.className = "bubble " + role;
      bubble.textContent = text;
      log.appendChild(bubble);
      log.scrollTop = log.scrollHeight;
    }
    function ask(text) {
      const question = text.trim();
      if (!question) return;
      addMessage("user", question);
      const response = generateBankingResponse(question, select.value);
      addMessage("assistant", response.text);
      input.value = "";
    }
    $("chat-form")?.addEventListener("submit", (e) => {
      e.preventDefault();
      ask(input.value);
    });
    document.querySelectorAll("[data-question]").forEach((button) => {
      button.addEventListener("click", () => ask(button.dataset.question || ""));
    });
  });
})();
